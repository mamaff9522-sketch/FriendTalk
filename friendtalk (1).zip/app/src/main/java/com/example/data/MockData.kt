package com.example.data

import com.example.model.*

object MockData {
    val initialUsers = listOf(
        User(
            id = "user_me",
            username = "tonkla_tk",
            displayName = "ต้นกล้า (Tonkla)",
            avatar = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80",
            coverPhoto = "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&auto=format&fit=crop&q=80",
            age = 24,
            gender = Gender.MALE,
            bio = "ชอบท่องเที่ยว ฟังเพลง ถ่ายรูปคาเฟ่ มาทำความรู้จักกันได้ครับ ☕✈️",
            role = UserRole.USER,
            isCreator = false,
            isVerified = true,
            isOnline = true,
            lastActive = "ออนไลน์ขณะนี้",
            coins = 1500,
            diamonds = 320,
            followersCount = 342,
            followingCount = 180,
            friendsCount = 64,
            likesCount = 1450,
            location = UserLocation("กรุงเทพมหานคร", 0.0, true),
            photos = listOf(
                "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=500&auto=format&fit=crop&q=80",
                "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=500&auto=format&fit=crop&q=80"
            ),
            badges = listOf("ผู้ใช้ดาวรุ่ง ⭐", "สายคาเฟ่ ☕"),
            interests = listOf("ท่องเที่ยว", "ฟังเพลง", "ถ่ายภาพ", "กาแฟ", "ซีรีส์"),
            giftsReceivedTotal = 120
        ),
        User(
            id = "user_admin",
            username = "admin_official",
            displayName = "ณัฐพงษ์ (Official Admin)",
            avatar = "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&auto=format&fit=crop&q=80",
            coverPhoto = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&auto=format&fit=crop&q=80",
            age = 30,
            gender = Gender.MALE,
            bio = "เจ้าหน้าที่ดูแลระบบ FriendTalk ตรวจสอบความปลอดภัยและให้บริการผู้ใช้ 24 ชม. 🛡️",
            role = UserRole.SUPERADMIN,
            isCreator = false,
            isVerified = true,
            isOnline = true,
            lastActive = "ออนไลน์ขณะนี้",
            coins = 99999,
            diamonds = 50000,
            followersCount = 15400,
            followingCount = 50,
            friendsCount = 200,
            likesCount = 98000,
            location = UserLocation("กรุงเทพมหานคร", 2.1, true),
            badges = listOf("👑 Super Admin", "🛡️ ฝ่ายความปลอดภัย"),
            interests = listOf("เทคโนโลยี", "ระบบความปลอดภัย", "การพัฒนา"),
            giftsReceivedTotal = 500
        ),
        User(
            id = "user_linlin",
            username = "linlin_live",
            displayName = "หลินหลิน 🌸 LinLada",
            avatar = "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&auto=format&fit=crop&q=80",
            coverPhoto = "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=800&auto=format&fit=crop&q=80",
            age = 22,
            gender = Gender.FEMALE,
            bio = "นักร้องอินดี้ & ครีเอเตอร์ประจำ FriendTalk มาร้องเพลงและพูดคุยกันทุกค่ำนะคะ 🎙️✨",
            role = UserRole.USER,
            isCreator = true,
            isVerified = true,
            isOnline = true,
            lastActive = "กำลังไลฟ์สด 🔴",
            coins = 4500,
            diamonds = 42500,
            followersCount = 28400,
            followingCount = 140,
            friendsCount = 110,
            likesCount = 156000,
            location = UserLocation("กรุงเทพมหานคร", 1.4, true),
            badges = listOf("🎤 Top Singer", "💎 Diamond Creator", "🔥 Live Star"),
            interests = listOf("ดนตรี", "ร้องเพลง", "กีตาร์", "แฟชั่น", "แมว"),
            giftsReceivedTotal = 48900
        ),
        User(
            id = "user_arty",
            username = "arty_gamer",
            displayName = "อาร์ตี้ ธาวิน ⚡",
            avatar = "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=400&auto=format&fit=crop&q=80",
            coverPhoto = "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800&auto=format&fit=crop&q=80",
            age = 23,
            gender = Gender.MALE,
            bio = "สตรีมเมอร์สายฮา ชอบ PK และเล่นเกม ROV / MOBA แวะมาเชียร์กันได้เลยครับ! 🎮💥",
            role = UserRole.USER,
            isCreator = true,
            isVerified = true,
            isOnline = true,
            lastActive = "กำลังไลฟ์สด 🔴",
            coins = 3800,
            diamonds = 29800,
            followersCount = 19200,
            followingCount = 220,
            friendsCount = 95,
            likesCount = 88400,
            location = UserLocation("นนทบุรี", 4.8, true),
            badges = listOf("🎮 Pro Gamer", "⚡ PK King", "🔥 Live Star"),
            interests = listOf("เกม", "ROV", "อีสปอร์ต", "ออกกำลังกาย", "มังงะ"),
            giftsReceivedTotal = 34500
        ),
        User(
            id = "user_fah",
            username = "fahsai_cute",
            displayName = "ฟ้าใส ☁️ Fahsai",
            avatar = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80",
            coverPhoto = "https://images.unsplash.com/photo-1513151233558-d860c5398176?w=800&auto=format&fit=crop&q=80",
            age = 21,
            gender = Gender.FEMALE,
            bio = "นักศึกษา ม.เกษตร รักการอ่านหนังสือ คาเฟ่ฮอปปิ้ง และสัตว์เลี้ยง 🐱📚",
            role = UserRole.USER,
            isCreator = false,
            isVerified = false,
            isOnline = true,
            lastActive = "ออนไลน์ขณะนี้",
            coins = 850,
            diamonds = 150,
            followersCount = 2100,
            followingCount = 310,
            friendsCount = 140,
            likesCount = 12500,
            location = UserLocation("กรุงเทพมหานคร", 0.8, true),
            badges = listOf("🐾 คนรักสัตว์", "☕ Cafe Hopper"),
            interests = listOf("คาเฟ่", "แมว", "อ่านหนังสือ", "ทำขนม"),
            giftsReceivedTotal = 890
        ),
        User(
            id = "user_bank",
            username = "bank_fit",
            displayName = "แบงค์ ธนภัทร 💪",
            avatar = "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&auto=format&fit=crop&q=80",
            coverPhoto = "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=800&auto=format&fit=crop&q=80",
            age = 26,
            gender = Gender.MALE,
            bio = "เทรนเนอร์ฟิตเนส & ชอบวิ่งมาราธอน หาเพื่อนวิ่งสวนลุมและแลกเปลี่ยนเรื่องสุขภาพครับ 🏃‍♂️🥗",
            role = UserRole.USER,
            isCreator = false,
            isVerified = true,
            isOnline = false,
            lastActive = "30 นาทีที่แล้ว",
            coins = 600,
            diamonds = 80,
            followersCount = 3400,
            followingCount = 290,
            friendsCount = 180,
            likesCount = 19800,
            location = UserLocation("กรุงเทพมหานคร", 3.2, true),
            badges = listOf("💪 สายฟิตเนส", "🏃 Marathoner"),
            interests = listOf("ฟิตเนส", "วิ่ง", "โภชนาการ", "ว่ายน้ำ"),
            giftsReceivedTotal = 420
        ),
        User(
            id = "user_ploy",
            username = "ploy_travel",
            displayName = "พลอยใส (Ploy Sailom)",
            avatar = "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&auto=format&fit=crop&q=80",
            coverPhoto = "https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?w=800&auto=format&fit=crop&q=80",
            age = 25,
            gender = Gender.FEMALE,
            bio = "สถาปนิกที่รักการเดินทางคนเดียว แบกเป้เที่ยวภูเขาและทะเล ชอบคุยเรื่องศิลปะ 🎨🏞️",
            role = UserRole.MODERATOR,
            isCreator = false,
            isVerified = true,
            isOnline = true,
            lastActive = "ออนไลน์ขณะนี้",
            coins = 2100,
            diamonds = 450,
            followersCount = 5600,
            followingCount = 420,
            friendsCount = 210,
            likesCount = 43200,
            location = UserLocation("เชียงใหม่", 8.5, true),
            badges = listOf("🛡️ Moderator", "🎒 Backpacker", "🎨 Artist"),
            interests = listOf("สถาปัตยกรรม", "เดินป่า", "แคมป์ปิ้ง", "ศิลปะ"),
            giftsReceivedTotal = 1540
        ),
        User(
            id = "user_nong_khao",
            username = "nong_khao16",
            displayName = "น้องข้าว 🌾 (อายุ 16 ปี - ผู้ใช้เยาวชน)",
            avatar = "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=400&auto=format&fit=crop&q=80",
            coverPhoto = "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=800&auto=format&fit=crop&q=80",
            age = 16,
            gender = Gender.FEMALE,
            bio = "นักเรียน ม.ปลาย ชอบวาดรูปและอ่านหนังสือ 🎨 (อายุต่ำกว่า 18 ปี - ฟังก์ชันเพื่อนคุยจะถูกซ่อนและล็อกตามกฎหมาย)",
            role = UserRole.USER,
            isCreator = false,
            isVerified = false,
            isOnline = true,
            lastActive = "ออนไลน์ขณะนี้",
            coins = 300,
            diamonds = 0,
            followersCount = 85,
            followingCount = 120,
            friendsCount = 45,
            likesCount = 520,
            location = UserLocation("กรุงเทพมหานคร", 1.2, true),
            interests = listOf("วาดรูป", "อ่านการ์ตูน", "ดนตรี"),
            giftsReceivedTotal = 10
        ),
        User(
            id = "user_spammer",
            username = "bot_promo99",
            displayName = "ฝากร้านแจกเครดิตฟรี",
            avatar = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&auto=format&fit=crop&q=80",
            age = 99,
            gender = Gender.OTHER,
            bio = "คลิกลิงก์รับโบนัส แอดไลน์ไอดี @xxxx ด่วนจำนวนจำกัด",
            role = UserRole.USER,
            isCreator = false,
            isVerified = false,
            isOnline = false,
            lastActive = "1 วันที่แล้ว",
            coins = 0,
            diamonds = 0,
            followersCount = 2,
            followingCount = 890,
            friendsCount = 0,
            likesCount = 0,
            location = UserLocation("ไม่ระบุ", 0.0, false),
            isSuspended = true,
            giftsReceivedTotal = 0
        )
    )

    val giftsCatalog = listOf(
        Gift("gift_rose", "ดอกกุหลาบหวาน", "🌹", 1, GiftTier.BASIC),
        Gift("gift_heart", "มินิฮาร์ทสุดคิวท์", "🫰", 5, GiftTier.BASIC),
        Gift("gift_boba", "ชานมไข่มุกพ่นไฟ", "🧋", 20, GiftTier.MEDIUM),
        Gift("gift_crown", "มงกุฎเจ้าหญิง", "👑", 100, GiftTier.MEDIUM),
        Gift("gift_supercar", "สปอร์ตคาร์ซูเปอร์คาร์", "🏎️", 500, GiftTier.RARE),
        Gift("gift_rocket", "จรวด FriendTalk Space", "🚀", 1000, GiftTier.RARE),
        Gift("gift_castle", "ปราสาทเวทมนตร์", "🏰", 2500, GiftTier.LEGENDARY),
        Gift("gift_dragon", "มังกรทองนำโชค", "🐉", 5000, GiftTier.LEGENDARY)
    )

    val initialPosts = listOf(
        Post(
            id = "post_1",
            authorId = "user_linlin",
            content = "ขอบคุณทุกคนที่เข้ามาฟังเพลงในไลฟ์คืนนี้นะคะ! เพลงใหม่อบอุ่นหัวใจมากๆ ใครยังไม่ได้ดู รอติดตามคลิปไฮไลต์เร็วๆ นี้นะคะ 💖🎸 #ดนตรีสด #FriendTalkLive #เพลงเพราะ",
            mediaUrls = listOf("https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=800&auto=format&fit=crop&q=80"),
            likes = listOf("user_me", "user_arty", "user_fah", "user_ploy"),
            commentsCount = 28,
            sharesCount = 12,
            createdAt = "1 ชั่วโมงที่แล้ว",
            tags = listOf("ดนตรีสด", "FriendTalkLive", "เพลงเพราะ")
        ),
        Post(
            id = "post_2",
            authorId = "user_arty",
            content = "ศึก PK คืนนี้เดือดจัด! พรุ่งนี้ 2 ทุ่มนัดท้าดวลอีกรอบ ใครอยากเห็นผมแปลงร่าง ส่งจรวดมาได้เลย 🚀🎮 เจอกันในห้องไลฟ์ครับ!",
            mediaUrls = listOf("https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800&auto=format&fit=crop&q=80"),
            likes = listOf("user_me", "user_linlin"),
            commentsCount = 19,
            sharesCount = 5,
            createdAt = "3 ชั่วโมงที่แล้ว",
            tags = listOf("ROV", "PKLive", "GameStream")
        ),
        Post(
            id = "post_3",
            authorId = "user_fah",
            content = "ค้นพบคาเฟ่ลับย่านอารีย์ บรรยากาศเงียบสงบ กาแฟ Dirty หอมนุ่มมาก มีน้องเหมียวคอยต้อนรับด้วย 🐱 ใครอยากไปด้วยกันทักแชตมาได้น้าา",
            mediaUrls = listOf("https://images.unsplash.com/photo-1554118811-1e0d58224f24?w=800&auto=format&fit=crop&q=80"),
            likes = listOf("user_me", "user_ploy", "user_bank"),
            commentsCount = 14,
            sharesCount = 8,
            createdAt = "5 ชั่วโมงที่แล้ว",
            tags = listOf("คาเฟ่กรุงเทพ", "หาเพื่อนเที่ยว", "CafeHopping")
        ),
        Post(
            id = "post_4",
            authorId = "user_bank",
            content = "Morning Run 10km สวนเบญจกิติ อากาศเช้าวันนี้สดชื่นมาก วิ่งเพื่อสุขภาพและจิตใจที่แจ่มใส ใครอยากเข้ากลุ่มวิ่งทักได้เลยครับ 🏃‍♂️🌤️",
            mediaUrls = listOf("https://images.unsplash.com/photo-1476480862126-209bfaa8edc8?w=800&auto=format&fit=crop&q=80"),
            likes = listOf("user_me", "user_arty"),
            commentsCount = 9,
            sharesCount = 3,
            createdAt = "8 ชั่วโมงที่แล้ว",
            tags = listOf("สายวิ่ง", "สุขภาพดี", "RunningCommunity")
        )
    )

    val initialStories = listOf(
        Story(
            id = "story_linlin",
            authorId = "user_linlin",
            mediaUrl = "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=600&auto=format&fit=crop&q=80",
            caption = "ซ้อมกีตาร์ก่อนขึ้นไลฟ์ 🎸✨",
            createdAt = "1 ชั่วโมงที่แล้ว"
        ),
        Story(
            id = "story_arty",
            authorId = "user_arty",
            mediaUrl = "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=600&auto=format&fit=crop&q=80",
            caption = "จัดห้องสตรีมใหม่ สวยมั้ยทุกคน 🔥",
            createdAt = "3 ชั่วโมงที่แล้ว"
        ),
        Story(
            id = "story_fah",
            authorId = "user_fah",
            mediaUrl = "https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=600&auto=format&fit=crop&q=80",
            caption = "เจอน้องแมวส้มอ้อนสุดๆ 🐾",
            createdAt = "4 ชั่วโมงที่แล้ว"
        ),
        Story(
            id = "story_ploy",
            authorId = "user_ploy",
            mediaUrl = "https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?w=600&auto=format&fit=crop&q=80",
            caption = "วิวดอยอินทนนท์เช้านี้ หมอกขาวสวยมาก ⛰️",
            createdAt = "6 ชั่วโมงที่แล้ว"
        )
    )

    val initialLiveRooms = listOf(
        LiveRoom(
            id = "live_linlin",
            hostId = "user_linlin",
            title = "🎙️ ร้องเพลงตามใจคนดู & พูดคุยคลายเหงาคืนวันจันทร์ 🌸",
            coverUrl = "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=800&auto=format&fit=crop&q=80",
            category = "ดนตรีและร้องเพลง",
            isLive = true,
            viewersCount = 1420,
            currentGiftCoins = 12450,
            heartsCount = 8930,
            tags = listOf("ร้องเพลง", "acoustic", "เพลงไทย"),
            isPkMode = false,
            startedAt = "15 นาทีที่แล้ว"
        ),
        LiveRoom(
            id = "live_arty",
            hostId = "user_arty",
            title = "⚡ PK BATTLE สุดมันส์! อาร์ตี้ vs น้องฟ้าใส ใครจะชนะมาช่วยดัน 🚀",
            coverUrl = "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800&auto=format&fit=crop&q=80",
            category = "เกม & PK Battle",
            isLive = true,
            viewersCount = 2850,
            currentGiftCoins = 38900,
            heartsCount = 24100,
            tags = listOf("PKBattle", "เกมเมอร์", "ดวลของขวัญ"),
            isPkMode = true,
            pkOpponent = PkOpponent(
                hostId = "user_fah",
                score = 34200,
                streamUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=500&auto=format&fit=crop&q=80"
            ),
            pkScore = 38900,
            startedAt = "25 นาทีที่แล้ว"
        ),
        LiveRoom(
            id = "live_bank",
            hostId = "user_bank",
            title = "💪 ตอบคำถามฟิตเนส ปั้นหุ่น ลดพุง สร้างกล้ามเนื้อ สบายๆ 🥗",
            coverUrl = "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=800&auto=format&fit=crop&q=80",
            category = "สุขภาพและไลฟ์สไตล์",
            isLive = true,
            viewersCount = 460,
            currentGiftCoins = 3400,
            heartsCount = 5200,
            tags = listOf("ฟิตเนส", "ลดน้ำหนัก", "สุขภาพ"),
            isPkMode = false,
            startedAt = "40 นาทีที่แล้ว"
        )
    )

    val initialClubs = listOf(
        Club(
            id = "club_singles",
            name = "คนโสดวัยทำงาน หาเพื่อนคุยจริงใจ",
            description = "คลับพื้นที่ปลอดภัยสำหรับคนโสดวัย 20-35 ปี พูดคุย แลกเปลี่ยนไลฟ์สไตล์ ไม่กดดัน",
            coverImage = "https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=800&auto=format&fit=crop&q=80",
            memberCount = 8420,
            category = "หาคู่ & เพื่อนคุย",
            members = listOf("user_me", "user_linlin", "user_fah"),
            icon = "💕"
        ),
        Club(
            id = "club_cafe",
            name = "คาเฟ่ฮอปปิ้ง & ถ่ายรูปทั่วไทย",
            description = "แชร์พิกัดคาเฟ่สวย กาแฟดี เมนูของหวาน แนะนำมุมถ่ายรูปและนัดไปจอยกัน",
            coverImage = "https://images.unsplash.com/photo-1554118811-1e0d58224f24?w=800&auto=format&fit=crop&q=80",
            memberCount = 12500,
            category = "อาหาร & ท่องเที่ยว",
            members = listOf("user_me", "user_fah", "user_ploy"),
            icon = "☕"
        ),
        Club(
            id = "club_gaming",
            name = "ROV & MOBA Thailand Guild",
            description = "หาตี้ลงแรงก์ แลกเปลี่ยนเทคนิค จัดทีมแข่ง และชวนเล่นเกมกันทุกวัน",
            coverImage = "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800&auto=format&fit=crop&q=80",
            memberCount = 18900,
            category = "เกม & อีสปอร์ต",
            members = listOf("user_me", "user_arty"),
            icon = "🎮"
        ),
        Club(
            id = "club_fitness",
            name = "สายฟิต & มาราธอน แข็งแรงไปด้วยกัน",
            description = "ชมรมคนรักการวิ่ง เวทเทรนนิ่ง และคุมอาหาร แบ่งปันโปรแกรมซ้อมและผลลัพธ์",
            coverImage = "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=800&auto=format&fit=crop&q=80",
            memberCount = 6300,
            category = "กีฬา & สุขภาพ",
            members = listOf("user_me", "user_bank"),
            icon = "🏃"
        )
    )

    val initialConversations = listOf(
        Conversation(
            id = "conv_linlin",
            type = "direct",
            participantIds = listOf("user_me", "user_linlin"),
            unreadCounts = mapOf("user_me" to 1),
            updatedAt = "10 นาทีที่แล้ว",
            lastMessage = ChatMessage(
                id = "m_last_linlin",
                conversationId = "conv_linlin",
                senderId = "user_linlin",
                text = "ขอบคุณสำหรับของขวัญกุหลาบเมื่อกี้นะคะต้นกล้า! 🌹 น่ารักมากเลย",
                createdAt = "10 นาทีที่แล้ว",
                isRead = false
            )
        ),
        Conversation(
            id = "conv_fah",
            type = "direct",
            participantIds = listOf("user_me", "user_fah"),
            unreadCounts = mapOf("user_me" to 0),
            updatedAt = "1 ชั่วโมงที่แล้ว",
            lastMessage = ChatMessage(
                id = "m_last_fah",
                conversationId = "conv_fah",
                senderId = "user_me",
                text = "ร้านคาเฟ่นั้นเดินทางสะดวกไหมครับ เดี๋ยวเสาร์นี้ว่าจะลองแวะไป",
                createdAt = "1 ชั่วโมงที่แล้ว",
                isRead = true
            )
        ),
        Conversation(
            id = "conv_group_chill",
            type = "group",
            name = "แก๊งคาเฟ่ & ตะลุยชิม 🍰",
            avatar = "https://images.unsplash.com/photo-1554118811-1e0d58224f24?w=400&auto=format&fit=crop&q=80",
            participantIds = listOf("user_me", "user_fah", "user_ploy", "user_linlin"),
            unreadCounts = mapOf("user_me" to 3),
            updatedAt = "20 นาทีที่แล้ว",
            createdBy = "user_fah",
            groupAdmins = listOf("user_fah"),
            lastMessage = ChatMessage(
                id = "m_last_group",
                conversationId = "conv_group_chill",
                senderId = "user_ploy",
                text = "เสาร์นี้บ่ายโมงเจอกันที่ร้านนะทุกคน ใครมาสายเลี้ยงเค้ก! 😋",
                createdAt = "20 นาทีที่แล้ว",
                isRead = false
            )
        )
    )

    val initialMessages = listOf(
        ChatMessage(
            id = "m_1",
            conversationId = "conv_linlin",
            senderId = "user_me",
            text = "สวัสดีครับน้องหลิน เพลงที่ร้องเมื่อคืนเพราะมากเลยครับ 🎸✨",
            createdAt = "15 นาทีที่แล้ว",
            isRead = true
        ),
        ChatMessage(
            id = "m_2",
            conversationId = "conv_linlin",
            senderId = "user_me",
            text = "ส่งของขวัญให้กำลังใจนะคร้าบ",
            type = MessageType.GIFT,
            giftInfo = GiftInfo("gift_rose", "ดอกกุหลาบหวาน", "🌹", 1),
            createdAt = "12 นาทีที่แล้ว",
            isRead = true
        ),
        ChatMessage(
            id = "m_3",
            conversationId = "conv_linlin",
            senderId = "user_linlin",
            text = "ขอบคุณสำหรับของขวัญกุหลาบเมื่อกี้นะคะต้นกล้า! 🌹 น่ารักมากเลย",
            createdAt = "10 นาทีที่แล้ว",
            isRead = false
        )
    )

    val initialForumTopics = listOf(
        ForumTopic(
            id = "topic_1",
            clubId = "club_singles",
            authorId = "user_linlin",
            title = "สเปกคนที่ทำให้คุณตกหลุมรักตั้งแต่แรกพบเป็นยังไงกันบ้างคะ? 💭",
            content = "สำหรับหลินคือคนที่ยิ้มเก่ง มองโลกในแง่บวก และเป็นผู้ฟังที่ดีค่ะ แล้วเพื่อนๆ ในคลับชอบคนแบบไหนกัน มาแชร์กันหน่อยน้า",
            likes = listOf("user_me", "user_fah"),
            commentsCount = 32,
            createdAt = "2 ชั่วโมงที่แล้ว"
        ),
        ForumTopic(
            id = "topic_2",
            clubId = "club_cafe",
            authorId = "user_fah",
            title = "รวม 5 คาเฟ่แสงสวย สำหรับสายถ่ายรูปพอร์ตเทรตแถวทองหล่อ-เอกมัย 📸✨",
            content = "ใครที่ชอบถ่ายรูปฟีลเกาหลี แสงธรรมชาติ แนะนำร้าน Craft Coffee, Little Summer, และ The Glass House เลยค่ะ มีมุมกระจกสวยมาก",
            likes = listOf("user_me", "user_ploy"),
            commentsCount = 18,
            createdAt = "4 ชั่วโมงที่แล้ว"
        )
    )

    val initialReports = listOf(
        Report(
            id = "rep_1",
            reporterId = "user_fah",
            targetType = "user",
            targetId = "user_spammer",
            reason = "บัญชีสแปม / โฆษณาพนันออนไลน์ผิดกฎหมาย",
            details = "ส่งข้อความสแปมชวนเล่นพนันในแชตและคอมเมนต์ฟีด",
            status = "pending",
            createdAt = "2 ชั่วโมงที่แล้ว"
        ),
        Report(
            id = "rep_2",
            reporterId = "user_ploy",
            targetType = "post",
            targetId = "post_fake_promo",
            reason = "เนื้อหาหลอกลวง",
            details = "มีลิงก์แจกเงินน่าสงสัย",
            status = "action_taken",
            createdAt = "1 วันที่แล้ว",
            actionNote = "ลบโพสต์และตักเตือนผู้ใช้แล้ว"
        )
    )

    val initialWithdrawals = listOf(
        WithdrawalRequest(
            id = "wd_1",
            creatorId = "user_linlin",
            amountCoins = 10000,
            amountBaht = 5000,
            bankName = "ธนาคารกสิกรไทย (KBANK)",
            accountNumber = "045-8-12948-2",
            accountName = "น.ส. ลินลดา ศิริโชค",
            status = "pending",
            createdAt = "3 ชั่วโมงที่แล้ว"
        ),
        WithdrawalRequest(
            id = "wd_2",
            creatorId = "user_arty",
            amountCoins = 20000,
            amountBaht = 10000,
            bankName = "ธนาคารไทยพาณิชย์ (SCB)",
            accountNumber = "112-9-88741-0",
            accountName = "นาย ธาวิน พงษ์ไพศาล",
            status = "approved",
            createdAt = "2 วันที่แล้ว",
            adminNote = "อนุมัติเรียบร้อย รอดำเนินการโอนรอบถัดไป"
        )
    )

    val initialAdminLogs = listOf(
        AdminLog(
            id = "log_1",
            adminId = "user_admin",
            adminName = "Official Admin",
            action = "ตรวจความปลอดภัยระบบ",
            targetType = "system",
            targetId = "firewall",
            details = "ตรวจสอบบันทึกความปลอดภัยประจำวัน ระบบทำงานปกติ",
            timestamp = "1 วันที่แล้ว"
        )
    )

    val initialNotifications = listOf(
        AppNotification(
            id = "notif_1",
            userId = "user_me",
            title = "หลินหลิน กำลังไลฟ์สด 🔴",
            body = "มาร่วมร้องเพลงและพูดคุยในไลฟ์ตอนนี้เลย!",
            type = "live",
            linkTab = "live",
            isRead = false,
            createdAt = "15 นาทีที่แล้ว"
        ),
        AppNotification(
            id = "notif_2",
            userId = "user_me",
            title = "ข้อความใหม่จาก น้องหลินหลิน 🌸",
            body = "ขอบคุณสำหรับของขวัญกุหลาบนะคะ!",
            type = "comment",
            linkTab = "chat",
            isRead = false,
            createdAt = "10 นาทีที่แล้ว"
        ),
        AppNotification(
            id = "notif_3",
            userId = "user_me",
            title = "ยินดีต้อนรับสู่ FriendTalk! 🎉",
            body = "คุณได้รับ 1,500 Coins เริ่มต้น สำหรับส่งของขวัญและหาเพื่อนใหม่",
            type = "system",
            linkTab = "home",
            isRead = true,
            createdAt = "เมื่อวานนี้"
        )
    )
}
