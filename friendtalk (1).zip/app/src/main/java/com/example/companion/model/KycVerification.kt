package com.example.companion.model

/**
 * ข้อมูลการยืนยันตัวตน (KYC) ด้วยบัตรประชาชน + สแกนใบหน้า
 */
data class KycVerificationInfo(
    val idCardNumberMasked: String, // เช่น 1-1004-XXXXX-XX-1
    val idCardPhotoUrl: String,
    val faceScanPhotoUrl: String,
    val birthYear: Int,
    val verifiedAge: Int,
    val isIdentityVerified: Boolean = false,
    val verifiedAt: String? = null,
    val automatedScreening: AutomatedScreeningResult = AutomatedScreeningResult()
)

/**
 * ผลการคัดกรองอัตโนมัติเบื้องต้น (Automated Pre-Screening)
 * ตามกฎข้อ 9: ระบบอัตโนมัติช่วยตรวจเบื้องต้น เคสเสี่ยงให้ส่งเข้า Manual Review
 * ห้ามระบบอัตโนมัติแบนถาวรโดยไม่มี Review แอดมินต้องเป็นผู้ตัดสินใจขั้นสุดท้าย
 */
data class AutomatedScreeningResult(
    val riskScore: Double = 0.05, // 0.0 (ปลอดภัยมาก) ถึง 1.0 (เสี่ยงสูง)
    val isFlaggedForManualReview: Boolean = false,
    val automatedCheckNotes: List<String> = listOf(
        "ภาพบัตรประชาชนคมชัด ผ่านเกณฑ์",
        "คะแนนความตรงกันของใบหน้า (Face Match) 98.4%",
        "อายุตามฐานข้อมูล 18 ปีขึ้นไป"
    ),
    val spamRisk: Boolean = false,
    val duplicateAccountRisk: Boolean = false
)
