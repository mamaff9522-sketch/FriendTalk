package com.example.companion.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.companion.model.*
import com.example.model.User
import com.example.model.UserRole
import com.example.service.SoundService
import com.example.ui.theme.*

@Composable
fun CompanionMainScreen(
    currentUser: User,
    profiles: List<CompanionProfile>,
    pricingConfig: CompanionPricingConfig,
    wallets: Map<String, CompanionWallet>,
    giftRequests: List<CompanionGiftRequest>,
    auditLogs: List<CompanionAdminAuditLog>,
    safetyReports: List<CompanionSafetyReport>,
    userKycInfo: KycVerificationInfo?,
    onOpenCoinTopUp: () -> Unit,
    onDeductCoinsFromUser: (Int) -> Unit,
    onApplyCompanion: (CompanionProfile) -> Unit,
    onApproveCompanion: (String, String) -> Unit,
    onRejectCompanion: (String, String) -> Unit,
    onSuspendCompanion: (String, String) -> Unit,
    onUpdateRates: (CompanionLevel, Int, Int, Int, String) -> Unit,
    onRecalculateLevel: (String) -> Unit,
    onSendGiftRequest: (CompanionGiftRequest) -> Unit,
    onRespondGiftRequest: (requestId: String, accept: Boolean) -> Pair<Boolean, CompanionGiftRequest?>,
    onSessionCompleted: (session: CompanionSession, earnings: Int, rating: Int?, comment: String?) -> Unit,
    onCompanionWithdrawal: (companionId: String, companionName: String, amount: Int, bankAccount: CompanionBankAccount) -> Boolean,
    onLogAdminAudit: (action: String, targetType: String, targetId: String, justification: String) -> Unit,
    onKycCompleted: (KycVerificationInfo) -> Unit,
    modifier: Modifier = Modifier
) {
    // กฎข้อ 1: ผู้ใช้อายุต่ำกว่า 18 ปี ห้ามเห็นเมนู “เพื่อนคุย” ห้ามสมัครเป็นเพื่อนคุย ห้ามใช้ฟังก์ชันเพื่อนคุยทุกกรณี
    if (currentUser.age < 18) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(Slate950)
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(RosePrimary.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Block, contentDescription = null, tint = RosePrimary, modifier = Modifier.size(36.dp))
                }
                Text("จำกัดสิทธิ์เฉพาะผู้ใช้ 18 ปีขึ้นไป", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
                Text(
                    "ระบบเพื่อนคุยถูกสงวนไว้สำหรับผู้ใช้อายุ 18 ปีขึ้นไปเท่านั้น เพื่อความปลอดภัยและการปฏิบัติตามกฎหมายอย่างเคร่งครัด",
                    fontSize = 12.sp,
                    color = Slate400,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    lineHeight = 18.sp
                )
            }
        }
        return
    }

    var searchQuery by remember { mutableStateOf("") }
    var selectedLevelFilter by remember { mutableStateOf<CompanionLevel?>(null) }

    // Dialog controllers
    var isKycDialogOpen by remember { mutableStateOf(false) }
    var isApplyDialogOpen by remember { mutableStateOf(false) }
    var isWalletOpen by remember { mutableStateOf(false) }
    var isAdminOpen by remember { mutableStateOf(false) }
    var giftTargetCompanion by remember { mutableStateOf<CompanionProfile?>(null) }

    // Active Session Controller
    var activeSessionCompanion by remember { mutableStateOf<CompanionProfile?>(null) }
    var activeSessionType by remember { mutableStateOf(CompanionSessionType.TEXT) }
    var activeSessionRate by remember { mutableStateOf(10) }
    var isSessionActive by remember { mutableStateOf(false) }

    // Check if current user is an existing companion
    val myCompanionProfile = profiles.find { it.userId == currentUser.id }
    val myCompanionWallet = if (myCompanionProfile != null) wallets[myCompanionProfile.id] else null

    // Filtered Companions:
    // กฎข้อ 3: แสดงเฉพาะเพื่อนคุยที่ APPROVED และ ONLINE
    val approvedOnlineCompanions = remember(profiles, searchQuery, selectedLevelFilter) {
        profiles.filter {
            it.status == CompanionStatus.APPROVED &&
                    it.isOnline &&
                    it.userId != currentUser.id && // ไม่แสดงตัวเอง
                    (selectedLevelFilter == null || it.level == selectedLevelFilter) &&
                    (searchQuery.isBlank() ||
                            it.displayName.contains(searchQuery, ignoreCase = true) ||
                            it.introBio.contains(searchQuery, ignoreCase = true) ||
                            it.languages.any { lang -> lang.contains(searchQuery, ignoreCase = true) })
        }
    }

    // Check for incoming gift requests for the current user
    val pendingIncomingGiftRequests = giftRequests.filter {
        it.receiverId == currentUser.id && it.status == GiftRequestStatus.PENDING
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(10.dp))

            // Hero Banner / Companion Header
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Slate900,
                border = androidx.compose.foundation.BorderStroke(1.dp, PinkPrimary.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.horizontalGradient(
                                listOf(
                                    PinkPrimary.copy(alpha = 0.15f),
                                    RosePrimary.copy(alpha = 0.08f),
                                    Slate900
                                )
                            )
                        )
                        .padding(16.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(PinkPrimary),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Favorite, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                                }
                                Column {
                                    Text("เพื่อนคุย (Friend Companion)", fontWeight = FontWeight.Black, fontSize = 16.sp, color = Color.White)
                                    Text("รับฟัง ให้คำปรึกษา แชร์รอยยิ้ม 18+", fontSize = 11.sp, color = PinkLight)
                                }
                            }

                            // Coins Badge
                            Surface(
                                onClick = onOpenCoinTopUp,
                                color = AmberGold.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(20.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, AmberGold.copy(alpha = 0.4f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text("🪙", fontSize = 12.sp)
                                    Text(
                                        text = "${currentUser.coins}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = AmberLight
                                    )
                                    Text("+", fontSize = 11.sp, fontWeight = FontWeight.Black, color = AmberGold)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Quick Actions Bar (Apply, Wallet, Admin, KYC)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (myCompanionProfile == null) {
                                Button(
                                    onClick = { isApplyDialogOpen = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                                    shape = RoundedCornerShape(10.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Icon(Icons.Default.VolunteerActivism, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("สมัครเป็นเพื่อนคุย", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            } else if (myCompanionProfile.status == CompanionStatus.PENDING_REVIEW) {
                                Surface(
                                    color = AmberGold.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(10.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, AmberGold)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Text("⏳ รอ Admin ตรวจสอบ", color = AmberGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            } else if (myCompanionProfile.status == CompanionStatus.APPROVED) {
                                Button(
                                    onClick = { isWalletOpen = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = AmberGold),
                                    shape = RoundedCornerShape(10.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, tint = Slate950, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("กระเป๋ารายได้ของฉัน", color = Slate950, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            if (userKycInfo?.isIdentityVerified != true && !currentUser.isVerified) {
                                OutlinedButton(
                                    onClick = { isKycDialogOpen = true },
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = EmeraldGreen),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldGreen.copy(alpha = 0.6f)),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text("ยืนยันตัวตน KYC", fontSize = 11.sp)
                                }
                            }

                            if (currentUser.role == UserRole.ADMIN || currentUser.role == UserRole.SUPERADMIN) {
                                Button(
                                    onClick = { isAdminOpen = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = Slate800),
                                    shape = RoundedCornerShape(10.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Icon(Icons.Default.Security, contentDescription = null, tint = AmberGold, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("ดูแลระบบ (Admin)", color = AmberGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Incoming Prominent Gift Requests (if any)
        // กฎข้อ 7: ผู้รับเห็นคำขอแบบเด่น ผู้รับตัดสินใจเอง
        if (pendingIncomingGiftRequests.isNotEmpty()) {
            items(pendingIncomingGiftRequests) { greq ->
                CompanionIncomingGiftRequestCard(
                    request = greq,
                    onAccept = {
                        val (success, updated) = onRespondGiftRequest(greq.id, true)
                        if (success && updated != null) {
                            SoundService.playMatch()
                            // เปิดเริ่มแชททันที
                            val senderProfile = profiles.find { it.userId == greq.senderId }
                            if (senderProfile != null) {
                                activeSessionCompanion = senderProfile
                                activeSessionType = CompanionSessionType.TEXT
                                activeSessionRate = 0 // ฟรีเนื่องจากเปิดผ่านของขวัญ
                                isSessionActive = true
                            }
                        }
                    },
                    onReject = {
                        onRespondGiftRequest(greq.id, false)
                        SoundService.playPop()
                    }
                )
            }
        }

        // Search & Filter Row
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("ค้นหาชื่อ, ภาษา หรือแนวการพูดคุย...", fontSize = 12.sp) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Slate400, modifier = Modifier.size(18.dp)) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PinkPrimary,
                    unfocusedBorderColor = Slate800,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Level Filter Chips
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    FilterChip(
                        selected = selectedLevelFilter == null,
                        onClick = { selectedLevelFilter = null },
                        label = { Text("ทั้งหมด (${approvedOnlineCompanions.size})", fontSize = 11.sp) }
                    )
                }
                items(CompanionLevel.values().toList()) { level ->
                    val isSelected = selectedLevelFilter == level
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedLevelFilter = if (isSelected) null else level },
                        label = {
                            Text(
                                level.name,
                                fontSize = 11.sp,
                                color = if (isSelected) Color.White else Color(level.badgeColorHex)
                            )
                        }
                    )
                }
            }
        }

        // Companion Directory List (กฎข้อ 3)
        if (approvedOnlineCompanions.isEmpty()) {
            item {
                Surface(
                    color = Slate900,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.PeopleOutline, contentDescription = null, tint = Slate600, modifier = Modifier.size(36.dp))
                        Text("ไม่พบเพื่อนคุยที่ตรงกับเงื่อนไข", fontWeight = FontWeight.Bold, color = Slate400, fontSize = 13.sp)
                        Text("ลองเปลี่ยนคำค้นหา หรือรีเซ็ตตัวกรอง Level", color = Slate500, fontSize = 11.sp)
                    }
                }
            }
        } else {
            items(approvedOnlineCompanions) { comp ->
                CompanionDirectoryCard(
                    companion = comp,
                    pricingConfig = pricingConfig,
                    clientCoins = currentUser.coins,
                    onStartSession = { type ->
                        val rate = pricingConfig.getRate(comp.level, type)
                        if (currentUser.coins < rate) {
                            SoundService.playPop()
                            onOpenCoinTopUp()
                        } else {
                            activeSessionCompanion = comp
                            activeSessionType = type
                            activeSessionRate = rate
                            isSessionActive = true
                        }
                    },
                    onOpenGiftRequest = {
                        giftTargetCompanion = comp
                    }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(70.dp))
        }
    }

    // KYC Dialog
    CompanionKycDialog(
        isOpen = isKycDialogOpen,
        currentUser = currentUser,
        onClose = { isKycDialogOpen = false },
        onKycCompleted = { kyc ->
            onKycCompleted(kyc)
            SoundService.playMatch()
        }
    )

    // Companion Application Dialog
    CompanionApplyDialog(
        isOpen = isApplyDialogOpen,
        currentUser = currentUser,
        existingProfile = myCompanionProfile,
        kycInfo = userKycInfo,
        onOpenKycDialog = {
            isApplyDialogOpen = false
            isKycDialogOpen = true
        },
        onClose = { isApplyDialogOpen = false },
        onSubmitApplication = { profile ->
            onApplyCompanion(profile)
            SoundService.playMatch()
        }
    )

    // Companion Wallet Dialog
    CompanionWalletSheet(
        isOpen = isWalletOpen,
        companion = myCompanionProfile,
        wallet = myCompanionWallet,
        onClose = { isWalletOpen = false },
        onRequestWithdrawal = { amt, bankAccount ->
            if (myCompanionProfile != null) {
                onCompanionWithdrawal(myCompanionProfile.id, myCompanionProfile.displayName, amt, bankAccount)
            } else false
        }
    )

    // Companion Gift Request Dialog
    CompanionGiftRequestDialog(
        isOpen = giftTargetCompanion != null,
        targetCompanion = giftTargetCompanion,
        currentUser = currentUser,
        onClose = { giftTargetCompanion = null },
        onTopUpCoins = onOpenCoinTopUp,
        onSendGiftRequest = { req ->
            onSendGiftRequest(req)
            giftTargetCompanion = null
        }
    )

    // Companion Admin Dialog
    CompanionAdminDialog(
        isOpen = isAdminOpen,
        adminUser = currentUser,
        profiles = profiles,
        pricingConfig = pricingConfig,
        wallets = wallets,
        giftRequests = giftRequests,
        auditLogs = auditLogs,
        safetyReports = safetyReports,
        onClose = { isAdminOpen = false },
        onApproveCompanion = onApproveCompanion,
        onRejectCompanion = onRejectCompanion,
        onSuspendCompanion = onSuspendCompanion,
        onUpdateRates = onUpdateRates,
        onRecalculateLevel = onRecalculateLevel,
        onLogAudit = { action, type, id, justification ->
            onLogAdminAudit(action, type, id, justification)
        }
    )

    // Active Session Dialog (Text / Voice / Video with real-time timer & credit deduction)
    CompanionSessionActiveDialog(
        isOpen = isSessionActive,
        companion = activeSessionCompanion,
        sessionType = activeSessionType,
        currentUser = currentUser,
        rateCoinsPerMinute = activeSessionRate,
        onClose = { isSessionActive = false },
        onTopUpCoinsRequested = onOpenCoinTopUp,
        onDeductCoinsFromUser = onDeductCoinsFromUser,
        onSessionCompleted = { session, earnings, rating, comment ->
            onSessionCompleted(session, earnings, rating, comment)
            isSessionActive = false
        }
    )
}

/**
 * การ์ดแสดงโปรไฟล์เพื่อนคุยสำหรับคนที่ต้องการหาเพื่อนคุย (กฎข้อ 3)
 */
@Composable
private fun CompanionDirectoryCard(
    companion: CompanionProfile,
    pricingConfig: CompanionPricingConfig,
    clientCoins: Int,
    onStartSession: (CompanionSessionType) -> Unit,
    onOpenGiftRequest: () -> Unit
) {
    val textRate = pricingConfig.getRate(companion.level, CompanionSessionType.TEXT)
    val voiceRate = pricingConfig.getRate(companion.level, CompanionSessionType.VOICE)
    val videoRate = pricingConfig.getRate(companion.level, CompanionSessionType.VIDEO)

    Surface(
        shape = RoundedCornerShape(20.dp),
        color = Slate900,
        border = androidx.compose.foundation.BorderStroke(1.dp, Slate800),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Top Row: Avatar, Name, Age, Status Ready Now, Rating & Level
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .clip(CircleShape)
                            .border(2.dp, Color(companion.level.badgeColorHex), CircleShape)
                    ) {
                        AsyncImage(
                            model = companion.avatar,
                            contentDescription = companion.displayName,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = companion.displayName,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = Color.White
                            )

                            // Level Badge
                            Surface(
                                color = Color(companion.level.badgeColorHex).copy(alpha = 0.2f),
                                shape = RoundedCornerShape(4.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(companion.level.badgeColorHex))
                            ) {
                                Text(
                                    text = companion.level.name,
                                    color = Color(companion.level.badgeColorHex),
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                )
                            }
                        }

                        // Age & Languages
                        Text(
                            text = "อายุ ${companion.age} ปี • ภาษา: ${companion.languages.joinToString(", ")}",
                            fontSize = 11.sp,
                            color = Slate400
                        )

                        // Rating & Sessions count
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.padding(top = 2.dp)
                        ) {
                            Icon(Icons.Default.Star, contentDescription = null, tint = AmberGold, modifier = Modifier.size(13.dp))
                            Text(
                                text = String.format("%.2f", companion.rating),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = AmberGold
                            )
                            Text(
                                text = "(${companion.reviewCount} รีวิว) • คุยแล้ว ${companion.totalSessionsCount} คน",
                                fontSize = 10.sp,
                                color = Slate400
                            )
                        }
                    }
                }

                // Ready Now Status Badge (กฎข้อ 3)
                if (companion.isReadyNow) {
                    Surface(
                        color = EmeraldGreen.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldGreen.copy(alpha = 0.5f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(EmeraldGreen))
                            Text("พร้อมคุยตอนนี้", color = EmeraldGreen, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Intro Bio (คำแนะนำตัว)
            Text(
                text = companion.introBio,
                fontSize = 12.sp,
                color = Slate200,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Rates Info Banner (กำหนดตาม Level - ไม่ให้ผู้ใช้ตั้งเอง)
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = Slate950,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Text("💬 แชต: $textRate 🪙/นาที", fontSize = 10.sp, color = Slate300)
                    Text("📞 เสียง: $voiceRate 🪙/นาที", fontSize = 10.sp, color = Slate300)
                    Text("📹 วิดีโอ: $videoRate 🪙/นาที", fontSize = 10.sp, color = Slate300)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action Buttons: เริ่มแชท, โทรเสียง, วิดีโอคอล, ขอคุยด้วยของขวัญ (กฎข้อ 3 & 7)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Text Chat
                Button(
                    onClick = { onStartSession(CompanionSessionType.TEXT) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Slate800),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.ChatBubbleOutline, contentDescription = null, tint = PinkLight, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("แชท", fontSize = 11.sp, color = Color.White)
                }

                // Voice Call
                Button(
                    onClick = { onStartSession(CompanionSessionType.VOICE) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Slate800),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Phone, contentDescription = null, tint = EmeraldGreen, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("โทรเสียง", fontSize = 11.sp, color = Color.White)
                }

                // Video Call
                Button(
                    onClick = { onStartSession(CompanionSessionType.VIDEO) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Videocam, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("วิดีโอคอล", fontSize = 11.sp, color = Color.White)
                }

                // Gift Request
                IconButton(
                    onClick = onOpenGiftRequest,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(AmberGold.copy(alpha = 0.2f))
                        .border(1.dp, AmberGold.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                ) {
                    Icon(Icons.Default.CardGiftcard, contentDescription = "ส่งของขวัญขอคุย", tint = AmberGold, modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}
