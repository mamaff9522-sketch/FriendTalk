package com.example.companion.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.companion.model.CompanionLevel
import com.example.companion.model.CompanionProfile
import com.example.companion.model.CompanionStatus
import com.example.companion.model.KycVerificationInfo
import com.example.model.User
import com.example.ui.theme.*

@Composable
fun CompanionApplyDialog(
    isOpen: Boolean,
    currentUser: User,
    existingProfile: CompanionProfile?,
    kycInfo: KycVerificationInfo?,
    onOpenKycDialog: () -> Unit,
    onClose: () -> Unit,
    onSubmitApplication: (CompanionProfile) -> Unit
) {
    if (!isOpen) return

    val isUnder18 = currentUser.age < 18
    val isKycVerified = kycInfo?.isIdentityVerified == true || currentUser.isVerified

    var introBio by remember { mutableStateOf(existingProfile?.introBio ?: "ยินดีรับฟังและพูดคุยอย่างเป็นกันเอง พร้อมให้คำปรึกษาและแลกเปลี่ยนเรื่องราวดีๆ ครับ/ค่ะ ✨") }
    var languagesText by remember { mutableStateOf("ไทย, English") }
    var tagListening by remember { mutableStateOf(true) }
    var tagFriendly by remember { mutableStateOf(true) }
    var tagConsult by remember { mutableStateOf(true) }
    var agreedCodeOfConduct by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .wrapContentHeight(),
            shape = RoundedCornerShape(24.dp),
            color = Slate900,
            border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(PinkPrimary.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.VolunteerActivism, contentDescription = null, tint = PinkLight, modifier = Modifier.size(20.dp))
                        }
                        Column {
                            Text("สมัครเป็น \"เพื่อนคุย\"", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
                            Text("ร่วมเป็นผู้รับฟัง สร้างรายได้ตาม Level", fontSize = 11.sp, color = Slate400)
                        }
                    }

                    IconButton(onClick = onClose) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Slate400)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Condition 1: Check Age >= 18
                if (isUnder18) {
                    Surface(
                        color = RosePrimary.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, RosePrimary.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Block, contentDescription = null, tint = RosePrimary)
                            Text(
                                "ผู้ใช้อายุต่ำกว่า 18 ปี ไม่สามารถสมัครเป็นเพื่อนคุย หรือใช้งานระบบเพื่อนคุยได้ทุกกรณี เพื่อความปลอดภัยตามกฎหมาย",
                                color = RoseLight,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                    Button(onClick = onClose, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Slate800)) {
                        Text("ตกลงและปิด")
                    }
                    return@Column
                }

                // Condition 2: KYC Verified Check
                if (!isKycVerified) {
                    Surface(
                        color = AmberGold.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, AmberGold.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = AmberGold)
                                Text("ต้องยืนยันตัวตน (KYC) ก่อนสมัคร", color = AmberLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            Text(
                                "ระบบเพื่อนคุยต้องยืนยันด้วยบัตรประชาชนและสแกนใบหน้า เพื่อความปลอดภัยและความโปร่งใส",
                                color = Slate300,
                                fontSize = 11.sp
                            )
                            Button(
                                onClick = onOpenKycDialog,
                                colors = ButtonDefaults.buttonColors(containerColor = AmberGold),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("ไปยืนยันตัวตน KYC ทันที", color = Slate950, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                } else {
                    Surface(
                        color = EmeraldGreen.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldGreen, modifier = Modifier.size(16.dp))
                            Text("ยืนยันตัวตน KYC เรียบร้อย (อายุ ${currentUser.age} ปี)", color = EmeraldGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                }

                // If already submitted and in PENDING_REVIEW
                if (existingProfile?.status == CompanionStatus.PENDING_REVIEW) {
                    Surface(
                        color = AmberGold.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, AmberGold),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("⏳ สถานะ: รอการตรวจสอบ (PENDING_REVIEW)", color = AmberGold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(
                                "คำขอของคุณอยู่ระหว่างการตรวจเอกสารและข้อมูลโดย Admin\n\n⚠️ ระหว่างรอตรวจ: ระบบจะยังไม่เปิดรับคนคุย และไม่สามารถสร้างรายได้ได้ จนกว่า Admin จะอนุมัติ",
                                color = Slate200,
                                fontSize = 11.sp,
                                lineHeight = 16.sp
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                    Button(onClick = onClose, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Slate800)) {
                        Text("เข้าใจแล้ว")
                    }
                    return@Column
                }

                // Application Form Inputs
                Text("คำแนะนำตัวของคุณ (Bio)", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = introBio,
                    onValueChange = { introBio = it },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PinkPrimary,
                        unfocusedBorderColor = Slate700,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text("ภาษาที่สื่อสารได้ (คั่นด้วยจุลภาค)", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = languagesText,
                    onValueChange = { languagesText = it },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PinkPrimary,
                        unfocusedBorderColor = Slate700,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text("จุดเด่น / แท็ก", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = tagListening,
                        onClick = { tagListening = !tagListening },
                        label = { Text("รับฟังเก่ง", fontSize = 10.sp) }
                    )
                    FilterChip(
                        selected = tagFriendly,
                        onClick = { tagFriendly = !tagFriendly },
                        label = { Text("เป็นกันเอง", fontSize = 10.sp) }
                    )
                    FilterChip(
                        selected = tagConsult,
                        onClick = { tagConsult = !tagConsult },
                        label = { Text("ให้คำปรึกษา", fontSize = 10.sp) }
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Important System Notice
                Surface(
                    color = Slate950,
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Slate800),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("📌 เงื่อนไขสำคัญ:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = PinkLight)
                        Text("• ผู้ใช้ไม่สามารถตั้งราคาเองได้ ระบบจะกำหนดเรตตาม Level (เริ่มต้นที่ STARTER)", fontSize = 10.sp, color = Slate400)
                        Text("• หลังส่งใบสมัคร สถานะจะถูกตั้งเป็น PENDING_REVIEW", fontSize = 10.sp, color = Slate400)
                        Text("• ระหว่างรอตรวจ ห้ามเปิดรับคนคุยและห้ามรับรายได้ จนกว่า Admin จะอนุมัติ", fontSize = 10.sp, color = Slate400)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = agreedCodeOfConduct,
                        onCheckedChange = { agreedCodeOfConduct = it },
                        colors = CheckboxDefaults.colors(checkedColor = PinkPrimary)
                    )
                    Text("ฉันรับทราบและยอมรับข้อกำหนดของเพื่อนคุย", fontSize = 11.sp, color = Slate300)
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        val tags = mutableListOf<String>()
                        if (tagListening) tags.add("รับฟังเก่ง")
                        if (tagFriendly) tags.add("เป็นกันเอง")
                        if (tagConsult) tags.add("ให้คำปรึกษา")

                        val newProfile = CompanionProfile(
                            id = "comp_${currentUser.id}",
                            userId = currentUser.id,
                            displayName = currentUser.displayName,
                            avatar = currentUser.avatar,
                            age = currentUser.age,
                            languages = languagesText.split(",").map { it.trim() }.filter { it.isNotEmpty() },
                            introBio = introBio,
                            rating = 5.0,
                            reviewCount = 0,
                            level = CompanionLevel.STARTER,
                            totalSessionsCount = 0,
                            repeatUsersCount = 0,
                            totalHoursTalked = 0.0,
                            complaintsCount = 0,
                            penaltyHistoryCount = 0,
                            isReadyNow = false,
                            isOnline = true,
                            status = CompanionStatus.PENDING_REVIEW, // ส่งเป็น PENDING_REVIEW ตามกฎข้อ 2
                            kycInfo = kycInfo,
                            appliedAt = "วันนี้",
                            tags = tags
                        )
                        onSubmitApplication(newProfile)
                        onClose()
                    },
                    enabled = isKycVerified && agreedCodeOfConduct,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("ส่งใบสมัครเพื่อนคุย (เข้าสู่สถานะรอตรวจสอบ)", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
