package com.example.companion.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.companion.model.CompanionBankAccount
import com.example.companion.model.CompanionProfile
import com.example.companion.model.CompanionWallet
import com.example.service.SoundService
import com.example.ui.theme.*

@Composable
fun CompanionWalletSheet(
    isOpen: Boolean,
    companion: CompanionProfile?,
    wallet: CompanionWallet?,
    onClose: () -> Unit,
    onRequestWithdrawal: (amountCoins: Int, bankAccount: CompanionBankAccount) -> Boolean
) {
    if (!isOpen || companion == null) return

    val currentWallet = wallet ?: CompanionWallet(companionId = companion.id)

    var showWithdrawModal by remember { mutableStateOf(false) }
    var withdrawAmountText by remember { mutableStateOf("${minOf(currentWallet.currentBalanceCoins, 500)}") }
    var bankName by remember { mutableStateOf("ธนาคารกสิกรไทย (KBANK)") }
    var accountNumber by remember { mutableStateOf("") }
    var accountName by remember { mutableStateOf(companion.displayName) }
    var withdrawSuccessMessage by remember { mutableStateOf<String?>(null) }
    var withdrawErrorMessage by remember { mutableStateOf<String?>(null) }

    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Slate950
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header
                Surface(
                    color = Slate900,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 36.dp, bottom = 12.dp, start = 14.dp, end = 14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(AmberGold.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, tint = AmberGold, modifier = Modifier.size(20.dp))
                            }
                            Column {
                                Text("กระเป๋ารายได้เพื่อนคุย (Wallet)", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
                                Text("${companion.displayName} • Level ${companion.level.name}", fontSize = 11.sp, color = Slate400)
                            }
                        }

                        IconButton(onClick = onClose) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Slate400)
                        }
                    }
                }

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Summary Cards
                    item {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = Slate900,
                            border = androidx.compose.foundation.BorderStroke(1.dp, AmberGold.copy(alpha = 0.4f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("ยอดเงินที่ถอนได้ปัจจุบัน", fontSize = 11.sp, color = AmberGold, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            "🪙 ${currentWallet.currentBalanceCoins} Coins",
                                            fontSize = 24.sp,
                                            fontWeight = FontWeight.Black,
                                            color = AmberLight
                                        )
                                        Text(
                                            "≈ ฿${(currentWallet.currentBalanceCoins * 0.5).toInt()} บาท",
                                            fontSize = 12.sp,
                                            color = Slate400
                                        )
                                    }

                                    Button(
                                        onClick = { showWithdrawModal = true },
                                        colors = ButtonDefaults.buttonColors(containerColor = AmberGold),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Icon(Icons.Default.Payments, contentDescription = null, tint = Slate950, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("ขอถอนเงิน", color = Slate950, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }

                    // Stat Breakdown (วันนี้ / เดือนนี้ / ทั้งหมด)
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Today
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = Slate900,
                                border = androidx.compose.foundation.BorderStroke(1.dp, Slate800),
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("รายได้วันนี้", fontSize = 10.sp, color = Slate400)
                                    Text("🪙 ${currentWallet.todayEarningsCoins}", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = EmeraldGreen)
                                }
                            }

                            // Month
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = Slate900,
                                border = androidx.compose.foundation.BorderStroke(1.dp, Slate800),
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("รายได้เดือนนี้", fontSize = 10.sp, color = Slate400)
                                    Text("🪙 ${currentWallet.monthEarningsCoins}", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = PinkLight)
                                }
                            }

                            // Total
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = Slate900,
                                border = androidx.compose.foundation.BorderStroke(1.dp, Slate800),
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("รายได้ทั้งหมด", fontSize = 10.sp, color = Slate400)
                                    Text("🪙 ${currentWallet.totalEarningsCoins}", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = PurpleAccent)
                                }
                            }
                        }
                    }

                    // Session History
                    item {
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.History, contentDescription = null, tint = PinkPrimary, modifier = Modifier.size(16.dp))
                            Text("ประวัติเซสชันการคุย", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
                        }
                    }

                    if (currentWallet.sessionHistory.isEmpty()) {
                        item {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Slate900,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    "ยังไม่มีประวัติเซสชันที่เสร็จสมบูรณ์",
                                    fontSize = 11.sp,
                                    color = Slate500,
                                    modifier = Modifier.padding(14.dp)
                                )
                            }
                        }
                    } else {
                        items(currentWallet.sessionHistory) { sess ->
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Slate900,
                                border = androidx.compose.foundation.BorderStroke(1.dp, Slate800),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("คุยกับ: ${sess.clientName}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White)
                                        Text(
                                            "${sess.type.titleThai} • ระยะเวลา ${sess.durationSeconds / 60} นาที ${sess.durationSeconds % 60} วินาที",
                                            fontSize = 10.sp,
                                            color = Slate400
                                        )
                                        if (sess.clientRating != null) {
                                            Text("⭐ รีวิว ${sess.clientRating} ดาว: \"${sess.clientReviewComment ?: ""}\"", fontSize = 10.sp, color = AmberGold)
                                        }
                                    }

                                    Text(
                                        "+${sess.companionEarningsCoins} Coins",
                                        fontWeight = FontWeight.Black,
                                        fontSize = 13.sp,
                                        color = EmeraldGreen
                                    )
                                }
                            }
                        }
                    }

                    // Transactions Log
                    item {
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.AutoMirrored.Filled.ReceiptLong, contentDescription = null, tint = AmberGold, modifier = Modifier.size(16.dp))
                            Text("ประวัติรายการในกระเป๋า", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
                        }
                    }

                    if (currentWallet.transactions.isEmpty()) {
                        item {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Slate900,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("ยังไม่มีรายการธุรกรรม", fontSize = 11.sp, color = Slate500, modifier = Modifier.padding(14.dp))
                            }
                        }
                    } else {
                        items(currentWallet.transactions) { tx ->
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = Slate900,
                                border = androidx.compose.foundation.BorderStroke(1.dp, Slate800),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(tx.description, fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Medium)
                                        Text(tx.formattedTime, fontSize = 9.sp, color = Slate500)
                                    }

                                    Text(
                                        text = if (tx.amountCoins > 0) "+${tx.amountCoins}" else "${tx.amountCoins}",
                                        color = if (tx.amountCoins > 0) EmeraldGreen else RoseLight,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Withdrawal Modal
            // กฎข้อ 6: เตรียมระบบถอนเงินไว้ แต่ยังไม่ต้องเชื่อมเงินจริง บัญชีธนาคารให้ขอเฉพาะตอนผู้ใช้ต้องการถอนเงิน
            if (showWithdrawModal) {
                AlertDialog(
                    onDismissRequest = { showWithdrawModal = false },
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.Payments, contentDescription = null, tint = AmberGold)
                            Text("ระบุบัญชีธนาคารเพื่อถอนเงิน", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                    },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(
                                "ระบบจะขอข้อมูลบัญชีธนาคารเฉพาะเมื่อคุณต้องการถอนเงินเท่านั้น เพื่อความเป็นส่วนตัวสูงสุด",
                                fontSize = 11.sp,
                                color = Slate400
                            )

                            OutlinedTextField(
                                value = withdrawAmountText,
                                onValueChange = { withdrawAmountText = it },
                                label = { Text("จำนวน Coins ที่ต้องการถอน", fontSize = 12.sp) },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = AmberGold,
                                    unfocusedBorderColor = Slate700
                                )
                            )

                            OutlinedTextField(
                                value = bankName,
                                onValueChange = { bankName = it },
                                label = { Text("ธนาคาร", fontSize = 12.sp) },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = AmberGold,
                                    unfocusedBorderColor = Slate700
                                )
                            )

                            OutlinedTextField(
                                value = accountNumber,
                                onValueChange = { accountNumber = it },
                                label = { Text("เลขที่บัญชีธนาคาร", fontSize = 12.sp) },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = AmberGold,
                                    unfocusedBorderColor = Slate700
                                )
                            )

                            OutlinedTextField(
                                value = accountName,
                                onValueChange = { accountName = it },
                                label = { Text("ชื่อเจ้าของบัญชี (ตรงกับชื่อจริง)", fontSize = 12.sp) },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = AmberGold,
                                    unfocusedBorderColor = Slate700
                                )
                            )

                            val amt = withdrawAmountText.toIntOrNull() ?: 0
                            Text(
                                "ยอดเงินที่จะได้รับ: ≈ ฿${(amt * 0.5).toInt()} บาท (ระบบ Mock ถอนเงิน)",
                                fontSize = 11.sp,
                                color = EmeraldGreen,
                                fontWeight = FontWeight.Bold
                            )

                            if (withdrawErrorMessage != null) {
                                Text(withdrawErrorMessage ?: "", color = RoseLight, fontSize = 11.sp)
                            }
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                val amt = withdrawAmountText.toIntOrNull() ?: 0
                                if (amt <= 0 || amt > currentWallet.currentBalanceCoins) {
                                    withdrawErrorMessage = "ยอดเหรียญไม่ถูกต้อง หรือมากกว่ายอดที่มี"
                                    return@Button
                                }
                                if (accountNumber.isBlank()) {
                                    withdrawErrorMessage = "กรุณาระบุเลขที่บัญชีธนาคาร"
                                    return@Button
                                }
                                val bankAccount = CompanionBankAccount(bankName, accountNumber, accountName)
                                val success = onRequestWithdrawal(amt, bankAccount)
                                if (success) {
                                    SoundService.playCoin()
                                    showWithdrawModal = false
                                    withdrawErrorMessage = null
                                } else {
                                    withdrawErrorMessage = "เกิดข้อผิดพลาดในการส่งคำขอ"
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = AmberGold)
                        ) {
                            Text("ยืนยันขอถอนเงิน", color = Slate950, fontWeight = FontWeight.Bold)
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showWithdrawModal = false }) {
                            Text("ยกเลิก", color = Slate400)
                        }
                    },
                    containerColor = Slate900
                )
            }
        }
    }
}
