package com.example.companion.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.companion.model.*
import com.example.model.User
import com.example.service.SoundService
import com.example.ui.theme.*

@Composable
fun CompanionAdminDialog(
    isOpen: Boolean,
    adminUser: User,
    profiles: List<CompanionProfile>,
    pricingConfig: CompanionPricingConfig,
    wallets: Map<String, CompanionWallet>,
    giftRequests: List<CompanionGiftRequest>,
    auditLogs: List<CompanionAdminAuditLog>,
    safetyReports: List<CompanionSafetyReport>,
    onClose: () -> Unit,
    onApproveCompanion: (id: String, reason: String) -> Unit,
    onRejectCompanion: (id: String, reason: String) -> Unit,
    onSuspendCompanion: (id: String, reason: String) -> Unit,
    onUpdateRates: (level: CompanionLevel, text: Int, voice: Int, video: Int, reason: String) -> Unit,
    onRecalculateLevel: (id: String) -> Unit,
    onLogAudit: (action: String, targetType: String, targetId: String, justification: String) -> Unit
) {
    if (!isOpen) return

    var activeTab by remember { mutableStateOf("applications") } // "applications", "pricing", "sessions", "reports", "audit"

    // Sub-dialog states
    var selectedKycProfile by remember { mutableStateOf<CompanionProfile?>(null) }
    var auditInspectionReason by remember { mutableStateOf("") }
    var showKycDetailModal by remember { mutableStateOf(false) }

    // Pricing edit state
    var selectedLevelForEdit by remember { mutableStateOf<CompanionLevel?>(null) }
    var editTextRate by remember { mutableStateOf("10") }
    var editVoiceRate by remember { mutableStateOf("20") }
    var editVideoRate by remember { mutableStateOf("35") }
    var editPricingReason by remember { mutableStateOf("ปรับราคาให้สอดคล้องกับความต้องการของตลาด") }

    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Slate950
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header
                Surface(
                    color = Slate900,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 36.dp, bottom = 10.dp, start = 14.dp, end = 14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(AmberGold.copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = AmberGold, modifier = Modifier.size(20.dp))
                                }
                                Column {
                                    Text("ระบบผู้ดูแลเพื่อนคุย (Companion Moderation)", fontWeight = FontWeight.Black, fontSize = 15.sp, color = Color.White)
                                    Text("แอดมิน: ${adminUser.displayName} • กฎความปลอดภัย & Privacy", fontSize = 11.sp, color = Slate400)
                                }
                            }

                            IconButton(onClick = onClose) {
                                Icon(Icons.Default.Close, contentDescription = "Close", tint = Slate400)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Admin Navigation Tabs
                        ScrollableTabRow(
                            selectedTabIndex = when (activeTab) {
                                "applications" -> 0
                                "pricing" -> 1
                                "sessions" -> 2
                                "reports" -> 3
                                "audit" -> 4
                                else -> 0
                            },
                            containerColor = Slate900,
                            contentColor = PinkPrimary,
                            edgePadding = 0.dp
                        ) {
                            val pendingAppsCount = profiles.count { it.status == CompanionStatus.PENDING_REVIEW }
                            Tab(
                                selected = activeTab == "applications",
                                onClick = { activeTab = "applications" },
                                text = { Text("คำขอสมัคร ($pendingAppsCount)", fontSize = 11.sp) }
                            )
                            Tab(
                                selected = activeTab == "pricing",
                                onClick = { activeTab = "pricing" },
                                text = { Text("เรตราคา & Level", fontSize = 11.sp) }
                            )
                            Tab(
                                selected = activeTab == "sessions",
                                onClick = { activeTab = "sessions" },
                                text = { Text("เซสชัน & Wallet", fontSize = 11.sp) }
                            )
                            val pendingRepCount = safetyReports.count { it.status == "pending" }
                            Tab(
                                selected = activeTab == "reports",
                                onClick = { activeTab = "reports" },
                                text = { Text("รายงาน ($pendingRepCount)", fontSize = 11.sp) }
                            )
                            Tab(
                                selected = activeTab == "audit",
                                onClick = { activeTab = "audit" },
                                text = { Text("Audit Logs (${auditLogs.size})", fontSize = 11.sp) }
                            )
                        }
                    }
                }

                // Tab Content
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(14.dp)
                ) {
                    when (activeTab) {
                        "applications" -> {
                            // Review Applications (PENDING_REVIEW, APPROVED, REJECTED, SUSPENDED)
                            val pendingList = profiles.filter { it.status == CompanionStatus.PENDING_REVIEW }
                            val otherList = profiles.filter { it.status != CompanionStatus.PENDING_REVIEW }

                            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                item {
                                    Text("คำขอที่รอตรวจสอบ (Pending Review)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = AmberGold)
                                }

                                if (pendingList.isEmpty()) {
                                    item {
                                        Surface(color = Slate900, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                                            Text("ไม่มีคำขอที่ค้างตรวจในขณะนี้", fontSize = 11.sp, color = Slate500, modifier = Modifier.padding(14.dp))
                                        }
                                    }
                                } else {
                                    items(pendingList) { prof ->
                                        ApplicationCard(
                                            profile = prof,
                                            onInspectKyc = {
                                                selectedKycProfile = prof
                                                showKycDetailModal = true
                                            },
                                            onApprove = { reason ->
                                                onApproveCompanion(prof.id, reason)
                                                SoundService.playMatch()
                                            },
                                            onReject = { reason ->
                                                onRejectCompanion(prof.id, reason)
                                                SoundService.playPop()
                                            }
                                        )
                                    }
                                }

                                item {
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text("รายชื่อเพื่อนคุยทั้งหมด (${profiles.size})", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
                                }

                                items(otherList) { prof ->
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = Slate900,
                                        border = androidx.compose.foundation.BorderStroke(1.dp, Slate800),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(12.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                                AsyncImage(
                                                    model = prof.avatar,
                                                    contentDescription = prof.displayName,
                                                    contentScale = ContentScale.Crop,
                                                    modifier = Modifier
                                                        .size(40.dp)
                                                        .clip(CircleShape)
                                                )
                                                Column {
                                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                        Text(prof.displayName, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White)
                                                        Surface(
                                                            color = Color(prof.level.badgeColorHex).copy(alpha = 0.2f),
                                                            shape = RoundedCornerShape(4.dp)
                                                        ) {
                                                            Text(prof.level.name, color = Color(prof.level.badgeColorHex), fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp))
                                                        }
                                                    }
                                                    Text("สถานะ: ${prof.status.name} • เรตติ้ง ${prof.rating} ★", fontSize = 10.sp, color = Slate400)
                                                }
                                            }

                                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                if (prof.status == CompanionStatus.APPROVED) {
                                                    Button(
                                                        onClick = { onSuspendCompanion(prof.id, "Admin สั่งระงับเนื่องจากตรวจสอบพบความเสี่ยง") },
                                                        colors = ButtonDefaults.buttonColors(containerColor = RosePrimary),
                                                        shape = RoundedCornerShape(8.dp),
                                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                                    ) {
                                                        Text("ระงับ (Suspend)", fontSize = 10.sp)
                                                    }
                                                } else if (prof.status == CompanionStatus.SUSPENDED) {
                                                    Button(
                                                        onClick = { onApproveCompanion(prof.id, "Admin ปลดระงับการให้บริการ") },
                                                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
                                                        shape = RoundedCornerShape(8.dp),
                                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                                    ) {
                                                        Text("ปลดระงับ", fontSize = 10.sp, color = Slate950)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        "pricing" -> {
                            // Level & Pricing Management (ข้อ 4 & 8: ผู้ใช้ห้ามตั้งราคาเอง ให้ระบบกำหนดเรตตาม Level, Admin แก้ไขได้)
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                item {
                                    Text("ตารางเรตราคาตาม Level (Coin ต่อนาที)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
                                    Text("ผู้ใช้ไม่สามารถตั้งราคาเองได้ ระบบกำหนดอัตโนมัติ และ Admin สามารถปรับปรุงเรตราคาได้ที่นี่", fontSize = 11.sp, color = Slate400)
                                }

                                items(CompanionLevel.values().toList()) { level ->
                                    val currentRate = pricingConfig.rates[level] ?: CompanionLevelRate(level, 5, 10, 20)
                                    Surface(
                                        shape = RoundedCornerShape(14.dp),
                                        color = Slate900,
                                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(level.badgeColorHex).copy(alpha = 0.4f)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(14.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                    Text(level.name, fontWeight = FontWeight.Black, fontSize = 14.sp, color = Color(level.badgeColorHex))
                                                    Text("(${level.titleThai})", fontSize = 11.sp, color = Slate400)
                                                }
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Text(
                                                    "💬 แชต: ${currentRate.textChatCoinsPerMin} • 📞 เสียง: ${currentRate.voiceCallCoinsPerMin} • 📹 วิดีโอ: ${currentRate.videoCallCoinsPerMin} Coins/นาที",
                                                    fontSize = 11.sp,
                                                    color = Color.White
                                                )
                                            }

                                            Button(
                                                onClick = {
                                                    selectedLevelForEdit = level
                                                    editTextRate = currentRate.textChatCoinsPerMin.toString()
                                                    editVoiceRate = currentRate.voiceCallCoinsPerMin.toString()
                                                    editVideoRate = currentRate.videoCallCoinsPerMin.toString()
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = Slate800),
                                                shape = RoundedCornerShape(10.dp)
                                            ) {
                                                Icon(Icons.Default.Edit, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("แก้ไขเรต", fontSize = 11.sp)
                                            }
                                        }
                                    }
                                }

                                item {
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text("คำนวณ Level อัตโนมัติ (Level Calculator)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
                                    Text("เกณฑ์: คะแนนรีวิว, ชม. คุย, ลูกค้าคุยซ้ำ, การร้องเรียน, ประวัติลงโทษ", fontSize = 11.sp, color = Slate400)
                                }

                                items(profiles) { prof ->
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = Slate900,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(10.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                Text(prof.displayName, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White)
                                                Text(
                                                    "เรตติ้ง ${prof.rating} ★ • ${prof.totalHoursTalked} ชม. • คุยซ้ำ ${prof.repeatUsersCount} คน • ร้องเรียน ${prof.complaintsCount}",
                                                    fontSize = 10.sp,
                                                    color = Slate400
                                                )
                                            }

                                            Button(
                                                onClick = {
                                                    onRecalculateLevel(prof.id)
                                                    SoundService.playMatch()
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                                                shape = RoundedCornerShape(8.dp),
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                            ) {
                                                Text("คำนวณ Level ใหม่", fontSize = 10.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        "sessions" -> {
                            // Sessions & Wallets
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                item {
                                    Text("รายการคำขอของขวัญ (Gift Requests)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
                                }

                                items(giftRequests) { greq ->
                                    Surface(shape = RoundedCornerShape(10.dp), color = Slate900, modifier = Modifier.fillMaxWidth()) {
                                        Column(modifier = Modifier.padding(10.dp)) {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                Text("${greq.senderName} ➔ ${greq.receiverName}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White)
                                                Text(greq.status.name, fontSize = 11.sp, color = if (greq.status == GiftRequestStatus.ACCEPTED) EmeraldGreen else AmberGold)
                                            }
                                            Text("ของขวัญ: ${greq.gift.emoji} ${greq.gift.name} (${greq.gift.coins} Coins) • \"${greq.message}\"", fontSize = 11.sp, color = Slate400)
                                        }
                                    }
                                }

                                item {
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text("กระเป๋ารายได้ของเพื่อนคุย (Companion Wallets)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
                                }

                                items(wallets.values.toList()) { wal ->
                                    val comp = profiles.find { it.id == wal.companionId }
                                    Surface(shape = RoundedCornerShape(10.dp), color = Slate900, modifier = Modifier.fillMaxWidth()) {
                                        Column(modifier = Modifier.padding(10.dp)) {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                Text(comp?.displayName ?: wal.companionId, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White)
                                                Text("คงเหลือ: 🪙 ${wal.currentBalanceCoins}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = AmberGold)
                                            }
                                            Text(
                                                "รายได้วันนี้: 🪙 ${wal.todayEarningsCoins} • เดือนนี้: 🪙 ${wal.monthEarningsCoins} • ทั้งหมด: 🪙 ${wal.totalEarningsCoins}",
                                                fontSize = 10.sp,
                                                color = Slate400
                                            )
                                            if (wal.bankAccount != null) {
                                                Text("บัญชี: ${wal.bankAccount.bankName} เลข ${wal.bankAccount.accountNumber}", fontSize = 10.sp, color = Slate500)
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        "reports" -> {
                            // Safety Reports (Rule 10: Privacy / Safety - แสดงเฉพาะข้อมูลที่จำเป็น และทำ Audit Log ทุกครั้งที่เปิดดูข้อมูลละเอียด)
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                item {
                                    Text("รายงานความปลอดภัยเพื่อนคุย (Safety Reports)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
                                    Text("ข้อกำหนดความเป็นส่วนตัว: แสดงเฉพาะข้อมูลที่เกี่ยวข้องต่อการตรวจสอบ ห้ามเปิดอ่านข้อความส่วนตัวทั่วไปโดยไม่มีเหตุผล", fontSize = 11.sp, color = Slate400)
                                }

                                items(safetyReports) { rep ->
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = Slate900,
                                        border = androidx.compose.foundation.BorderStroke(1.dp, RosePrimary.copy(alpha = 0.4f)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                Text("ผู้รายงาน: ${rep.reporterName}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White)
                                                Text("สถานะ: ${rep.status}", fontSize = 10.sp, color = AmberGold, fontWeight = FontWeight.Bold)
                                            }
                                            Text("ผู้ถูกรายงาน: ${rep.reportedCompanionName} • เหตุผล: ${rep.reason}", fontSize = 11.sp, color = RoseLight)

                                            // Relevant Context Snippet
                                            Surface(color = Slate950, shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
                                                Text(
                                                    "บริบทข้อความที่เป็นปัญหา: \"${rep.relevantSnippet}\"",
                                                    fontSize = 11.sp,
                                                    color = Slate300,
                                                    modifier = Modifier.padding(8.dp)
                                                )
                                            }

                                            Button(
                                                onClick = {
                                                    onLogAudit(
                                                        "เปิดตรวจบริบทความปลอดภัยของรายงาน ${rep.id}",
                                                        "report_inspection",
                                                        rep.id,
                                                        "ตรวจสอบหลักฐานการละเมิดกฎชุมชน"
                                                    )
                                                    SoundService.playPop()
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = Slate800),
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                Icon(Icons.Default.Visibility, contentDescription = null, tint = AmberGold, modifier = Modifier.size(14.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("บันทึกการเข้าตรวจ (Audit Log) & ยืนยัน", fontSize = 10.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        "audit" -> {
                            // Audit Logs Trail
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                item {
                                    Text("บันทึกการตรวจสอบของแอดมิน (Audit Logs)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
                                    Text("บันทึกทุกครั้งที่มีการเปิดดูข้อมูลละเอียด ปรับเรตราคา หรือลงโทษ เพื่อความโปร่งใส", fontSize = 11.sp, color = Slate400)
                                }

                                items(auditLogs) { log ->
                                    Surface(shape = RoundedCornerShape(10.dp), color = Slate900, modifier = Modifier.fillMaxWidth()) {
                                        Column(modifier = Modifier.padding(10.dp)) {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                Text(log.action, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = AmberGold)
                                                Text(log.formattedTime, fontSize = 9.sp, color = Slate500)
                                            }
                                            Text("ผู้ปฏิบัติการ: ${log.adminName} • เป้าหมาย: ${log.targetType} (${log.targetId})", fontSize = 10.sp, color = Slate300)
                                            Text("เหตุผล/บันทึก: ${log.reasonOrJustification}", fontSize = 10.sp, color = Slate400)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Sub-Modal: Inspect KYC with Mandatory Audit Logging
            if (showKycDetailModal && selectedKycProfile != null) {
                val prof = selectedKycProfile!!
                val kyc = prof.kycInfo

                AlertDialog(
                    onDismissRequest = { showKycDetailModal = false },
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = AmberGold)
                            Text("ตรวจสอบข้อมูล KYC (Audit Log Required)", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }
                    },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("ชื่อผู้สมัคร: ${prof.displayName} (อายุ ${prof.age} ปี)", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 13.sp)
                            Text("เลขบัตร ปชช.: ${kyc?.idCardNumberMasked ?: "ไม่มีข้อมูล"}", fontSize = 12.sp, color = Slate300)
                            Text("ผลตรวจอัตโนมัติ: Risk Score ${kyc?.automatedScreening?.riskScore ?: 0.05}", fontSize = 12.sp, color = EmeraldGreen)

                            kyc?.automatedScreening?.automatedCheckNotes?.forEach { note ->
                                Text("• $note", fontSize = 11.sp, color = Slate400)
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text("ระบุเหตุผลในการเปิดดูเอกสาร (จะถูกบันทึกลง Audit Log):", fontSize = 11.sp, color = AmberGold)
                            OutlinedTextField(
                                value = auditInspectionReason,
                                onValueChange = { auditInspectionReason = it },
                                placeholder = { Text("เช่น ตรวจความถูกต้องของใบหน้าและอายุ", fontSize = 11.sp) },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                onLogAudit(
                                    "เปิดดูข้อมูลละเอียด KYC ผู้สมัคร ${prof.displayName}",
                                    "companion_kyc",
                                    prof.id,
                                    if (auditInspectionReason.isNotBlank()) auditInspectionReason else "ตรวจสอบความถูกต้องของเอกสาร KYC"
                                )
                                showKycDetailModal = false
                                auditInspectionReason = ""
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = AmberGold)
                        ) {
                            Text("บันทึก Audit และปิด", color = Slate950, fontWeight = FontWeight.Bold)
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showKycDetailModal = false }) {
                            Text("ยกเลิก", color = Slate400)
                        }
                    },
                    containerColor = Slate900
                )
            }

            // Sub-Modal: Edit Level Pricing
            if (selectedLevelForEdit != null) {
                val lvl = selectedLevelForEdit!!
                AlertDialog(
                    onDismissRequest = { selectedLevelForEdit = null },
                    title = { Text("ปรับเรตราคา Level ${lvl.name}", fontSize = 15.sp, fontWeight = FontWeight.Bold) },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("ระบุราคา Coin ต่อนาที สำหรับผู้ให้บริการในระดับนี้", fontSize = 11.sp, color = Slate400)
                            OutlinedTextField(
                                value = editTextRate,
                                onValueChange = { editTextRate = it },
                                label = { Text("Text Chat (Coin/นาที)", fontSize = 11.sp) },
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = editVoiceRate,
                                onValueChange = { editVoiceRate = it },
                                label = { Text("Voice Call (Coin/นาที)", fontSize = 11.sp) },
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = editVideoRate,
                                onValueChange = { editVideoRate = it },
                                label = { Text("Video Call (Coin/นาที)", fontSize = 11.sp) },
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = editPricingReason,
                                onValueChange = { editPricingReason = it },
                                label = { Text("เหตุผลในการปรับราคา (Audit Reason)", fontSize = 11.sp) },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                val t = editTextRate.toIntOrNull() ?: 5
                                val v = editVoiceRate.toIntOrNull() ?: 10
                                val vi = editVideoRate.toIntOrNull() ?: 20
                                onUpdateRates(lvl, t, v, vi, editPricingReason)
                                selectedLevelForEdit = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary)
                        ) {
                            Text("บันทึกเรตราคา", fontWeight = FontWeight.Bold)
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { selectedLevelForEdit = null }) {
                            Text("ยกเลิก", color = Slate400)
                        }
                    },
                    containerColor = Slate900
                )
            }
        }
    }
}

@Composable
private fun ApplicationCard(
    profile: CompanionProfile,
    onInspectKyc: () -> Unit,
    onApprove: (reason: String) -> Unit,
    onReject: (reason: String) -> Unit
) {
    var rejectReason by remember { mutableStateOf("") }
    var showRejectDialog by remember { mutableStateOf(false) }

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = Slate900,
        border = androidx.compose.foundation.BorderStroke(1.dp, AmberGold.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    AsyncImage(
                        model = profile.avatar,
                        contentDescription = profile.displayName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                    )
                    Column {
                        Text(profile.displayName, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
                        Text("อายุ ${profile.age} ปี • ภาษา: ${profile.languages.joinToString(", ")}", fontSize = 10.sp, color = Slate400)
                        Text("ยื่นสมัครเมื่อ: ${profile.appliedAt}", fontSize = 9.sp, color = AmberGold)
                    }
                }

                Surface(
                    color = AmberGold.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        "รอตรวจ (PENDING)",
                        color = AmberGold,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Surface(color = Slate950, shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
                Text(
                    "Bio: \"${profile.introBio}\"",
                    fontSize = 11.sp,
                    color = Slate300,
                    modifier = Modifier.padding(8.dp)
                )
            }

            // KYC Automated Check Summary
            val kyc = profile.kycInfo
            if (kyc != null) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "ระบบคัดกรอง: Risk ${kyc.automatedScreening.riskScore} (ปลอดภัย)",
                        fontSize = 10.sp,
                        color = EmeraldGreen,
                        fontWeight = FontWeight.Bold
                    )
                    TextButton(onClick = onInspectKyc) {
                        Icon(Icons.Default.Search, contentDescription = null, tint = AmberGold, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("ดูเอกสาร & บันทึก Audit", color = AmberGold, fontSize = 10.sp)
                    }
                }
            }

            // Action Buttons (Approve / Reject)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { showRejectDialog = true },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = RoseLight),
                    border = androidx.compose.foundation.BorderStroke(1.dp, RosePrimary.copy(alpha = 0.5f))
                ) {
                    Text("ปฏิเสธ (Reject)", fontSize = 11.sp)
                }

                Button(
                    onClick = { onApprove("เอกสารครบถ้วน อายุตรงตามเกณฑ์ ผ่านการตรวจสอบ") },
                    modifier = Modifier.weight(1.2f),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen)
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, tint = Slate950, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("อนุมัติ (Approve)", color = Slate950, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
        }
    }

    if (showRejectDialog) {
        AlertDialog(
            onDismissRequest = { showRejectDialog = false },
            title = { Text("ระบุเหตุผลการปฏิเสธ", fontSize = 14.sp, fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = rejectReason,
                    onValueChange = { rejectReason = it },
                    placeholder = { Text("เช่น รูปบัตรไม่ชัดเจน หรือข้อมูลไม่สอดคล้อง", fontSize = 11.sp) },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onReject(if (rejectReason.isNotBlank()) rejectReason else "เอกสารไม่ผ่านเกณฑ์การพิจารณา")
                        showRejectDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RosePrimary)
                ) {
                    Text("ยืนยันปฏิเสธ")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRejectDialog = false }) {
                    Text("ยกเลิก", color = Slate400)
                }
            },
            containerColor = Slate900
        )
    }
}
