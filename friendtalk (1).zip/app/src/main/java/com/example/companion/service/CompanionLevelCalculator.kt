package com.example.companion.service

import com.example.companion.model.CompanionLevel
import com.example.companion.model.CompanionProfile

/**
 * คำนวณ Level ของเพื่อนคุยตามเกณฑ์:
 * 1. คะแนนรีวิว (Rating)
 * 2. จำนวนชั่วโมงที่คุย (Total hours)
 * 3. จำนวนผู้ใช้ที่กลับมาคุยซ้ำ (Repeat users)
 * 4. จำนวนการร้องเรียน (Complaints)
 * 5. ประวัติการถูกลงโทษ (Penalty history)
 */
object CompanionLevelCalculator {

    fun calculateLevel(
        rating: Double,
        totalHours: Double,
        repeatUsers: Int,
        complaints: Int,
        penaltyHistory: Int
    ): CompanionLevel {
        // หากมีประวัติถูกลงโทษมากกว่า 2 ครั้ง หรือถูกร้องเรียนหนัก ลดระดับไม่ให้เกิน BRONZE/STARTER
        if (penaltyHistory >= 3 || complaints >= 5) {
            return CompanionLevel.STARTER
        }

        return when {
            rating >= 4.9 && totalHours >= 50.0 && repeatUsers >= 20 && complaints == 0 && penaltyHistory == 0 ->
                CompanionLevel.VIP

            rating >= 4.8 && totalHours >= 30.0 && repeatUsers >= 10 && complaints <= 1 && penaltyHistory == 0 ->
                CompanionLevel.PLATINUM

            rating >= 4.6 && totalHours >= 15.0 && repeatUsers >= 5 && complaints <= 2 && penaltyHistory == 0 ->
                CompanionLevel.GOLD

            rating >= 4.3 && totalHours >= 5.0 && repeatUsers >= 2 && complaints <= 3 && penaltyHistory <= 1 ->
                CompanionLevel.SILVER

            rating >= 4.0 && totalHours >= 1.0 && complaints <= 4 && penaltyHistory <= 1 ->
                CompanionLevel.BRONZE

            else -> CompanionLevel.STARTER
        }
    }

    fun recalculateProfileLevel(profile: CompanionProfile): CompanionProfile {
        val newLevel = calculateLevel(
            rating = profile.rating,
            totalHours = profile.totalHoursTalked,
            repeatUsers = profile.repeatUsersCount,
            complaints = profile.complaintsCount,
            penaltyHistory = profile.penaltyHistoryCount
        )
        return profile.copy(level = newLevel)
    }
}
