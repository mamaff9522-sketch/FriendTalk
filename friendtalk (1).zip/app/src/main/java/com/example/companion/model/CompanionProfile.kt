package com.example.companion.model

/**
 * ข้อมูลโปรไฟล์ของเพื่อนคุย
 */
data class CompanionProfile(
    val id: String,
    val userId: String,
    val displayName: String,
    val avatar: String,
    val age: Int,
    val languages: List<String> = listOf("ไทย", "English"),
    val introBio: String,
    val rating: Double = 5.0,
    val reviewCount: Int = 0,
    val level: CompanionLevel = CompanionLevel.STARTER,
    val totalSessionsCount: Int = 0, // จำนวนคนที่เคยคุย
    val repeatUsersCount: Int = 0,   // จำนวนผู้ใช้ที่กลับมาคุยซ้ำ
    val totalHoursTalked: Double = 0.0, // จำนวนชั่วโมงที่คุย
    val complaintsCount: Int = 0,    // จำนวนการร้องเรียน
    val penaltyHistoryCount: Int = 0, // ประวัติการถูกลงโทษ
    val isReadyNow: Boolean = true,  // สถานะ "พร้อมคุยตอนนี้"
    val isOnline: Boolean = true,
    val status: CompanionStatus = CompanionStatus.PENDING_REVIEW,
    val kycInfo: KycVerificationInfo? = null,
    val appliedAt: String = "วันนี้",
    val reviewedAt: String? = null,
    val reviewedByAdminId: String? = null,
    val rejectionReason: String? = null,
    val suspensionReason: String? = null,
    val tags: List<String> = listOf("รับฟัง", "ปรึกษา", "เสียงนุ่ม")
)

/**
 * รีวิวหลังจบการสนทนา
 */
data class CompanionReview(
    val id: String,
    val sessionId: String,
    val companionId: String,
    val reviewerId: String,
    val reviewerName: String,
    val score: Int, // 1 ถึง 5
    val comment: String,
    val createdAt: String
)
