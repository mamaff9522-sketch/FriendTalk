package com.example.companion.data

import com.example.companion.model.*

object CompanionMockData {

    val giftCatalog = listOf(
        CompanionGiftCatalogItem(
            id = "gift_coffee",
            name = "กาแฟอุ่นใจ",
            emoji = "☕",
            coins = 20,
            description = "ส่งกาแฟร้อนๆ พร้อมทักทายขอคุยด้วยความสุภาพ"
        ),
        CompanionGiftCatalogItem(
            id = "gift_flowers",
            name = "ช่อดอกไม้หวาน",
            emoji = "💐",
            coins = 50,
            description = "ช่อดอกไม้สวยงาม ส่งต่อความรู้สึกดีๆ"
        ),
        CompanionGiftCatalogItem(
            id = "gift_teddy",
            name = "หมีกอดอุ่น",
            emoji = "🧸",
            coins = 100,
            description = "ตุ๊กตาหมีนุ่มนิ่ม แสดงความตั้งใจอยากทำความรู้จัก"
        ),
        CompanionGiftCatalogItem(
            id = "gift_cake",
            name = "เค้กสตรอว์เบอร์รี่",
            emoji = "🍰",
            coins = 150,
            description = "เค้กหวานฉ่ำ เติมพลังบวกให้บทสนทนา"
        ),
        CompanionGiftCatalogItem(
            id = "gift_crown",
            name = "มงกุฎเจ้าหญิง",
            emoji = "👑",
            coins = 300,
            description = "ของขวัญเกียรติยศสุดพรีเมียม ให้เกียรติผู้รับอย่างสูงสุด"
        )
    )

    val initialProfiles = listOf(
        // Companion 1: LinLin (Approved, Online, ReadyNow, VIP)
        CompanionProfile(
            id = "comp_linlin",
            userId = "user_linlin",
            displayName = "หลินหลิน 🌸 LinLada",
            avatar = "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&auto=format&fit=crop&q=80",
            age = 22,
            languages = listOf("ไทย", "English", "日本語"),
            introBio = "ยินดีรับฟังทุกเรื่องราวค่ะ ปรึกษาได้ทั้งเรื่องงาน ความรัก หรือแค่อยากมีคนคุยแก้เหงา สบายใจได้ 100% 💖",
            rating = 4.96,
            reviewCount = 138,
            level = CompanionLevel.VIP,
            totalSessionsCount = 142,
            repeatUsersCount = 38,
            totalHoursTalked = 72.5,
            complaintsCount = 0,
            penaltyHistoryCount = 0,
            isReadyNow = true,
            isOnline = true,
            status = CompanionStatus.APPROVED,
            kycInfo = KycVerificationInfo(
                idCardNumberMasked = "1-1002-XXXXX-12-3",
                idCardPhotoUrl = "https://images.unsplash.com/photo-1544717305-2782549b5136?w=600&auto=format&fit=crop&q=80",
                faceScanPhotoUrl = "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&auto=format&fit=crop&q=80",
                birthYear = 2004,
                verifiedAge = 22,
                isIdentityVerified = true,
                verifiedAt = "15 ม.ค. 2026",
                automatedScreening = AutomatedScreeningResult(
                    riskScore = 0.02,
                    isFlaggedForManualReview = false,
                    automatedCheckNotes = listOf(
                        "✓ บัตรประชาชนผ่านการตรวจสอบอัตโนมัติ",
                        "✓ สแกนใบหน้า Match 99.1%",
                        "✓ อายุ 22 ปี (เกิน 18 ปีบริบูรณ์)"
                    )
                )
            ),
            appliedAt = "10 ม.ค. 2026",
            reviewedAt = "15 ม.ค. 2026",
            reviewedByAdminId = "user_admin",
            tags = listOf("เสียงนุ่ม", "รับฟังเก่ง", "ปรึกษาหัวใจ", "เป็นกันเอง")
        ),

        // Companion 2: Fahsai (Approved, Online, ReadyNow, GOLD)
        CompanionProfile(
            id = "comp_fah",
            userId = "user_fah",
            displayName = "ฟ้าใส ☁️ Fahsai",
            avatar = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80",
            age = 21,
            languages = listOf("ไทย", "English"),
            introBio = "สายคาเฟ่และหนังสือ ใครเครียดหรือเหนื่อย แวะมาคุยเล่าให้ฟังได้นะคะ ยิ้มไปด้วยกันนะ ✨",
            rating = 4.82,
            reviewCount = 52,
            level = CompanionLevel.GOLD,
            totalSessionsCount = 56,
            repeatUsersCount = 14,
            totalHoursTalked = 26.0,
            complaintsCount = 0,
            penaltyHistoryCount = 0,
            isReadyNow = true,
            isOnline = true,
            status = CompanionStatus.APPROVED,
            kycInfo = KycVerificationInfo(
                idCardNumberMasked = "1-1004-XXXXX-98-1",
                idCardPhotoUrl = "https://images.unsplash.com/photo-1544717305-2782549b5136?w=600&auto=format&fit=crop&q=80",
                faceScanPhotoUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80",
                birthYear = 2005,
                verifiedAge = 21,
                isIdentityVerified = true,
                verifiedAt = "20 ม.ค. 2026",
                automatedScreening = AutomatedScreeningResult(
                    riskScore = 0.04,
                    isFlaggedForManualReview = false,
                    automatedCheckNotes = listOf(
                        "✓ บัตรประชาชนผ่านการตรวจสอบ",
                        "✓ สแกนใบหน้า Match 97.8%",
                        "✓ อายุ 21 ปี"
                    )
                )
            ),
            appliedAt = "18 ม.ค. 2026",
            reviewedAt = "20 ม.ค. 2026",
            reviewedByAdminId = "user_admin",
            tags = listOf("สดใส", "ฮีลใจ", "พลังบวก", "คุยสนุก")
        ),

        // Companion 3: Ploy (Approved, Online, ReadyNow, SILVER)
        CompanionProfile(
            id = "comp_ploy",
            userId = "user_ploy",
            displayName = "พลอยใส (Ploy)",
            avatar = "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&auto=format&fit=crop&q=80",
            age = 25,
            languages = listOf("ไทย", "English"),
            introBio = "ชอบคุยเรื่องงาน ศิลปะ การเดินทาง แบกเป้เที่ยว ให้คำปรึกษาอย่างมีเหตุผลและจริงใจค่ะ 🎨",
            rating = 4.60,
            reviewCount = 20,
            level = CompanionLevel.SILVER,
            totalSessionsCount = 22,
            repeatUsersCount = 5,
            totalHoursTalked = 11.5,
            complaintsCount = 0,
            penaltyHistoryCount = 0,
            isReadyNow = true,
            isOnline = true,
            status = CompanionStatus.APPROVED,
            kycInfo = KycVerificationInfo(
                idCardNumberMasked = "1-1008-XXXXX-45-7",
                idCardPhotoUrl = "https://images.unsplash.com/photo-1544717305-2782549b5136?w=600&auto=format&fit=crop&q=80",
                faceScanPhotoUrl = "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&auto=format&fit=crop&q=80",
                birthYear = 2001,
                verifiedAge = 25,
                isIdentityVerified = true,
                verifiedAt = "02 ก.พ. 2026",
                automatedScreening = AutomatedScreeningResult(
                    riskScore = 0.05,
                    isFlaggedForManualReview = false
                )
            ),
            appliedAt = "01 ก.พ. 2026",
            reviewedAt = "02 ก.พ. 2026",
            reviewedByAdminId = "user_admin",
            tags = listOf("คุยปรึกษางาน", "ศิลปะ", "แชร์มุมมอง")
        ),

        // Companion 4: Bank (PENDING_REVIEW - สำหรับ Admin ตรวจสอบตามข้อ 2 และ 8)
        CompanionProfile(
            id = "comp_bank",
            userId = "user_bank",
            displayName = "แบงค์ ธนภัทร 💪",
            avatar = "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&auto=format&fit=crop&q=80",
            age = 26,
            languages = listOf("ไทย", "English"),
            introBio = "เทรนเนอร์ฟิตเนสและนักวิ่ง พร้อมรับฟังและให้คำปรึกษาด้านสุขภาพ ออกกำลังกาย และดูแลใจครับ 🏃‍♂️",
            rating = 5.0,
            reviewCount = 0,
            level = CompanionLevel.STARTER,
            totalSessionsCount = 0,
            repeatUsersCount = 0,
            totalHoursTalked = 0.0,
            complaintsCount = 0,
            penaltyHistoryCount = 0,
            isReadyNow = false,
            isOnline = true,
            status = CompanionStatus.PENDING_REVIEW,
            kycInfo = KycVerificationInfo(
                idCardNumberMasked = "1-1005-XXXXX-63-9",
                idCardPhotoUrl = "https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=600&auto=format&fit=crop&q=80",
                faceScanPhotoUrl = "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&auto=format&fit=crop&q=80",
                birthYear = 2000,
                verifiedAge = 26,
                isIdentityVerified = true,
                verifiedAt = "เมื่อสักครู่",
                automatedScreening = AutomatedScreeningResult(
                    riskScore = 0.08,
                    isFlaggedForManualReview = false,
                    automatedCheckNotes = listOf(
                        "✓ บัตรประชาชนไทยถูกต้อง",
                        "✓ สแกนใบหน้า Match 96.5%",
                        "✓ อายุ 26 ปี (ผ่านเกณฑ์ 18+)"
                    )
                )
            ),
            appliedAt = "วันนี้ 10:15 น.",
            reviewedAt = null,
            reviewedByAdminId = null,
            tags = listOf("สุขภาพ", "ฟิตเนส", "เป้าหมายชีวิต")
        )
    )

    val initialWallets: Map<String, CompanionWallet> = mapOf(
        "comp_linlin" to CompanionWallet(
            companionId = "comp_linlin",
            todayEarningsCoins = 350,
            monthEarningsCoins = 4200,
            totalEarningsCoins = 18600,
            currentBalanceCoins = 5400,
            transactions = listOf(
                CompanionWalletTransaction(
                    id = "tx_101",
                    type = "session_earning",
                    amountCoins = 120,
                    description = "เซสชันวิดีโอคอล VIP กับคุณต้นกล้า (10 นาที)",
                    formattedTime = "วันนี้ 09:30 น."
                ),
                CompanionWalletTransaction(
                    id = "tx_102",
                    type = "gift_request_reward",
                    amountCoins = 230,
                    description = "ยอมรับคำขอของขวัญ มงกุฎเจ้าหญิง 👑",
                    formattedTime = "เมื่อวานนี้"
                )
            ),
            bankAccount = CompanionBankAccount("ธนาคารกสิกรไทย (KBANK)", "084-2-99812-4", "นางสาวลินลดา")
        ),
        "comp_fah" to CompanionWallet(
            companionId = "comp_fah",
            todayEarningsCoins = 180,
            monthEarningsCoins = 1600,
            totalEarningsCoins = 6400,
            currentBalanceCoins = 2100,
            transactions = listOf(
                CompanionWalletTransaction(
                    id = "tx_201",
                    type = "session_earning",
                    amountCoins = 180,
                    description = "เซสชันโทรเสียง Gold (15 นาที)",
                    formattedTime = "วันนี้ 11:15 น."
                )
            )
        )
    )

    val initialGiftRequests = listOf(
        CompanionGiftRequest(
            id = "greq_demo_01",
            senderId = "user_arty",
            senderName = "อาร์ตี้ ธาวิน ⚡",
            senderAvatar = "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=400&auto=format&fit=crop&q=80",
            receiverId = "user_me",
            receiverName = "ต้นกล้า (Tonkla)",
            gift = giftCatalog[2], // หมีกอดอุ่น 100 coins
            message = "สวัสดีครับ เห็นรูปคาเฟ่น่าไปมาก อยากขอคุยปรึกษาแนะนำมุมถ่ายรูปหน่อยครับ 😊",
            status = GiftRequestStatus.PENDING
        )
    )

    val initialAuditLogs = listOf(
        CompanionAdminAuditLog(
            id = "audit_01",
            adminId = "user_admin",
            adminName = "Official Admin",
            action = "อนุมัติคำขอสมัครเพื่อนคุย",
            targetType = "companion_application",
            targetId = "comp_linlin",
            reasonOrJustification = "เอกสาร KYC ถูกต้อง และประวัติโปรไฟล์ครบถ้วนตามระเบียบ",
            formattedTime = "15 ม.ค. 2026"
        ),
        CompanionAdminAuditLog(
            id = "audit_02",
            adminId = "user_admin",
            adminName = "Official Admin",
            action = "ปรับปรุงเรตราคา Level VIP",
            targetType = "rate_modification",
            targetId = "VIP",
            reasonOrJustification = "ปรับเรต Text Chat จาก 30 เป็น 35 Coins เพื่อให้สะท้อนคุณวุฒิ",
            formattedTime = "01 ก.พ. 2026"
        )
    )

    val initialSafetyReports = listOf(
        CompanionSafetyReport(
            id = "report_c01",
            reporterId = "user_me",
            reporterName = "ต้นกล้า (Tonkla)",
            reportedCompanionId = "comp_spammer",
            reportedCompanionName = "ผู้ใช้ทดสอบสแปม",
            sessionId = "sess_old_99",
            reason = "spam",
            relevantSnippet = "มีข้อความชักชวนเล่นพนันออนไลน์ซ้ำๆ ในระหว่างเซสชัน",
            status = "reviewed_penalty_applied",
            adminNotes = "ตรวจสอบบริบทแล้วพบพฤติกรรมจริง ดำเนินการระงับการให้บริการ",
            createdAt = "3 วันที่แล้ว"
        )
    )
}
