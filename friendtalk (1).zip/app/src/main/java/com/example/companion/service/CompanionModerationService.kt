package com.example.companion.service

import com.example.companion.model.*

/**
 * บริการคัดกรองและระบบความปลอดภัยสำหรับเพื่อนคุย
 * ข้อ 9: ระบบอัตโนมัติช่วยตรวจเบื้องต้น เคสเสี่ยงส่งเข้า Manual Review (ห้ามระบบอัตโนมัติแบนถาวรโดยไม่มี Review)
 * ข้อ 10: Audit Log ทุกครั้งที่เปิดดูข้อมูลละเอียด และกรองให้เห็นเฉพาะข้อมูลที่จำเป็น
 */
class CompanionModerationService {

    /**
     * คัดกรองข้อมูลผู้สมัครเพื่อนคุยด้วยระบบอัตโนมัติ
     */
    fun performAutomatedScreening(
        age: Int,
        idCardNumber: String,
        faceMatchConfidence: Double
    ): AutomatedScreeningResult {
        val notes = mutableListOf<String>()
        var riskScore = 0.05
        var flaggedForManual = false

        if (age < 18) {
            riskScore = 1.0
            flaggedForManual = true
            notes.add("⚠️ ตรวจพบอายุต่ำกว่า 18 ปี ($age ปี) - ระงับการสมัครอัตโนมัติและส่งเข้า Manual Review")
        } else {
            notes.add("✓ ผ่านเกณฑ์อายุขั้นต่ำ 18 ปี ($age ปี)")
        }

        if (idCardNumber.replace("-", "").length != 13) {
            riskScore += 0.4
            flaggedForManual = true
            notes.add("⚠️ เลขประจำตัวประชาชนไม่ครบ 13 หลัก ส่งตรวจสอบเอกสารเพิ่มเติม")
        } else {
            notes.add("✓ เลขประจำตัวประชาชนมีรูปแบบถูกต้อง")
        }

        if (faceMatchConfidence < 0.75) {
            riskScore += 0.35
            flaggedForManual = true
            notes.add("⚠️ ความเหมือนของใบหน้าต่ำกว่าเกณฑ์ (${(faceMatchConfidence * 100).toInt()}%) จำเป็นต้องให้เจ้าหน้าที่ตรวจด้วยตนเอง")
        } else {
            notes.add("✓ สแกนใบหน้าตรงกับบัตรประชาชน (${(faceMatchConfidence * 100).toInt()}%)")
        }

        return AutomatedScreeningResult(
            riskScore = riskScore.coerceIn(0.0, 1.0),
            isFlaggedForManualReview = flaggedForManual,
            automatedCheckNotes = notes,
            spamRisk = false,
            duplicateAccountRisk = false
        )
    }

    /**
     * บันทึก Audit Log เมื่อ Admin เข้าดูข้อมูลส่วนบุคคลหรือข้อความรายงาน
     */
    fun createAuditLog(
        adminId: String,
        adminName: String,
        action: String,
        targetType: String,
        targetId: String,
        reason: String
    ): CompanionAdminAuditLog {
        return CompanionAdminAuditLog(
            id = "audit_${System.currentTimeMillis()}",
            adminId = adminId,
            adminName = adminName,
            action = action,
            targetType = targetType,
            targetId = targetId,
            reasonOrJustification = reason
        )
    }
}
