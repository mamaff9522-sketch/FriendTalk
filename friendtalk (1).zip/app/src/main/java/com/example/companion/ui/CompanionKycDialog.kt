package com.example.companion.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.companion.model.AutomatedScreeningResult
import com.example.companion.model.KycVerificationInfo
import com.example.model.User
import com.example.ui.theme.*

@Composable
fun CompanionKycDialog(
    isOpen: Boolean,
    currentUser: User,
    onClose: () -> Unit,
    onKycCompleted: (KycVerificationInfo) -> Unit
) {
    if (!isOpen) return

    var step by remember { mutableStateOf(1) } // 1: ID Card, 2: Face Scan, 3: Auto Screening Check
    var idNumber by remember { mutableStateOf("1-1004-92841-55-2") }
    var idPhotoUploaded by remember { mutableStateOf(true) }
    var faceScanCaptured by remember { mutableStateOf(false) }
    var isProcessing by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .wrapContentHeight(),
            shape = RoundedCornerShape(24.dp),
            color = Slate900,
            border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(PinkPrimary.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = PinkLight, modifier = Modifier.size(20.dp))
                        }
                        Column {
                            Text("ยืนยันตัวตน (KYC)", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
                            Text("บัตรประชาชน + สแกนใบหน้า (18 ปีขึ้นไป)", fontSize = 11.sp, color = Slate400)
                        }
                    }

                    IconButton(onClick = onClose) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Slate400)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Step Progress Indicator
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StepPill(number = 1, title = "บัตรประชาชน", active = step == 1, completed = step > 1)
                    HorizontalDivider(modifier = Modifier.width(20.dp), color = Slate700)
                    StepPill(number = 2, title = "สแกนใบหน้า", active = step == 2, completed = step > 2)
                    HorizontalDivider(modifier = Modifier.width(20.dp), color = Slate700)
                    StepPill(number = 3, title = "ตรวจอัตโนมัติ", active = step == 3, completed = false)
                }

                Spacer(modifier = Modifier.height(20.dp))

                when (step) {
                    1 -> {
                        // Step 1: ID Card
                        Text("ขั้นตอนที่ 1: ถ่ายภาพบัตรประจำตัวประชาชน", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("ระบบจะทำการตรวจสอบอายุและชื่อ-นามสกุลให้ตรงกับบัญชี", fontSize = 11.sp, color = Slate400)

                        Spacer(modifier = Modifier.height(14.dp))

                        // ID Card Mock Box
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(130.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(Slate950)
                                .border(1.dp, if (idPhotoUploaded) EmeraldGreen else Slate700, RoundedCornerShape(16.dp))
                                .padding(12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.CreditCard, contentDescription = null, tint = if (idPhotoUploaded) EmeraldGreen else Slate500, modifier = Modifier.size(36.dp))
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    if (idPhotoUploaded) "✓ ตรวจพบภาพบัตรประชาชนชัดเจน" else "คลิกเพื่ออัปโหลดภาพบัตรประชาชน",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (idPhotoUploaded) EmeraldGreen else Slate300
                                )
                                Text("เลขที่บัตร: ${idNumber.take(6)}XXXXX-XX-X", fontSize = 11.sp, color = Slate400)
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        OutlinedTextField(
                            value = idNumber,
                            onValueChange = { idNumber = it },
                            label = { Text("เลขประจำตัวประชาชน 13 หลัก", fontSize = 12.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = PinkPrimary,
                                unfocusedBorderColor = Slate700,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )

                        Spacer(modifier = Modifier.height(18.dp))

                        Button(
                            onClick = { step = 2 },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("ถัดไป: สแกนใบหน้า", fontWeight = FontWeight.Bold)
                        }
                    }

                    2 -> {
                        // Step 2: Face Scan
                        Text("ขั้นตอนที่ 2: สแกนใบหน้าสด (Liveness Face Scan)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("เพื่อยืนยันว่าคุณคือเจ้าของบัตรประชาชนตัวจริง ป้องกันบัญชีปลอม", fontSize = 11.sp, color = Slate400)

                        Spacer(modifier = Modifier.height(14.dp))

                        Box(
                            modifier = Modifier
                                .size(140.dp)
                                .clip(CircleShape)
                                .background(Slate950)
                                .border(2.dp, if (faceScanCaptured) EmeraldGreen else RosePrimary, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            if (faceScanCaptured) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldGreen, modifier = Modifier.size(50.dp))
                            } else {
                                Icon(Icons.Default.Face, contentDescription = null, tint = RosePrimary, modifier = Modifier.size(60.dp))
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        if (faceScanCaptured) {
                            Text("✓ สแกนใบหน้าสำเร็จ (Face Match 98.4%)", color = EmeraldGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        } else {
                            Text("มองตรงที่กล้องและกะพริบตาเพื่อจับภาพ", color = Slate300, fontSize = 11.sp)
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedButton(
                                onClick = { step = 1 },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Slate300)
                            ) {
                                Text("ย้อนกลับ")
                            }

                            Button(
                                onClick = {
                                    faceScanCaptured = true
                                    step = 3
                                },
                                modifier = Modifier.weight(1.5f),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = if (faceScanCaptured) EmeraldGreen else PinkPrimary)
                            ) {
                                Text(if (faceScanCaptured) "ดำเนินการต่อ" else "เริ่มสแกนใบหน้า", fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    3 -> {
                        // Step 3: Automated Screening Evaluation
                        Text("ขั้นตอนที่ 3: ระบบคัดกรองอัตโนมัติ (Automated Screening)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("ผลการประเมินเบื้องต้นก่อนส่งคำขอ", fontSize = 11.sp, color = Slate400)

                        Spacer(modifier = Modifier.height(12.dp))

                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = Slate950,
                            border = androidx.compose.foundation.BorderStroke(1.dp, Slate800),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("คะแนนความเสี่ยง (Risk Score):", fontSize = 11.sp, color = Slate400)
                                    Text("0.04 (ต่ำมาก - ปลอดภัย)", fontSize = 11.sp, color = EmeraldGreen, fontWeight = FontWeight.Bold)
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("อายุที่ยืนยัน:", fontSize = 11.sp, color = Slate400)
                                    Text("${currentUser.age} ปี (ผ่านเกณฑ์ 18+)", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("ความตรงกันของใบหน้า:", fontSize = 11.sp, color = Slate400)
                                    Text("98.4%", fontSize = 11.sp, color = EmeraldGreen, fontWeight = FontWeight.Bold)
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("การป้องกันบัญชีปลอม/สแปม:", fontSize = 11.sp, color = Slate400)
                                    Text("ผ่านเกณฑ์", fontSize = 11.sp, color = EmeraldGreen, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        Button(
                            onClick = {
                                val kycInfo = KycVerificationInfo(
                                    idCardNumberMasked = "${idNumber.take(6)}XXXXX-XX-X",
                                    idCardPhotoUrl = "https://images.unsplash.com/photo-1544717305-2782549b5136?w=600&auto=format&fit=crop&q=80",
                                    faceScanPhotoUrl = currentUser.avatar,
                                    birthYear = 2026 - currentUser.age,
                                    verifiedAge = currentUser.age,
                                    isIdentityVerified = true,
                                    verifiedAt = "วันนี้",
                                    automatedScreening = AutomatedScreeningResult(
                                        riskScore = 0.04,
                                        isFlaggedForManualReview = false,
                                        automatedCheckNotes = listOf(
                                            "✓ บัตรประชาชนไทยถูกต้อง",
                                            "✓ สแกนใบหน้า Match 98.4%",
                                            "✓ อายุ ${currentUser.age} ปี (ผ่านเกณฑ์ 18+)"
                                        )
                                    )
                                )
                                onKycCompleted(kycInfo)
                                onClose()
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("เสร็จสิ้นการยืนยันตัวตน KYC", fontWeight = FontWeight.Bold, color = Slate950)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StepPill(number: Int, title: String, active: Boolean, completed: Boolean) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .clip(CircleShape)
                .background(
                    if (completed) EmeraldGreen
                    else if (active) PinkPrimary
                    else Slate800
                ),
            contentAlignment = Alignment.Center
        ) {
            if (completed) {
                Icon(Icons.Default.Check, contentDescription = null, tint = Slate950, modifier = Modifier.size(14.dp))
            } else {
                Text(
                    text = number.toString(),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (active) Color.White else Slate400
                )
            }
        }
        Text(title, fontSize = 9.sp, color = if (active || completed) Color.White else Slate500)
    }
}
