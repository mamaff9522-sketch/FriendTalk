package com.example.companion.service

import com.example.companion.model.*

/**
 * บริการจัดการ Wallet ของเพื่อนคุย
 * จัดการรายได้วันนี้, รายได้เดือนนี้, รายได้ทั้งหมด, ประวัติเซสชัน, และการขอถอนเงิน
 */
class CompanionWalletService {

    fun creditSessionEarning(
        wallet: CompanionWallet,
        session: CompanionSession,
        earnedCoins: Int
    ): CompanionWallet {
        val tx = CompanionWalletTransaction(
            id = "tx_${System.currentTimeMillis()}",
            type = "session_earning",
            amountCoins = earnedCoins,
            description = "รายได้จากเซสชัน ${session.type.titleThai} (${session.clientName}) ระยะเวลา ${session.durationSeconds / 60} นาที ${session.durationSeconds % 60} วินาที"
        )
        return wallet.copy(
            todayEarningsCoins = wallet.todayEarningsCoins + earnedCoins,
            monthEarningsCoins = wallet.monthEarningsCoins + earnedCoins,
            totalEarningsCoins = wallet.totalEarningsCoins + earnedCoins,
            currentBalanceCoins = wallet.currentBalanceCoins + earnedCoins,
            transactions = listOf(tx) + wallet.transactions,
            sessionHistory = listOf(session) + wallet.sessionHistory
        )
    }

    fun creditGiftReward(
        wallet: CompanionWallet,
        giftRequest: CompanionGiftRequest,
        earnedCoins: Int
    ): CompanionWallet {
        val tx = CompanionWalletTransaction(
            id = "tx_gift_${System.currentTimeMillis()}",
            type = "gift_request_reward",
            amountCoins = earnedCoins,
            description = "ของขวัญ ${giftRequest.gift.name} ${giftRequest.gift.emoji} จาก ${giftRequest.senderName}"
        )
        return wallet.copy(
            todayEarningsCoins = wallet.todayEarningsCoins + earnedCoins,
            monthEarningsCoins = wallet.monthEarningsCoins + earnedCoins,
            totalEarningsCoins = wallet.totalEarningsCoins + earnedCoins,
            currentBalanceCoins = wallet.currentBalanceCoins + earnedCoins,
            transactions = listOf(tx) + wallet.transactions
        )
    }

    fun requestWithdrawal(
        wallet: CompanionWallet,
        amountCoins: Int,
        bankAccount: CompanionBankAccount
    ): Pair<CompanionWallet, CompanionWithdrawalRequest>? {
        if (amountCoins <= 0 || wallet.currentBalanceCoins < amountCoins) {
            return null
        }
        val bahtEquivalent = (amountCoins * 0.5).toInt() // อัตราแลกเปลี่ยน 1 เหรียญ = 0.5 บาท
        val withdrawalReq = CompanionWithdrawalRequest(
            id = "wd_comp_${System.currentTimeMillis()}",
            companionId = wallet.companionId,
            companionName = "",
            amountCoins = amountCoins,
            amountBaht = bahtEquivalent,
            bankAccount = bankAccount,
            status = "pending"
        )
        val tx = CompanionWalletTransaction(
            id = "tx_wd_${System.currentTimeMillis()}",
            type = "withdrawal",
            amountCoins = -amountCoins,
            description = "ยื่นขอถอนเงิน ฿$bahtEquivalent เข้าบัญชี ${bankAccount.bankName} (${bankAccount.accountNumber})"
        )
        val updatedWallet = wallet.copy(
            currentBalanceCoins = wallet.currentBalanceCoins - amountCoins,
            bankAccount = bankAccount, // บันทึกบัญชีไว้
            transactions = listOf(tx) + wallet.transactions
        )
        return Pair(updatedWallet, withdrawalReq)
    }
}
