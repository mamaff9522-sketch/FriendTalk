package com.example.companion.model

/**
 * ข้อมูลเซสชันการคุย (Text / Voice / Video)
 */
data class CompanionSession(
    val id: String,
    val clientId: String,
    val clientName: String,
    val companionId: String,
    val companionName: String,
    val type: CompanionSessionType,
    val rateCoinsPerMinute: Int,
    val startedAtTimestamp: Long = System.currentTimeMillis(),
    val durationSeconds: Int = 0,
    val totalCoinsDeducted: Int = 0,
    val companionEarningsCoins: Int = 0,
    val status: CompanionSessionStatus = CompanionSessionStatus.REQUESTED,
    val terminationReason: String? = null,
    val clientRating: Int? = null,
    val clientReviewComment: String? = null
)

/**
 * สถานะเซสชันที่กำลังใช้งานอยู่ (Active Session State สำหรับ UI)
 */
data class ActiveSessionUiState(
    val session: CompanionSession,
    val companion: CompanionProfile,
    val clientRemainingCoins: Int,
    val secondsElapsed: Int = 0,
    val isCompanionAccepted: Boolean = false,
    val isLowCreditWarning: Boolean = false,
    val isAutoTerminated: Boolean = false
)
