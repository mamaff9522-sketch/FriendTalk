package com.example.companion.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.companion.data.CompanionMockData
import com.example.companion.model.CompanionGiftCatalogItem
import com.example.companion.model.CompanionGiftRequest
import com.example.companion.model.CompanionProfile
import com.example.model.User
import com.example.service.SoundService
import com.example.ui.theme.*

/**
 * กล่องส่งของขวัญเพื่อขอคุยกับผู้ใช้อื่น (Gift Request Dialog)
 * กฎข้อ 7: ผู้ส่งใช้ Coin ซื้อของขวัญ, ผู้รับต้องเป็นคนตัดสินใจเองเสมอ, ห้ามการจ่ายเงินบังคับให้อีกฝ่ายต้องคุย
 */
@Composable
fun CompanionGiftRequestDialog(
    isOpen: Boolean,
    targetCompanion: CompanionProfile?,
    currentUser: User,
    onClose: () -> Unit,
    onTopUpCoins: () -> Unit,
    onSendGiftRequest: (CompanionGiftRequest) -> Unit
) {
    if (!isOpen || targetCompanion == null) return

    val gifts = CompanionMockData.giftCatalog
    var selectedGift by remember { mutableStateOf(gifts[1]) } // default ช่อดอกไม้ 50 coins
    var customMessage by remember { mutableStateOf("สวัสดีครับ ชื่นชอบโปรไฟล์และทัศนคติมาก อยากขออนุญาตส่งของขวัญทักทายคุยกันครับ 😊") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val hasEnoughCoins = currentUser.coins >= selectedGift.coins

    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .wrapContentHeight(),
            shape = RoundedCornerShape(24.dp),
            color = Slate900,
            border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(PinkPrimary.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.CardGiftcard, contentDescription = null, tint = PinkLight, modifier = Modifier.size(20.dp))
                        }
                        Column {
                            Text("ส่งของขวัญขอคุย (Gift Request)", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White)
                            Text("ถึง: ${targetCompanion.displayName}", fontSize = 11.sp, color = Slate400)
                        }
                    }

                    IconButton(onClick = onClose) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Slate400)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Receiver Preview
                Surface(
                    color = Slate950,
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Slate800),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        AsyncImage(
                            model = targetCompanion.avatar,
                            contentDescription = targetCompanion.displayName,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                        )
                        Column {
                            Text(targetCompanion.displayName, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
                            Text(targetCompanion.introBio.take(50) + "...", fontSize = 10.sp, color = Slate400)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text("เลือกของขวัญที่ต้องการมอบ:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Spacer(modifier = Modifier.height(8.dp))

                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(gifts) { gift ->
                        val isSelected = gift.id == selectedGift.id
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = if (isSelected) PinkPrimary.copy(alpha = 0.2f) else Slate950,
                            border = androidx.compose.foundation.BorderStroke(
                                1.5.dp,
                                if (isSelected) PinkPrimary else Slate800
                            ),
                            modifier = Modifier
                                .width(90.dp)
                                .clickable { selectedGift = gift }
                        ) {
                            Column(
                                modifier = Modifier.padding(8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(gift.emoji, fontSize = 28.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(gift.name, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                Text("🪙 ${gift.coins}", fontSize = 10.sp, color = AmberGold, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text("ข้อความทักทายถึงผู้รับ:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = customMessage,
                    onValueChange = { customMessage = it },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PinkPrimary,
                        unfocusedBorderColor = Slate700,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Important Policy Banner
                Surface(
                    color = Slate950,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        "🛡️ ข้อตกลง: ผู้รับมีสิทธิ์ตัดสินใจว่าจะ Accept หรือ Reject ด้วยตนเองเสมอ หากผู้รับปฏิเสธ ระบบจะไม่เปิดสิทธิ์แชท การจ่ายเงินไม่สามารถบังคับให้อีกฝ่ายคุยได้",
                        fontSize = 10.sp,
                        color = Slate400,
                        modifier = Modifier.padding(8.dp),
                        lineHeight = 14.sp
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Wallet / Coins Status
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("เหรียญของคุณ:", fontSize = 11.sp, color = Slate400)
                        Text("🪙 ${currentUser.coins}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AmberLight)
                    }

                    if (!hasEnoughCoins) {
                        TextButton(onClick = onTopUpCoins) {
                            Text("เติมเหรียญ", color = AmberGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                if (errorMessage != null) {
                    Text(errorMessage ?: "", color = RoseLight, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
                }

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = {
                        if (!hasEnoughCoins) {
                            errorMessage = "เหรียญไม่เพียงพอ กรุณาเติมเหรียญก่อนส่งของขวัญ"
                            return@Button
                        }
                        val request = CompanionGiftRequest(
                            id = "greq_${System.currentTimeMillis()}",
                            senderId = currentUser.id,
                            senderName = currentUser.displayName,
                            senderAvatar = currentUser.avatar,
                            receiverId = targetCompanion.userId,
                            receiverName = targetCompanion.displayName,
                            gift = selectedGift,
                            message = customMessage
                        )
                        SoundService.playGiftFanfare()
                        onSendGiftRequest(request)
                        onClose()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("ส่งของขวัญ (${selectedGift.coins} Coins) และส่งคำขอ", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/**
 * การ์ดแสดงคำขอของขวัญแบบเด่นสำหรับผู้รับ (Prominent Gift Request Card for Receiver)
 * กฎข้อ 7: ผู้รับเห็นคำขอแบบเด่น, ถ้ากด Accept: เปิดสิทธิ์แชท + ได้รับมูลค่าของขวัญ, ถ้า Reject: ไม่เปิดแชท
 */
@Composable
fun CompanionIncomingGiftRequestCard(
    request: CompanionGiftRequest,
    onAccept: () -> Unit,
    onReject: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = Slate900,
        border = androidx.compose.foundation.BorderStroke(2.dp, AmberGold),
        shadowElevation = 8.dp,
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Prominent Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("🎁", fontSize = 20.sp)
                    Text(
                        "คำขอคุยพร้อมของขวัญสุดพิเศษ!",
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp,
                        color = AmberLight
                    )
                }

                Surface(
                    color = AmberGold.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        "+${(request.gift.coins * 0.8).toInt()} Coins",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = AmberGold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Sender Details
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                AsyncImage(
                    model = request.senderAvatar,
                    contentDescription = request.senderName,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .border(2.dp, PinkPrimary, CircleShape)
                )

                Column {
                    Text(request.senderName, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
                    Text("ได้ส่งของขวัญ: ${request.gift.emoji} ${request.gift.name} (${request.gift.coins} Coins)", fontSize = 11.sp, color = PinkLight)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Surface(
                color = Slate950,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    "💬 \"${request.message}\"",
                    fontSize = 12.sp,
                    color = Slate200,
                    modifier = Modifier.padding(10.dp)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                "คุณเป็นผู้ตัดสินใจเอง 100%: กดรับเพื่อรับเหรียญเข้ากระเป๋าและเปิดแชท หรือกดปฏิเสธ",
                fontSize = 10.sp,
                color = Slate400
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Decision Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onReject,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Slate400),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Slate700)
                ) {
                    Text("ปฏิเสธคำขอ", fontSize = 12.sp)
                }

                Button(
                    onClick = onAccept,
                    modifier = Modifier.weight(1.4f),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen)
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, tint = Slate950, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("ยอมรับ & เปิดแชท", color = Slate950, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }
    }
}
