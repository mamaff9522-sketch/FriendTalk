package com.example.companion.model

/**
 * บันทึก Audit Log เมื่อ Admin มีการเปิดดูข้อมูลเชิงลึก
 * ตามข้อ 10: ห้าม Admin เปิดอ่านข้อความส่วนตัวทั่วไปโดยไม่มีเหตุผล
 * ทำ Audit Log ทุกครั้งที่ Admin เปิดดูข้อมูลละเอียด
 */
data class CompanionAdminAuditLog(
    val id: String,
    val adminId: String,
    val adminName: String,
    val action: String,
    val targetType: String, // "companion_kyc", "report_inspection", "session_details", "rate_modification"
    val targetId: String,
    val reasonOrJustification: String,
    val timestamp: Long = System.currentTimeMillis(),
    val formattedTime: String = "เมื่อสักครู่"
)

/**
 * รายงานความปลอดภัยที่เกี่ยวข้องกับเพื่อนคุย
 * ข้อ 10: ถ้ามี Report ให้แสดงเฉพาะข้อมูลที่จำเป็นต่อการตรวจสอบ
 */
data class CompanionSafetyReport(
    val id: String,
    val reporterId: String,
    val reporterName: String,
    val reportedCompanionId: String,
    val reportedCompanionName: String,
    val sessionId: String?,
    val reason: String, // "inappropriate_behavior", "spam", "harassment", "fake_profile", "scam"
    val relevantSnippet: String, // เฉพาะข้อความหรือบริบทที่เป็นปัญหา
    val status: String = "pending", // "pending", "reviewed_dismissed", "reviewed_penalty_applied"
    val adminNotes: String? = null,
    val createdAt: String = "วันนี้"
)
