package com.example.companion.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.companion.model.*
import com.example.model.User
import com.example.service.SoundService
import com.example.ui.theme.*
import kotlinx.coroutines.delay

@Composable
fun CompanionSessionActiveDialog(
    isOpen: Boolean,
    companion: CompanionProfile?,
    sessionType: CompanionSessionType,
    currentUser: User,
    rateCoinsPerMinute: Int,
    onClose: () -> Unit,
    onTopUpCoinsRequested: () -> Unit,
    onDeductCoinsFromUser: (Int) -> Unit,
    onSessionCompleted: (session: CompanionSession, earnings: Int, rating: Int?, comment: String?) -> Unit
) {
    if (!isOpen || companion == null) return

    var isAccepted by remember { mutableStateOf(false) }
    var secondsElapsed by remember { mutableStateOf(0) }
    var currentClientCoins by remember { mutableStateOf(currentUser.coins) }
    var totalCoinsDeducted by remember { mutableStateOf(0) }
    var isMuted by remember { mutableStateOf(false) }
    var isVideoOff by remember { mutableStateOf(false) }

    // Text messages during session
    var textInput by remember { mutableStateOf("") }
    var chatMessages by remember {
        mutableStateOf(
            listOf(
                "ระบบ" to "เชื่อมต่อกับ ${companion.displayName} สำเร็จ อัตราค่าบริการ $rateCoinsPerMinute Coins/นาที"
            )
        )
    }

    // Auto-termination state
    var isAutoTerminated by remember { mutableStateOf(false) }

    // Rating Dialog after session
    var showRatingStep by remember { mutableStateOf(false) }
    var ratingScore by remember { mutableStateOf(5) }
    var reviewComment by remember { mutableStateOf("คุยสนุกมาก ให้คำแนะนำและรับฟังอย่างจริงใจ ประทับใจมากครับ ✨") }

    // Keep synced with currentUser coins (e.g. if user topped up during session!)
    LaunchedEffect(currentUser.coins) {
        currentClientCoins = currentUser.coins
    }

    // Simulate Companion accepting the call / chat after 1.5 seconds
    LaunchedEffect(Unit) {
        delay(1500)
        isAccepted = true
        SoundService.playMatch()
        chatMessages = chatMessages + ("companion" to "สวัสดีค่ะคุณ ${currentUser.displayName} วันนี้มีเรื่องอะไรอยากเล่าหรือปรึกษา ยินดีรับฟังนะคะ 😊")
    }

    // Real-time Timer & Credit Deduction
    // กฎข้อ 5: เมื่ออีกฝ่ายกดรับ ให้เริ่มจับเวลา หักเครดิตตามเวลาจริง แสดงเครดิตคงเหลือ เมื่อเครดิตใกล้หมดให้แจ้งเตือน เมื่อเครดิตหมดให้จบ Session อัตโนมัติ ห้ามเครดิตติดลบ
    LaunchedEffect(isAccepted, isAutoTerminated) {
        if (isAccepted && !isAutoTerminated) {
            while (true) {
                delay(1000)
                secondsElapsed += 1

                // หักเหรียญทุกๆ 10 วินาทีตามสัดส่วน (ratePerMinute / 6)
                // หรืออย่างน้อย 1 เหรียญ เพื่อให้ผู้ใช้เห็นการหักเครดิตตามเวลาจริง
                if (secondsElapsed % 10 == 0) {
                    val sliceCost = maxOf(1, (rateCoinsPerMinute / 6.0).toInt())
                    if (currentClientCoins >= sliceCost) {
                        currentClientCoins -= sliceCost
                        totalCoinsDeducted += sliceCost
                        onDeductCoinsFromUser(sliceCost)
                    } else {
                        // ไม่พอจ่าย -> จบ Session ทันที ห้ามเครดิตติดลบ
                        isAutoTerminated = true
                        SoundService.playPop()
                        break
                    }
                }
            }
        }
    }

    val isLowCredit = currentClientCoins in 1..rateCoinsPerMinute

    val minutes = secondsElapsed / 60
    val seconds = secondsElapsed % 60
    val formattedTime = String.format("%02d:%02d", minutes, seconds)

    Dialog(
        onDismissRequest = {
            if (!showRatingStep) {
                showRatingStep = true
            }
        },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Slate950
        ) {
            if (showRatingStep) {
                // Post-Session Rating & Review
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(70.dp)
                            .clip(CircleShape)
                            .background(AmberGold.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Star, contentDescription = null, tint = AmberGold, modifier = Modifier.size(36.dp))
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text("ให้คะแนนการสนทนา", fontWeight = FontWeight.Black, fontSize = 20.sp, color = Color.White)
                    Text("คะแนนของคุณจะช่วยอัปเดต Level ของ ${companion.displayName}", fontSize = 12.sp, color = Slate400)

                    Spacer(modifier = Modifier.height(16.dp))

                    // Stars
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        (1..5).forEach { star ->
                            IconButton(onClick = { ratingScore = star }) {
                                Icon(
                                    imageVector = if (star <= ratingScore) Icons.Default.Star else Icons.Default.StarBorder,
                                    contentDescription = "$star ดาว",
                                    tint = if (star <= ratingScore) AmberGold else Slate600,
                                    modifier = Modifier.size(36.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = reviewComment,
                        onValueChange = { reviewComment = it },
                        label = { Text("ความประทับใจ / ข้อความรีวิว", fontSize = 12.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PinkPrimary,
                            unfocusedBorderColor = Slate700,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Button(
                        onClick = {
                            val session = CompanionSession(
                                id = "sess_${System.currentTimeMillis()}",
                                clientId = currentUser.id,
                                clientName = currentUser.displayName,
                                companionId = companion.id,
                                companionName = companion.displayName,
                                type = sessionType,
                                rateCoinsPerMinute = rateCoinsPerMinute,
                                durationSeconds = secondsElapsed,
                                totalCoinsDeducted = totalCoinsDeducted,
                                companionEarningsCoins = (totalCoinsDeducted * 0.85).toInt(),
                                status = if (isAutoTerminated) CompanionSessionStatus.TERMINATED_INSUFFICIENT_CREDITS else CompanionSessionStatus.COMPLETED,
                                terminationReason = if (isAutoTerminated) "เครดิตคงเหลือหมด ระบบตัดจบอัตโนมัติ" else "ผู้ใช้สิ้นสุดการสนทนา",
                                clientRating = ratingScore,
                                clientReviewComment = reviewComment
                            )
                            val earnings = (totalCoinsDeducted * 0.85).toInt()
                            onSessionCompleted(session, earnings, ratingScore, reviewComment)
                            onClose()
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("ส่งคะแนนรีวิวและเสร็จสิ้น", fontWeight = FontWeight.Bold)
                    }
                }
                return@Surface
            }

            // Main Active Session Layout
            Column(modifier = Modifier.fillMaxSize()) {
                // Top Session Bar
                Surface(
                    color = Slate900,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(top = 36.dp, bottom = 12.dp, start = 14.dp, end = 14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Companion Info
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(CircleShape)
                                        .border(2.dp, PinkPrimary, CircleShape)
                                ) {
                                    AsyncImage(
                                        model = companion.avatar,
                                        contentDescription = companion.displayName,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }

                                Column {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(companion.displayName, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                                        Surface(
                                            color = Color(companion.level.badgeColorHex).copy(alpha = 0.2f),
                                            shape = RoundedCornerShape(4.dp),
                                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(companion.level.badgeColorHex))
                                        ) {
                                            Text(
                                                text = companion.level.name,
                                                color = Color(companion.level.badgeColorHex),
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        text = "${sessionType.titleThai} • $rateCoinsPerMinute Coins/นาที",
                                        fontSize = 11.sp,
                                        color = Slate400
                                    )
                                }
                            }

                            // Real-time Timer
                            Surface(
                                color = if (isAccepted) EmeraldGreen.copy(alpha = 0.2f) else Slate800,
                                shape = RoundedCornerShape(12.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, if (isAccepted) EmeraldGreen else Slate700)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Timer,
                                        contentDescription = null,
                                        tint = if (isAccepted) EmeraldGreen else Slate400,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = if (isAccepted) formattedTime else "กำลังรอรับ...",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isAccepted) EmeraldGreen else Slate400
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Real-time Credit Balance Bar
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text("เครดิตคงเหลือ:", fontSize = 11.sp, color = Slate400)
                                Text(
                                    text = "🪙 $currentClientCoins Coins",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isLowCredit) RosePrimary else AmberLight
                                )
                                Text(
                                    text = "(ใช้ไป $totalCoinsDeducted Coins)",
                                    fontSize = 10.sp,
                                    color = Slate500
                                )
                            }

                            // Top Up Coins Button (Inside session)
                            Button(
                                onClick = onTopUpCoinsRequested,
                                colors = ButtonDefaults.buttonColors(containerColor = AmberGold),
                                shape = RoundedCornerShape(12.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, tint = Slate950, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("เติมเครดิต", color = Slate950, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                            }
                        }
                    }
                }

                // Low Credit Warning Banner (ข้อ 5)
                AnimatedVisibility(visible = isLowCredit && !isAutoTerminated) {
                    Surface(
                        color = RosePrimary.copy(alpha = 0.25f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, RosePrimary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = RosePrimary, modifier = Modifier.size(16.dp))
                                Text("⚠️ เครดิตใกล้หมดแล้ว! กรุณาเติมเหรียญเพื่อคุยต่อ", fontSize = 11.sp, color = RoseLight, fontWeight = FontWeight.Bold)
                            }
                            TextButton(onClick = onTopUpCoinsRequested) {
                                Text("เติมทันที", color = AmberGold, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                        }
                    }
                }

                // Auto-Terminated Banner (ข้อ 5: เครดิตหมดให้จบ Session อัตโนมัติ ห้ามเครดิตติดลบ)
                if (isAutoTerminated) {
                    Surface(
                        color = RosePrimary.copy(alpha = 0.35f),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, RosePrimary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.HourglassDisabled, contentDescription = null, tint = RosePrimary, modifier = Modifier.size(32.dp))
                            Text(
                                "⛔ เครดิตคงเหลือหมดแล้ว",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = Color.White
                            )
                            Text(
                                "ระบบได้ทำการสิ้นสุดการสนทนาโดยอัตโนมัติ เพื่อป้องกันไม่ให้เครดิตติดลบตามข้อกำหนด",
                                fontSize = 11.sp,
                                color = Slate200,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                            Button(
                                onClick = { showRatingStep = true },
                                colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("ประเมินความพึงพอใจและปิด", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }

                // Call / Chat Area
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(12.dp)
                ) {
                    if (sessionType == CompanionSessionType.VOICE || sessionType == CompanionSessionType.VIDEO) {
                        // Voice / Video View
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(130.dp)
                                    .clip(CircleShape)
                                    .border(3.dp, if (sessionType == CompanionSessionType.VIDEO) PinkPrimary else EmeraldGreen, CircleShape)
                            ) {
                                AsyncImage(
                                    model = companion.avatar,
                                    contentDescription = companion.displayName,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Text(companion.displayName, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color.White)
                            Text(
                                if (!isAccepted) "กำลังรอให้เพื่อนคุยตอบรับ..." else "กำลังสนทนา • สัญญาณคุณภาพสูง HD",
                                fontSize = 12.sp,
                                color = if (!isAccepted) AmberGold else EmeraldGreen
                            )
                        }
                    } else {
                        // Text Chat View
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(chatMessages) { (sender, text) ->
                                val isMe = sender == "me"
                                val isSys = sender == "ระบบ"

                                if (isSys) {
                                    Surface(
                                        color = Slate900,
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(text, fontSize = 10.sp, color = Slate400, modifier = Modifier.padding(8.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                                    }
                                } else {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = if (isMe) Arrangement.End else Arrangement.Start
                                    ) {
                                        Surface(
                                            color = if (isMe) PinkPrimary else Slate800,
                                            shape = RoundedCornerShape(14.dp)
                                        ) {
                                            Text(
                                                text = text,
                                                color = Color.White,
                                                fontSize = 13.sp,
                                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Bottom Controls / Text Input
                Surface(
                    color = Slate900,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                        if (sessionType == CompanionSessionType.TEXT && !isAutoTerminated) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedTextField(
                                    value = textInput,
                                    onValueChange = { textInput = it },
                                    placeholder = { Text("พิมพ์ข้อความคุยกับเพื่อน...", fontSize = 12.sp) },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(20.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = PinkPrimary,
                                        unfocusedBorderColor = Slate700,
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White
                                    )
                                )

                                IconButton(
                                    onClick = {
                                        if (textInput.isNotBlank()) {
                                            val myMsg = textInput
                                            chatMessages = chatMessages + ("me" to myMsg)
                                            textInput = ""
                                            SoundService.playMessage()
                                        }
                                    },
                                    modifier = Modifier
                                        .clip(CircleShape)
                                        .background(PinkPrimary)
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color.White)
                                }
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                        }

                        // Bottom Actions Row (Mute, Video, End Session)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceAround,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (sessionType != CompanionSessionType.TEXT) {
                                IconButton(
                                    onClick = { isMuted = !isMuted },
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(CircleShape)
                                        .background(if (isMuted) RosePrimary else Slate800)
                                ) {
                                    Icon(if (isMuted) Icons.Default.MicOff else Icons.Default.Mic, contentDescription = "Mic", tint = Color.White)
                                }

                                if (sessionType == CompanionSessionType.VIDEO) {
                                    IconButton(
                                        onClick = { isVideoOff = !isVideoOff },
                                        modifier = Modifier
                                            .size(46.dp)
                                            .clip(CircleShape)
                                            .background(if (isVideoOff) RosePrimary else Slate800)
                                    ) {
                                        Icon(if (isVideoOff) Icons.Default.VideocamOff else Icons.Default.Videocam, contentDescription = "Video", tint = Color.White)
                                    }
                                }
                            }

                            // End Session Button
                            Button(
                                onClick = { showRatingStep = true },
                                colors = ButtonDefaults.buttonColors(containerColor = RosePrimary),
                                shape = RoundedCornerShape(16.dp),
                                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
                            ) {
                                Icon(Icons.Default.CallEnd, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("สิ้นสุดการสนทนา", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
