package com.example.companion.service

import com.example.companion.model.*

/**
 * จัดการ Session, การจับเวลา และการหักเครดิตตามเวลาจริง
 */
class CompanionSessionManager {

    /**
     * ตรวจสอบว่าเครดิตเพียงพอที่จะเริ่มคุยอย่างน้อย 1 นาทีหรือไม่
     */
    fun canStartSession(clientCoins: Int, ratePerMin: Int): Boolean {
        return clientCoins >= ratePerMin && ratePerMin > 0
    }

    /**
     * คำนวณการหักเครดิตตามรอบเวลาจริง (เช่น ทุกๆ 10 หรือ 30 หรือ 60 วินาที)
     * เพื่อให้ผู้ใช้เห็นเหรียญลดลงแบบเรียลไทม์ และแจ้งเตือนเมื่อเครดิตใกล้หมด
     */
    fun calculateCostForSeconds(secondsElapsed: Int, ratePerMinute: Int): Int {
        if (secondsElapsed <= 0) return 0
        // ปัดขึ้นทีละ 10 วินาที หรือคำนวณตามสัดส่วนเวลา
        val minutesFraction = secondsElapsed / 60.0
        return maxOf(1, kotlin.math.ceil(minutesFraction * ratePerMinute).toInt())
    }

    /**
     * ตรวจสอบว่าเครดิตใกล้หมดหรือไม่ (เหลือน้อยกว่าค่าบริการ 1 นาที)
     */
    fun isLowCredit(remainingCoins: Int, ratePerMinute: Int): Boolean {
        return remainingCoins in 1..ratePerMinute
    }

    /**
     * ตรวจสอบว่าเครดิตหมดหรือไม่
     */
    fun isOutOfCredits(remainingCoins: Int): Boolean {
        return remainingCoins <= 0
    }
}
