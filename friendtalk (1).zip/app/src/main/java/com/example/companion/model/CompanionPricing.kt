package com.example.companion.model

/**
 * กำหนดเรตราคาของแต่ละ Level (Coin ต่อนาที)
 * ผู้ใช้ไม่สามารถตั้งราคาเองได้ ระบบกำหนดตาม Level
 * Admin สามารถแก้ไขเรตราคาของแต่ละ Level ได้
 */
data class CompanionLevelRate(
    val level: CompanionLevel,
    val textChatCoinsPerMin: Int,
    val voiceCallCoinsPerMin: Int,
    val videoCallCoinsPerMin: Int
)

data class CompanionPricingConfig(
    val rates: Map<CompanionLevel, CompanionLevelRate> = defaultRates()
) {
    fun getRate(level: CompanionLevel, type: CompanionSessionType): Int {
        val levelRate = rates[level] ?: defaultRates()[level] ?: CompanionLevelRate(level, 5, 10, 20)
        return when (type) {
            CompanionSessionType.TEXT -> levelRate.textChatCoinsPerMin
            CompanionSessionType.VOICE -> levelRate.voiceCallCoinsPerMin
            CompanionSessionType.VIDEO -> levelRate.videoCallCoinsPerMin
        }
    }

    companion object {
        fun defaultRates(): Map<CompanionLevel, CompanionLevelRate> = mapOf(
            CompanionLevel.STARTER to CompanionLevelRate(CompanionLevel.STARTER, textChatCoinsPerMin = 5, voiceCallCoinsPerMin = 10, videoCallCoinsPerMin = 20),
            CompanionLevel.BRONZE to CompanionLevelRate(CompanionLevel.BRONZE, textChatCoinsPerMin = 8, voiceCallCoinsPerMin = 15, videoCallCoinsPerMin = 30),
            CompanionLevel.SILVER to CompanionLevelRate(CompanionLevel.SILVER, textChatCoinsPerMin = 12, voiceCallCoinsPerMin = 25, videoCallCoinsPerMin = 45),
            CompanionLevel.GOLD to CompanionLevelRate(CompanionLevel.GOLD, textChatCoinsPerMin = 18, voiceCallCoinsPerMin = 35, videoCallCoinsPerMin = 65),
            CompanionLevel.PLATINUM to CompanionLevelRate(CompanionLevel.PLATINUM, textChatCoinsPerMin = 25, voiceCallCoinsPerMin = 50, videoCallCoinsPerMin = 90),
            CompanionLevel.VIP to CompanionLevelRate(CompanionLevel.VIP, textChatCoinsPerMin = 35, voiceCallCoinsPerMin = 75, videoCallCoinsPerMin = 130)
        )
    }
}
