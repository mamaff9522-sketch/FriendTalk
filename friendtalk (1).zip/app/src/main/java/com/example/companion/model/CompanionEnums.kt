package com.example.companion.model

/**
 * สถานะของเพื่อนคุย
 */
enum class CompanionStatus {
    PENDING_REVIEW, // รอแอดมินตรวจสอบ (ห้ามเปิดรับคนคุยและห้ามรับรายได้)
    APPROVED,       // อนุมัติแล้ว พร้อมให้บริการ
    REJECTED,       // ถูกปฏิเสธคำขอ
    SUSPENDED       // ถูกระงับการให้บริการชั่วคราว/ถาวร
}

/**
 * ระดับ Level ของเพื่อนคุย คำนวณจากคะแนนรีวิว, ชม. คุย, คุยซ้ำ, ร้องเรียน, ประวัติลงโทษ
 */
enum class CompanionLevel(val titleThai: String, val badgeColorHex: Long) {
    STARTER("Starter", 0xFF64748B),
    BRONZE("Bronze", 0xFFCD7F32),
    SILVER("Silver", 0xFF94A3B8),
    GOLD("Gold", 0xFFF59E0B),
    PLATINUM("Platinum", 0xFF06B6D4),
    VIP("VIP Diamond", 0xFFEC4899)
}

/**
 * ประเภทการคุย
 */
enum class CompanionSessionType(val titleThai: String) {
    TEXT("ข้อความแชต"),
    VOICE("โทรเสียง"),
    VIDEO("วิดีโอคอล")
}

/**
 * สถานะเซสชันการคุย
 */
enum class CompanionSessionStatus {
    REQUESTED,
    ACTIVE,
    COMPLETED,
    TERMINATED_INSUFFICIENT_CREDITS,
    CANCELLED
}

/**
 * สถานะคำขอของขวัญเพื่อเปิดแชต
 */
enum class GiftRequestStatus {
    PENDING,
    ACCEPTED,
    REJECTED,
    EXPIRED
}
