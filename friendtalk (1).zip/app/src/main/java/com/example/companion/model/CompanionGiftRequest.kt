package com.example.companion.model

/**
 * แคตตาล็อกของขวัญสำหรับส่งขอคุย
 */
data class CompanionGiftCatalogItem(
    val id: String,
    val name: String,
    val emoji: String,
    val coins: Int,
    val description: String
)

/**
 * คำขอคุยพร้อมของขวัญ (Gift Request)
 * กฎ: ผู้รับเห็นคำขอแบบเด่น, ผู้รับต้องเป็นคนตัดสินใจเองเสมอ, ห้ามการจ่ายเงินบังคับให้อีกฝ่ายต้องคุย
 */
data class CompanionGiftRequest(
    val id: String,
    val senderId: String,
    val senderName: String,
    val senderAvatar: String,
    val receiverId: String,
    val receiverName: String,
    val gift: CompanionGiftCatalogItem,
    val message: String,
    val status: GiftRequestStatus = GiftRequestStatus.PENDING,
    val createdAtTimestamp: Long = System.currentTimeMillis(),
    val respondedAtTimestamp: Long? = null
)
