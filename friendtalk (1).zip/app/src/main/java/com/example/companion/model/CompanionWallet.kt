package com.example.companion.model

/**
 * บัญชีธนาคารสำหรับถอนเงิน
 * ตามข้อ 6: บัญชีธนาคารให้ขอเฉพาะตอนผู้ใช้ต้องการถอนเงินเท่านั้น
 */
data class CompanionBankAccount(
    val bankName: String,
    val accountNumber: String,
    val accountHolderName: String
)

/**
 * รายการประวัติธุรกรรมใน Wallet ของเพื่อนคุย
 */
data class CompanionWalletTransaction(
    val id: String,
    val type: String, // "session_earning", "gift_request_reward", "withdrawal"
    val amountCoins: Int,
    val description: String,
    val timestamp: Long = System.currentTimeMillis(),
    val formattedTime: String = "วันนี้"
)

/**
 * คำขอถอนเงินรายได้เพื่อนคุย
 */
data class CompanionWithdrawalRequest(
    val id: String,
    val companionId: String,
    val companionName: String,
    val amountCoins: Int,
    val amountBaht: Int,
    val bankAccount: CompanionBankAccount,
    val status: String = "pending", // "pending", "approved", "rejected"
    val requestedAt: String = "วันนี้",
    val processedAt: String? = null
)

/**
 * ข้อมูลกระเป๋าเงิน (Wallet) ของเพื่อนคุย
 */
data class CompanionWallet(
    val companionId: String,
    val todayEarningsCoins: Int = 0,
    val monthEarningsCoins: Int = 0,
    val totalEarningsCoins: Int = 0,
    val currentBalanceCoins: Int = 0,
    val transactions: List<CompanionWalletTransaction> = emptyList(),
    val sessionHistory: List<CompanionSession> = emptyList(),
    val bankAccount: CompanionBankAccount? = null
)
