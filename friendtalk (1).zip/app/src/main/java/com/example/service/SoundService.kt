package com.example.service

import android.media.AudioManager
import android.media.ToneGenerator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

object SoundService {
    private var toneGenerator: ToneGenerator? = null

    init {
        try {
            toneGenerator = ToneGenerator(AudioManager.STREAM_MUSIC, 70)
        } catch (_: Exception) {
        }
    }

    fun playPop() {
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 40)
        } catch (_: Exception) {}
    }

    fun playCoin() {
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_DTMF_D, 90)
        } catch (_: Exception) {}
    }

    fun playHeart() {
        playPop()
    }

    fun playMatch() {
        CoroutineScope(Dispatchers.Default).launch {
            try {
                toneGenerator?.startTone(ToneGenerator.TONE_DTMF_1, 80)
                delay(90)
                toneGenerator?.startTone(ToneGenerator.TONE_DTMF_5, 80)
                delay(90)
                toneGenerator?.startTone(ToneGenerator.TONE_DTMF_9, 120)
            } catch (_: Exception) {}
        }
    }

    fun playGiftFanfare() {
        CoroutineScope(Dispatchers.Default).launch {
            try {
                toneGenerator?.startTone(ToneGenerator.TONE_DTMF_3, 70)
                delay(80)
                toneGenerator?.startTone(ToneGenerator.TONE_DTMF_6, 70)
                delay(80)
                toneGenerator?.startTone(ToneGenerator.TONE_DTMF_9, 70)
                delay(80)
                toneGenerator?.startTone(ToneGenerator.TONE_DTMF_D, 180)
            } catch (_: Exception) {}
        }
    }

    fun playMessage() {
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_ACK, 60)
        } catch (_: Exception) {}
    }

    fun playRadarBlip() {
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_PROMPT, 60)
        } catch (_: Exception) {}
    }

    fun playSuccess() {
        playCoin()
    }
}
