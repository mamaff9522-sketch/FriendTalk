package com.example.model

data class Post(
    val id: String,
    val authorId: String,
    val content: String,
    val mediaUrls: List<String> = emptyList(),
    val likes: List<String> = emptyList(),
    val commentsCount: Int = 0,
    val sharesCount: Int = 0,
    val createdAt: String = "เมื่อสักครู่",
    val tags: List<String> = emptyList(),
    val isPinned: Boolean = false
)

data class Comment(
    val id: String,
    val postId: String,
    val authorId: String,
    val text: String,
    val createdAt: String = "เมื่อสักครู่",
    val likes: List<String> = emptyList()
)

data class Story(
    val id: String,
    val authorId: String,
    val mediaUrl: String,
    val caption: String? = null,
    val createdAt: String = "เมื่อสักครู่",
    val expiresAt: String = "24 ชั่วโมง",
    val viewedBy: List<String> = emptyList()
)
