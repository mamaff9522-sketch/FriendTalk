package com.example.model

enum class UserRole {
    USER, MODERATOR, ADMIN, SUPERADMIN
}

enum class Gender {
    MALE, FEMALE, NON_BINARY, OTHER
}

data class UserLocation(
    val province: String,
    val distanceKm: Double = 0.0,
    val isSharing: Boolean = true
)

data class User(
    val id: String,
    val username: String,
    val displayName: String,
    val avatar: String,
    val coverPhoto: String? = null,
    val age: Int,
    val gender: Gender,
    val bio: String,
    val role: UserRole = UserRole.USER,
    val isCreator: Boolean = false,
    val isVerified: Boolean = false,
    val isOnline: Boolean = true,
    val lastActive: String = "ออนไลน์ขณะนี้",
    val coins: Int = 1500,
    val diamonds: Int = 0,
    val followersCount: Int = 0,
    val followingCount: Int = 0,
    val friendsCount: Int = 0,
    val likesCount: Int = 0,
    val location: UserLocation = UserLocation("กรุงเทพมหานคร", 0.0, true),
    val isSuspended: Boolean = false,
    val isBanned: Boolean = false,
    val photos: List<String> = emptyList(),
    val badges: List<String> = emptyList(),
    val interests: List<String> = emptyList(),
    val giftsReceivedTotal: Int = 0,
    val createdAt: String = ""
)
