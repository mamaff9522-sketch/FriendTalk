package com.example.model

data class Club(
    val id: String,
    val name: String,
    val description: String,
    val coverImage: String,
    val memberCount: Int = 0,
    val category: String,
    val members: List<String> = emptyList(),
    val icon: String
)

data class ForumTopic(
    val id: String,
    val clubId: String,
    val authorId: String,
    val title: String,
    val content: String,
    val likes: List<String> = emptyList(),
    val commentsCount: Int = 0,
    val createdAt: String = "เมื่อสักครู่"
)
