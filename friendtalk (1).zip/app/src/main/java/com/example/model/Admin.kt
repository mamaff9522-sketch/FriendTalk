package com.example.model

data class Report(
    val id: String,
    val reporterId: String,
    val targetType: String, // "user", "post", "live"
    val targetId: String,
    val reason: String,
    val details: String? = null,
    val status: String = "pending", // "pending", "action_taken", "dismissed"
    val createdAt: String = "เมื่อสักครู่",
    val actionNote: String? = null
)

data class WithdrawalRequest(
    val id: String,
    val creatorId: String,
    val amountCoins: Int,
    val amountBaht: Int,
    val bankName: String,
    val accountNumber: String,
    val accountName: String,
    val status: String = "pending", // "pending", "approved", "rejected"
    val createdAt: String = "เมื่อสักครู่",
    val adminNote: String? = null
)

data class AdminLog(
    val id: String,
    val adminId: String,
    val adminName: String,
    val action: String,
    val targetType: String,
    val targetId: String,
    val details: String,
    val timestamp: String = "เมื่อสักครู่"
)

data class AppNotification(
    val id: String,
    val userId: String = "all",
    val title: String,
    val body: String,
    val type: String = "system", // "live", "gift", "like", "comment", "system"
    val linkTab: String? = null,
    val isRead: Boolean = false,
    val createdAt: String = "เมื่อสักครู่"
)

data class AppPermissions(
    val camera: Boolean = true,
    val microphone: Boolean = true,
    val geolocation: Boolean = true,
    val notifications: Boolean = true
)
