package com.example.model

import androidx.compose.ui.graphics.Color

data class SectionUiConfig(
    val id: String,
    val title: String,
    val subtitle: String = "",
    val isEnabled: Boolean = true,
    val order: Int = 0,
    val bannerImageUrl: String? = null,
    val buttonText: String? = null,
    val layoutType: String = "default" // "default", "grid", "cards", "compact", "hero"
)

data class PageUiConfig(
    val pageId: String,
    val pageTitle: String,
    val backgroundColorHex: String? = null,
    val heroImageUrl: String? = null,
    val sections: List<SectionUiConfig> = emptyList()
)

data class BottomNavTabConfig(
    val tabId: String, // "home", "discover", "live", "movie", "chat", "companion", "profile"
    val label: String,
    val iconName: String, // "Home", "Explore", "Radio", "Movie", "ChatBubble", "VolunteerActivism", "Person"
    val order: Int,
    val isEnabled: Boolean = true,
    val minAge: Int = 0
)

data class ThemeConfig(
    val themeMode: String = "dark", // "dark", "light"
    val primaryColorHex: String = "#EC4899", // PinkPrimary
    val secondaryColorHex: String = "#F43F5E", // RosePrimary
    val accentColorHex: String = "#F59E0B", // AmberGold
    val backgroundColorHex: String = "#020617", // Slate950
    val surfaceColorHex: String = "#0F172A", // Slate900
    val cardBorderColorHex: String = "#1E293B", // Slate800
    val textColorHex: String = "#FFFFFF",
    val textSecondaryColorHex: String = "#94A3B8", // Slate400
    val fontSizeScale: Float = 1.0f, // 0.85f, 1.0f, 1.15f, 1.3f
    val buttonSizeScale: Float = 1.0f, // 0.85f, 1.0f, 1.15f
    val spacingScale: Float = 1.0f, // 0.8f, 1.0f, 1.25f
    val cardCornerRadiusDp: Int = 16,
    val buttonCornerRadiusDp: Int = 14
)

data class AppUiConfig(
    val configVersion: String = "v1.0.0",
    val appName: String = "FriendTalk",
    val appLogoUrl: String = "",
    val headerTitle: String = "FriendTalk",
    val headerSubtitle: String = "สังคมเพื่อนใหม่ & ไลฟ์สตรีม",
    val theme: ThemeConfig = ThemeConfig(),
    val navigationTabs: List<BottomNavTabConfig> = defaultNavigationTabs(),
    val pages: Map<String, PageUiConfig> = defaultPages(),
    val lastUpdatedTimestamp: Long = System.currentTimeMillis(),
    val updatedBy: String = "System",
    val versionNotes: String = "Initial Configuration"
) {
    companion object {
        fun defaultNavigationTabs(): List<BottomNavTabConfig> = listOf(
            BottomNavTabConfig(tabId = "home", label = "หน้าแรก", iconName = "Home", order = 1, isEnabled = true),
            BottomNavTabConfig(tabId = "discover", label = "หาเพื่อน", iconName = "Explore", order = 2, isEnabled = true),
            BottomNavTabConfig(tabId = "companion", label = "เพื่อนคุย", iconName = "VolunteerActivism", order = 3, isEnabled = true, minAge = 18),
            BottomNavTabConfig(tabId = "live", label = "Live", iconName = "Radio", order = 4, isEnabled = true),
            BottomNavTabConfig(tabId = "movie", label = "วิดีโอ", iconName = "Movie", order = 5, isEnabled = true),
            BottomNavTabConfig(tabId = "chat", label = "แชต", iconName = "ChatBubble", order = 6, isEnabled = true),
            BottomNavTabConfig(tabId = "profile", label = "โปรไฟล์", iconName = "Person", order = 7, isEnabled = true)
        )

        fun defaultPages(): Map<String, PageUiConfig> = mapOf(
            "home" to PageUiConfig(
                pageId = "home",
                pageTitle = "หน้าแรก (Feed)",
                heroImageUrl = "https://images.unsplash.com/photo-1511632765486-a01980e01a18?w=800&auto=format&fit=crop&q=80",
                sections = listOf(
                    SectionUiConfig("feed_banner", "แบนเนอร์กิจกรรมไฮไลต์", "พบเพื่อนใหม่และส่งของขวัญได้ทันที", true, 1,
                        "https://images.unsplash.com/photo-1511632765486-a01980e01a18?w=800&auto=format&fit=crop&q=80",
                        buttonText = "โพสต์เรื่องราว"),
                    SectionUiConfig("story_bar", "สตอรี่และโมเมนต์", "อัปเดตเรื่องราวเพื่อนรอบตัว", true, 2),
                    SectionUiConfig("clubs_preview", "คลับและคอมมูนิตี้", "เลือกเข้าร่วมคลับที่ตรงใจคุณ", true, 3),
                    SectionUiConfig("posts_list", "ไทม์ไลน์โพสต์ทั้งหมด", "โพสต์ล่าสุดจากเพื่อนที่คุณติดตาม", true, 4)
                )
            ),
            "discover" to PageUiConfig(
                pageId = "discover",
                pageTitle = "หาเพื่อน (Discover)",
                heroImageUrl = "https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=800&auto=format&fit=crop&q=80",
                sections = listOf(
                    SectionUiConfig("discover_hero", "แบนเนอร์เรดาร์หาเพื่อน", "เรดาร์ตรวจจับเพื่อนในระยะใกล้", true, 1,
                        "https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=800&auto=format&fit=crop&q=80",
                        buttonText = "เปิดตำแหน่ง"),
                    SectionUiConfig("mode_selector", "ตัวเลือกโหมดค้นหา", "ใกล้เคียง, เรดาร์, เขย่า, สไวป์", true, 2),
                    SectionUiConfig("user_list", "รายชื่อสมาชิกแนะนำ", "เพื่อนใหม่น่าสนใจใกล้ตัวคุณ", true, 3)
                )
            ),
            "live" to PageUiConfig(
                pageId = "live",
                pageTitle = "ไลฟ์สด (Live Stream)",
                heroImageUrl = "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=800&auto=format&fit=crop&q=80",
                sections = listOf(
                    SectionUiConfig("live_banner", "แบนเนอร์ PK Battle & Event", "การแข่งขันไลฟ์ประจำสัปดาห์ แจกโบนัสเพชร", true, 1,
                        "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=800&auto=format&fit=crop&q=80",
                        buttonText = "เปิดห้องไลฟ์"),
                    SectionUiConfig("top_streamers", "อันดับสตรีมเมอร์ยอดนิยม", "สตรีมเมอร์ที่ได้รับของขวัญสูงสุด", true, 2),
                    SectionUiConfig("live_rooms_grid", "ห้องไลฟ์สดทั้งหมด", "ร่วมสนุก แชต และส่งของขวัญแบบเรียลไทม์", true, 3)
                )
            ),
            "movie" to PageUiConfig(
                pageId = "movie",
                pageTitle = "วิดีโอ & คอนเทนต์ (Movie / Short Video)",
                heroImageUrl = "https://images.unsplash.com/photo-1485846234645-a62644f84728?w=800&auto=format&fit=crop&q=80",
                sections = listOf(
                    SectionUiConfig("video_hero", "แบนเนอร์วิดีโอไฮไลต์", "คลิปวิดีโอสั้นและหนังสั้นยอดฮิต", true, 1,
                        "https://images.unsplash.com/photo-1485846234645-a62644f84728?w=800&auto=format&fit=crop&q=80",
                        buttonText = "ดูทั้งหมด"),
                    SectionUiConfig("category_chips", "หมวดหมู่วิดีโอ", "ตลก, ดนตรี, ไลฟ์สไตล์, ท่องเที่ยว, ละครสั้น", true, 2),
                    SectionUiConfig("trending_videos", "วิดีโอยอดนิยมประจำวัน", "คลิปที่มีผู้ชมและยอดแชร์สูงสุด", true, 3),
                    SectionUiConfig("video_feed", "ฟีดวิดีโอสำหรับคุณ", "เนื้อหาสร้างสรรค์จากครีเอเตอร์ FriendTalk", true, 4)
                )
            ),
            "companion" to PageUiConfig(
                pageId = "companion",
                pageTitle = "ระบบเพื่อนคุย (Companion)",
                heroImageUrl = "https://images.unsplash.com/photo-1517457373958-b7bdd4587205?w=800&auto=format&fit=crop&q=80",
                sections = listOf(
                    SectionUiConfig("companion_hero", "แบนเนอร์เพื่อนคุย", "เพื่อนคุยรับฟัง ปรึกษา คลายเหงา ผ่านการยืนยันตัวตน", true, 1,
                        "https://images.unsplash.com/photo-1517457373958-b7bdd4587205?w=800&auto=format&fit=crop&q=80",
                        buttonText = "สมัครเป็นเพื่อนคุย"),
                    SectionUiConfig("level_filter", "ตัวกรองระดับเลเวล", "Starter, Bronze, Silver, Gold, Platinum, VIP", true, 2),
                    SectionUiConfig("safety_banner", "นโยบายความปลอดภัยและยืนยันตัวตน (KYC)", "ห้ามคุยลามกอนาจาร ระบบดูแลตลอด 24 ชม.", true, 3),
                    SectionUiConfig("companion_grid", "รายชื่อเพื่อนคุยที่ออนไลน์", "เลือกเพื่อนคุยและเริ่มเซสชันได้ทันที", true, 4)
                )
            ),
            "chat" to PageUiConfig(
                pageId = "chat",
                pageTitle = "แชต & สนทนา (Chat)",
                heroImageUrl = "https://images.unsplash.com/photo-1577563908411-5077b6dc7624?w=800&auto=format&fit=crop&q=80",
                sections = listOf(
                    SectionUiConfig("chat_header", "แถบการสนทนา & สถานะ", "แชตทั้งหมดและเพื่อนที่ออนไลน์", true, 1, buttonText = "สร้างกลุ่ม"),
                    SectionUiConfig("online_friends", "เพื่อนออนไลน์ขณะนี้", "แตะเพื่อเริ่มบทสนทนา", true, 2),
                    SectionUiConfig("conversations_list", "รายการข้อความ", "ประวัติการแชตและข้อความล่าสุด", true, 3)
                )
            ),
            "profile" to PageUiConfig(
                pageId = "profile",
                pageTitle = "โปรไฟล์ของฉัน (Profile)",
                heroImageUrl = null,
                sections = listOf(
                    SectionUiConfig("profile_header", "ข้อมูลโปรไฟล์หลัก", "รูปโปรไฟล์ ปก ชื่อ และสถานะยืนยัน", true, 1, buttonText = "แก้ไขโปรไฟล์"),
                    SectionUiConfig("coins_summary", "กระเป๋าเหรียญและรายได้", "ยอดเหรียญ Coin และ Diamonds", true, 2, buttonText = "เติมเหรียญ"),
                    SectionUiConfig("menu_actions", "เมนูการตั้งค่าและแอดมิน", "แผงควบคุมระบบ, ศูนย์ครีเอเตอร์, สิทธิ์", true, 3)
                )
            )
        )
    }
}

data class ConfigVersionRecord(
    val version: String,
    val publishedAt: String,
    val publishedBy: String,
    val notes: String,
    val config: AppUiConfig,
    val isActive: Boolean = false
)

data class ApkBuildRecord(
    val buildId: String,
    val versionName: String,
    val versionCode: Int,
    val buildDate: String,
    val apkSizeMb: String,
    val status: String = "Build Successful",
    val apkFileName: String = "FriendTalk-v1.0.apk",
    val downloadPath: String = "/.build-outputs/app-debug.apk",
    val notes: String = "Official Release Build"
)

fun parseHexColor(hex: String?, fallback: Color): Color {
    if (hex.isNullOrBlank()) return fallback
    return try {
        val clean = hex.trim().removePrefix("#")
        val colorLong = when (clean.length) {
            6 -> "FF$clean".toLong(16)
            8 -> clean.toLong(16)
            else -> return fallback
        }
        Color(colorLong)
    } catch (e: Exception) {
        fallback
    }
}
