package com.example.model

enum class GiftTier {
    BASIC, MEDIUM, RARE, LEGENDARY
}

data class Gift(
    val id: String,
    val name: String,
    val icon: String,
    val coins: Int,
    val tier: GiftTier = GiftTier.BASIC
)

data class PkOpponent(
    val hostId: String,
    val score: Int = 0,
    val streamUrl: String? = null
)

data class LiveRoom(
    val id: String,
    val hostId: String,
    val title: String,
    val coverUrl: String,
    val category: String,
    val isLive: Boolean = true,
    val viewersCount: Int = 1,
    val currentGiftCoins: Int = 0,
    val heartsCount: Int = 0,
    val tags: List<String> = emptyList(),
    val isPkMode: Boolean = false,
    val pkOpponent: PkOpponent? = null,
    val pkScore: Int = 0,
    val mutedUserIds: List<String> = emptyList(),
    val bannedUserIds: List<String> = emptyList(),
    val startedAt: String = "เมื่อสักครู่"
)

data class LiveMessage(
    val id: String,
    val roomId: String,
    val senderId: String,
    val text: String,
    val type: String = "chat", // "chat", "gift", "system"
    val gift: GiftInfo? = null,
    val createdAt: String = "เมื่อสักครู่"
)

data class ActiveGiftAnimation(
    val id: String,
    val gift: Gift,
    val senderName: String,
    val receiverName: String
)
