package com.example.model

enum class MessageType {
    TEXT, IMAGE, VIDEO, AUDIO, STICKER, GIFT
}

data class GiftInfo(
    val giftId: String,
    val name: String,
    val icon: String,
    val coins: Int
)

data class ChatMessage(
    val id: String,
    val conversationId: String,
    val senderId: String,
    val text: String,
    val type: MessageType = MessageType.TEXT,
    val mediaUrl: String? = null,
    val giftInfo: GiftInfo? = null,
    val createdAt: String = "เมื่อสักครู่",
    val isRead: Boolean = false,
    val disappearingSeconds: Int? = null,
    val selfDestructAt: Long? = null
)

data class Conversation(
    val id: String,
    val type: String = "direct", // "direct" or "group"
    val name: String? = null,
    val avatar: String? = null,
    val participantIds: List<String> = emptyList(),
    val lastMessage: ChatMessage? = null,
    val unreadCounts: Map<String, Int> = emptyMap(),
    val updatedAt: String = "เมื่อสักครู่",
    val createdBy: String? = null,
    val groupAdmins: List<String> = emptyList(),
    val disappearingTimerDefault: Int = 0 // 0 = off, 5, 30, 60
)

enum class CallStatus {
    RINGING, CONNECTED, ENDED, REJECTED
}

data class CallSession(
    val id: String,
    val type: String = "audio", // "audio" or "video"
    val callerId: String,
    val receiverId: String,
    val status: CallStatus = CallStatus.RINGING,
    val startedAt: String = "",
    val durationSec: Int = 0
)
