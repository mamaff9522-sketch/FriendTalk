package com.example.ui.discover

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.User
import com.example.service.SoundService
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun ShakeView(
    currentUser: User,
    users: List<User>,
    friendIds: Set<String>,
    onToggleFriend: (String) -> Unit,
    onStartChat: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val candidates = remember(users, currentUser.id) {
        users.filter { it.id != currentUser.id && !it.isSuspended }
    }

    var isShaking by remember { mutableStateOf(false) }
    var matchedUser by remember { mutableStateOf<User?>(null) }
    val scope = rememberCoroutineScope()

    val infiniteTransition = rememberInfiniteTransition(label = "shake_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    fun triggerShake() {
        if (isShaking) return
        isShaking = true
        matchedUser = null
        SoundService.playRadarBlip()

        scope.launch {
            delay(2200)
            isShaking = false
            matchedUser = candidates.randomOrNull()
            SoundService.playMatch()
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "📱 เขย่าเพื่อสุ่มหาเพื่อนใหม่ (Shake)",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Text(
            text = "แตะวงกลมด้านล่างเพื่อค้นหาคนที่กำลังเขย่าพร้อมกัน",
            fontSize = 11.sp,
            color = Slate400
        )

        Spacer(modifier = Modifier.height(30.dp))

        // Shake Button
        Box(
            modifier = Modifier
                .size(160.dp)
                .scale(if (isShaking) pulseScale else 1f)
                .clip(CircleShape)
                .background(
                    Brush.linearGradient(listOf(PinkPrimary, RosePrimary, AmberGold))
                )
                .border(2.dp, AmberLight, CircleShape)
                .clickable { triggerShake() },
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.Smartphone,
                    contentDescription = "Shake",
                    tint = Color.White,
                    modifier = Modifier.size(54.dp)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (isShaking) "กำลังค้นหา..." else "แตะเพื่อเขย่า!",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black
                )
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Matched Result Card
        matchedUser?.let { match ->
            val isFriend = friendIds.contains(match.id)
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp),
                shape = RoundedCornerShape(24.dp),
                color = Slate900,
                border = androidx.compose.foundation.BorderStroke(1.5.dp, PinkPrimary)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = PinkLight, modifier = Modifier.size(16.dp))
                        Text(
                            text = "จับคู่สำเร็จ! เพื่อนที่กำลังเขย่าพร้อมกัน",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = PinkLight
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        AsyncImage(
                            model = match.avatar,
                            contentDescription = match.displayName,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .border(2.dp, PinkPrimary, CircleShape)
                        )
                        Column {
                            Text(
                                text = "${match.displayName} (${match.age} ปี)",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "📍 ${match.location.province} • เขย่าเมื่อสักครู่ ⚡",
                                fontSize = 11.sp,
                                color = EmeraldGreen
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "\"${match.bio}\"", fontSize = 11.sp, color = Slate300, maxLines = 2)

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { onToggleFriend(match.id) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isFriend) Slate800 else Slate800
                            )
                        ) {
                            Text(
                                text = if (isFriend) "เป็นเพื่อนแล้ว ✓" else "+ เพิ่มเพื่อน",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isFriend) EmeraldGreen else Color.White
                            )
                        }

                        Button(
                            onClick = { onStartChat(match.id) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary)
                        ) {
                            Text("ทักแชตเลย", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }
        }
    }
}
