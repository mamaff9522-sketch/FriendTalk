package com.example.ui.feed

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.model.Comment
import com.example.model.Post
import com.example.model.User
import com.example.service.SoundService
import com.example.ui.theme.*

@Composable
fun PostCommentsDialog(
    isOpen: Boolean,
    post: Post?,
    currentUser: User,
    users: List<User>,
    onClose: () -> Unit
) {
    if (!isOpen || post == null) return

    var comments by remember(post.id) {
        mutableStateOf(
            listOf(
                Comment("c_1", post.id, "user_fah", "บรรยากาศดีมากๆ เลยค่ะ อยากไปด้วยเลย 💖", "30 นาทีที่แล้ว", listOf("user_me")),
                Comment("c_2", post.id, "user_arty", "ภาพสวยจัดครับ โพสต์บ่อยๆ นะรอติดตามเลย 👍", "15 นาทีที่แล้ว", emptyList())
            )
        )
    }

    var commentInput by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onClose) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.75f),
            shape = RoundedCornerShape(24.dp),
            color = Slate900,
            border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ความคิดเห็น (${comments.size})",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    IconButton(onClick = onClose) {
                        Icon(Icons.Default.Close, contentDescription = "ปิด", tint = Slate400)
                    }
                }

                HorizontalDivider(color = Slate800, modifier = Modifier.padding(vertical = 8.dp))

                // Comments List
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(comments) { comment ->
                        val author = users.find { it.id == comment.authorId }
                        val isLiked = comment.likes.contains(currentUser.id)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            AsyncImage(
                                model = author?.avatar,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                            )

                            Surface(
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(14.dp),
                                color = Slate950,
                                border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = author?.displayName ?: "ผู้ใช้",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                        Text(
                                            text = comment.createdAt,
                                            fontSize = 10.sp,
                                            color = Slate500
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(3.dp))
                                    Text(
                                        text = comment.text,
                                        fontSize = 12.sp,
                                        color = Slate200
                                    )
                                }
                            }

                            // Heart on comment
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.clickable {
                                    SoundService.playHeart()
                                    comments = comments.map { c ->
                                        if (c.id == comment.id) {
                                            val newLikes = if (isLiked) c.likes - currentUser.id else c.likes + currentUser.id
                                            c.copy(likes = newLikes)
                                        } else c
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = if (isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                    contentDescription = null,
                                    tint = if (isLiked) RosePrimary else Slate500,
                                    modifier = Modifier.size(16.dp)
                                )
                                if (comment.likes.isNotEmpty()) {
                                    Text(
                                        text = comment.likes.size.toString(),
                                        fontSize = 10.sp,
                                        color = Slate400
                                    )
                                }
                            }
                        }
                    }
                }

                HorizontalDivider(color = Slate800, modifier = Modifier.padding(vertical = 8.dp))

                // Input bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = commentInput,
                        onValueChange = { commentInput = it },
                        placeholder = { Text("เขียนความคิดเห็นของคุณ...", fontSize = 12.sp) },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        shape = RoundedCornerShape(20.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PinkPrimary,
                            unfocusedBorderColor = Slate800,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    IconButton(
                        onClick = {
                            if (commentInput.isNotBlank()) {
                                val newC = Comment(
                                    id = "c_${System.currentTimeMillis()}",
                                    postId = post.id,
                                    authorId = currentUser.id,
                                    text = commentInput.trim(),
                                    createdAt = "เมื่อสักครู่"
                                )
                                comments = comments + newC
                                commentInput = ""
                                SoundService.playMessage()
                            }
                        },
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(PinkPrimary)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = "ส่ง",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}
