package com.example.ui.discover

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.Gender
import com.example.model.User
import com.example.ui.theme.*

@Composable
fun NearbyListView(
    currentUser: User,
    users: List<User>,
    friendIds: Set<String>,
    onToggleFriend: (String) -> Unit,
    onStartChat: (String) -> Unit,
    onToggleLocationSharing: () -> Unit,
    modifier: Modifier = Modifier
) {
    var genderFilter by remember { mutableStateOf<Gender?>(null) } // null = all
    var onlyOnline by remember { mutableStateOf(false) }

    val nearbyUsers = remember(users, currentUser.id, genderFilter, onlyOnline) {
        users.filter { u ->
            u.id != currentUser.id &&
                    !u.isSuspended &&
                    (genderFilter == null || u.gender == genderFilter) &&
                    (!onlyOnline || u.isOnline)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        // Location Sharing Status Card
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            color = Slate900,
            border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.Place,
                        contentDescription = null,
                        tint = if (currentUser.location.isSharing) EmeraldGreen else Slate500,
                        modifier = Modifier.size(20.dp)
                    )
                    Column {
                        Text(
                            text = if (currentUser.location.isSharing) "พิกัด: ${currentUser.location.province}" else "ปิดการแชร์ตำแหน่งอยู่",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = if (currentUser.location.isSharing) "ระบบแสดงระยะทางโดยประมาณ" else "เปิดเพื่อค้นหาเพื่อนในระยะใกล้",
                            fontSize = 10.sp,
                            color = Slate400
                        )
                    }
                }

                Button(
                    onClick = onToggleLocationSharing,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (currentUser.location.isSharing) Slate800 else EmeraldGreen
                    ),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (currentUser.location.isSharing) "ปิดแชร์" else "เปิดแชร์",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Filter Chips Row
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            item {
                FilterChip(
                    selected = genderFilter == null,
                    onClick = { genderFilter = null },
                    label = { Text("ทั้งหมด", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = PinkPrimary,
                        selectedLabelColor = Color.White
                    )
                )
            }
            item {
                FilterChip(
                    selected = genderFilter == Gender.FEMALE,
                    onClick = { genderFilter = Gender.FEMALE },
                    label = { Text("👩 ผู้หญิง", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = PinkPrimary,
                        selectedLabelColor = Color.White
                    )
                )
            }
            item {
                FilterChip(
                    selected = genderFilter == Gender.MALE,
                    onClick = { genderFilter = Gender.MALE },
                    label = { Text("👨 ผู้ชาย", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = PinkPrimary,
                        selectedLabelColor = Color.White
                    )
                )
            }
            item {
                FilterChip(
                    selected = genderFilter == Gender.NON_BINARY,
                    onClick = { genderFilter = Gender.NON_BINARY },
                    label = { Text("🌈 LGBTQ+", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = PinkPrimary,
                        selectedLabelColor = Color.White
                    )
                )
            }
            item {
                FilterChip(
                    selected = onlyOnline,
                    onClick = { onlyOnline = !onlyOnline },
                    label = { Text("🟢 ออนไลน์", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = EmeraldGreen,
                        selectedLabelColor = Color.White
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // User list
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(bottom = 72.dp)
        ) {
            items(nearbyUsers) { user ->
                val isFriend = friendIds.contains(user.id)
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    color = Slate900,
                    border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Box {
                                AsyncImage(
                                    model = user.avatar,
                                    contentDescription = user.displayName,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(CircleShape)
                                )
                                if (user.isOnline) {
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.BottomEnd)
                                            .size(10.dp)
                                            .clip(CircleShape)
                                            .background(EmeraldGreen)
                                            .border(1.5.dp, Slate900, CircleShape)
                                    )
                                }
                            }

                            Column {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = user.displayName,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "${user.age} ปี",
                                        fontSize = 11.sp,
                                        color = Slate400
                                    )
                                }

                                Text(
                                    text = user.bio,
                                    fontSize = 11.sp,
                                    color = Slate300,
                                    maxLines = 1
                                )

                                Text(
                                    text = "📍 ห่างประมาณ ${user.location.distanceKm} กม. • ${user.location.province}",
                                    fontSize = 10.sp,
                                    color = PinkLight
                                )
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            IconButton(
                                onClick = { onToggleFriend(user.id) },
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(
                                        if (isFriend) Slate800 else PinkPrimary.copy(alpha = 0.15f),
                                        RoundedCornerShape(10.dp)
                                    )
                            ) {
                                Icon(
                                    imageVector = if (isFriend) Icons.Default.Check else Icons.Default.PersonAdd,
                                    contentDescription = null,
                                    tint = if (isFriend) EmeraldGreen else PinkPrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            IconButton(
                                onClick = { onStartChat(user.id) },
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(PinkPrimary, RoundedCornerShape(10.dp))
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ChatBubble,
                                    contentDescription = "Chat",
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
