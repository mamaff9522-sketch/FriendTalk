package com.example.ui.feed

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.model.Club
import com.example.model.ForumTopic
import com.example.model.User
import com.example.ui.theme.*

@Composable
fun ClubsView(
    clubs: List<Club>,
    forumTopics: List<ForumTopic>,
    currentUser: User,
    users: List<User>,
    onJoinClub: (String) -> Unit,
    onLeaveClub: (String) -> Unit,
    onCreateTopic: (clubId: String, title: String, content: String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedClubId by remember { mutableStateOf(clubs.firstOrNull()?.id ?: "") }
    var isCreatingTopic by remember { mutableStateOf(false) }

    val activeClub = clubs.find { it.id == selectedClubId } ?: clubs.firstOrNull()
    val isMember = activeClub?.members?.contains(currentUser.id) == true
    val clubTopics = forumTopics.filter { it.clubId == activeClub?.id }

    Column(modifier = modifier.fillMaxWidth()) {
        // Clubs Horizontal Carousel
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "คลับยอดนิยม & คอมมูนิตี้",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Slate300
            )
            Text(
                text = "ทั้งหมด ${clubs.size} คลับ",
                fontSize = 11.sp,
                color = PinkLight
            )
        }

        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(clubs) { club ->
                val isSelected = club.id == selectedClubId
                Surface(
                    modifier = Modifier
                        .width(140.dp)
                        .clickable { selectedClubId = club.id },
                    shape = RoundedCornerShape(18.dp),
                    color = if (isSelected) Slate900 else Slate950,
                    border = androidx.compose.foundation.BorderStroke(
                        if (isSelected) 1.5.dp else 1.dp,
                        if (isSelected) PinkPrimary else Slate800
                    )
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(text = club.icon, fontSize = 24.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = club.name,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            maxLines = 1
                        )
                        Text(
                            text = "${club.memberCount} สมาชิก",
                            fontSize = 10.sp,
                            color = Slate400
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Surface(
                            color = if (club.members.contains(currentUser.id)) EmeraldGreen.copy(alpha = 0.2f) else Slate800,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = if (club.members.contains(currentUser.id)) "เข้าร่วมแล้ว ✓" else "+ เข้าร่วม",
                                fontSize = 10.sp,
                                color = if (club.members.contains(currentUser.id)) EmeraldGreen else Slate300,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Active Club Card & Discussions
        activeClub?.let { club ->
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp),
                shape = RoundedCornerShape(22.dp),
                color = Slate900,
                border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
            ) {
                Column {
                    // Club Cover Header
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                    ) {
                        AsyncImage(
                            model = club.coverImage,
                            contentDescription = club.name,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.Black.copy(alpha = 0.5f))
                        )

                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(12.dp),
                            verticalAlignment = Alignment.Bottom,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${club.icon} ${club.name}",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = club.description,
                                    fontSize = 10.sp,
                                    color = Slate200,
                                    maxLines = 1
                                )
                            }

                            Button(
                                onClick = {
                                    if (isMember) onLeaveClub(club.id) else onJoinClub(club.id)
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isMember) Slate800 else PinkPrimary
                                ),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = if (isMember) "เป็นสมาชิกแล้ว" else "+ เข้าร่วม",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                    }

                    // Club Discussion Topics
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "กระทู้พูดคุย (${clubTopics.size})",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Slate200
                            )

                            Button(
                                onClick = { isCreatingTopic = true },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary.copy(alpha = 0.2f)),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, tint = PinkLight, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("ตั้งกระทู้", fontSize = 11.sp, color = PinkLight, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        if (clubTopics.isEmpty()) {
                            Text(
                                text = "ยังไม่มีกระทู้ในคลับนี้ เป็นคนแรกที่เริ่มพูดคุยเลย!",
                                fontSize = 12.sp,
                                color = Slate500,
                                modifier = Modifier.padding(vertical = 16.dp)
                            )
                        } else {
                            clubTopics.forEach { topic ->
                                val author = users.find { it.id == topic.authorId }
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    shape = RoundedCornerShape(14.dp),
                                    color = Slate950,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            AsyncImage(
                                                model = author?.avatar,
                                                contentDescription = null,
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier
                                                    .size(20.dp)
                                                    .clip(CircleShape)
                                            )
                                            Text(
                                                text = author?.displayName ?: "สมาชิก",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = Slate300
                                            )
                                            Text(
                                                text = "• ${topic.createdAt}",
                                                fontSize = 10.sp,
                                                color = Slate500
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = topic.title,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = topic.content,
                                            fontSize = 11.sp,
                                            color = Slate300,
                                            maxLines = 2
                                        )

                                        Spacer(modifier = Modifier.height(6.dp))
                                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                Icon(Icons.Default.Favorite, contentDescription = null, tint = RosePrimary, modifier = Modifier.size(13.dp))
                                                Text(topic.likes.size.toString(), fontSize = 10.sp, color = Slate400)
                                            }
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                Icon(Icons.Default.ChatBubble, contentDescription = null, tint = SkyBlue, modifier = Modifier.size(13.dp))
                                                Text("${topic.commentsCount} ความเห็น", fontSize = 10.sp, color = Slate400)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Create Topic Dialog
    if (isCreatingTopic && activeClub != null) {
        var topicTitle by remember { mutableStateOf("") }
        var topicContent by remember { mutableStateOf("") }

        Dialog(onDismissRequest = { isCreatingTopic = false }) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                color = Slate900,
                border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "ตั้งกระทู้ใหม่ใน ${activeClub.name}",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = topicTitle,
                        onValueChange = { topicTitle = it },
                        label = { Text("หัวข้อกระทู้") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PinkPrimary,
                            unfocusedBorderColor = Slate800,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = topicContent,
                        onValueChange = { topicContent = it },
                        label = { Text("เนื้อหากระทู้") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PinkPrimary,
                            unfocusedBorderColor = Slate800,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { isCreatingTopic = false },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Slate800)
                        ) {
                            Text("ยกเลิก", color = Slate300)
                        }

                        Button(
                            onClick = {
                                if (topicTitle.isNotBlank() && topicContent.isNotBlank()) {
                                    onCreateTopic(activeClub.id, topicTitle.trim(), topicContent.trim())
                                    isCreatingTopic = false
                                }
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary)
                        ) {
                            Text("เผยแพร่", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }
        }
    }
}
