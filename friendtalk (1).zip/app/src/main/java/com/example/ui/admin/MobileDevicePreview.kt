package com.example.ui.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.AppUiConfig
import com.example.model.parseHexColor
import com.example.ui.theme.*

@Composable
fun MobileDevicePreview(
    config: AppUiConfig,
    activePreviewTab: String = "home",
    onTabSelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val theme = config.theme
    val isDark = theme.themeMode != "light"

    val bgColor = parseHexColor(theme.backgroundColorHex, if (isDark) Slate950 else Color(0xFFF8FAFC))
    val surfaceColor = parseHexColor(theme.surfaceColorHex, if (isDark) Slate900 else Color.White)
    val primaryColor = parseHexColor(theme.primaryColorHex, PinkPrimary)
    val accentColor = parseHexColor(theme.accentColorHex, AmberGold)
    val textColor = parseHexColor(theme.textColorHex, if (isDark) Color.White else Color(0xFF0F172A))
    val textSecColor = parseHexColor(theme.textSecondaryColorHex, if (isDark) Slate400 else Color(0xFF64748B))
    val cardRadius = theme.cardCornerRadiusDp.dp
    val buttonRadius = theme.buttonCornerRadiusDp.dp
    val fontScale = theme.fontSizeScale

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Banner notice
        Surface(
            color = Slate900,
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, PinkPrimary.copy(alpha = 0.3f)),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(Icons.Default.PhoneAndroid, contentDescription = null, tint = PinkPrimary, modifier = Modifier.size(16.dp))
                Text(
                    "จำลองแสดงผลหน้าจอมือถือจริง (Live Mobile Preview) • รุ่น: ${config.configVersion}",
                    fontSize = 11.sp,
                    color = Color.White,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        // Realistic Phone Bezel
        Surface(
            modifier = Modifier
                .width(320.dp)
                .height(580.dp),
            shape = RoundedCornerShape(38.dp),
            color = Color(0xFF1E222B),
            shadowElevation = 16.dp,
            border = androidx.compose.foundation.BorderStroke(3.dp, Color(0xFF333846))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(8.dp)
                    .clip(RoundedCornerShape(32.dp))
                    .background(bgColor)
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    // Status Bar + Dynamic Island
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(28.dp)
                            .background(bgColor)
                            .padding(horizontal = 14.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        // Left time
                        Text(
                            "09:41",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = textColor,
                            modifier = Modifier.align(Alignment.CenterStart)
                        )

                        // Dynamic Island Notch
                        Box(
                            modifier = Modifier
                                .width(74.dp)
                                .height(16.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color.Black),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF1E293B))
                            )
                        }

                        // Right icons
                        Row(
                            modifier = Modifier.align(Alignment.CenterEnd),
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.SignalCellular4Bar, contentDescription = null, tint = textColor, modifier = Modifier.size(11.dp))
                            Icon(Icons.Default.Wifi, contentDescription = null, tint = textColor, modifier = Modifier.size(11.dp))
                            Icon(Icons.Default.BatteryFull, contentDescription = null, tint = textColor, modifier = Modifier.size(12.dp))
                        }
                    }

                    // App Header in Preview
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = surfaceColor,
                        shadowElevation = 2.dp
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                if (config.appLogoUrl.isNotBlank()) {
                                    AsyncImage(
                                        model = config.appLogoUrl,
                                        contentDescription = "Logo",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .size(24.dp)
                                            .clip(RoundedCornerShape(6.dp))
                                    )
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .size(24.dp)
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(
                                                Brush.linearGradient(listOf(primaryColor, accentColor))
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("F", color = Color.White, fontWeight = FontWeight.Black, fontSize = 13.sp)
                                    }
                                }

                                Text(
                                    config.appName,
                                    fontSize = (13 * fontScale).sp,
                                    fontWeight = FontWeight.Black,
                                    color = primaryColor
                                )
                            }

                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    color = accentColor.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text(
                                        "🪙 1,500",
                                        fontSize = (10 * fontScale).sp,
                                        fontWeight = FontWeight.Bold,
                                        color = accentColor,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Icon(Icons.Default.Notifications, contentDescription = null, tint = textSecColor, modifier = Modifier.size(16.dp))
                            }
                        }
                    }

                    // Page Body Content
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState())
                    ) {
                        val pageConfig = config.pages[activePreviewTab]
                        val enabledSections = pageConfig?.sections?.filter { it.isEnabled }?.sortedBy { it.order } ?: emptyList()

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp),
                            verticalArrangement = Arrangement.spacedBy((8 * theme.spacingScale).dp)
                        ) {
                            // Page Hero if configured
                            if (!pageConfig?.heroImageUrl.isNullOrBlank()) {
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(95.dp),
                                    shape = RoundedCornerShape(cardRadius),
                                    color = surfaceColor
                                ) {
                                    Box(modifier = Modifier.fillMaxSize()) {
                                        AsyncImage(
                                            model = pageConfig?.heroImageUrl,
                                            contentDescription = null,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                        Box(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .background(
                                                    Brush.verticalGradient(
                                                        listOf(Color.Transparent, Color.Black.copy(alpha = 0.7f))
                                                    )
                                                )
                                        )
                                        Column(
                                            modifier = Modifier
                                                .align(Alignment.BottomStart)
                                                .padding(8.dp)
                                        ) {
                                            Text(
                                                pageConfig?.pageTitle ?: "",
                                                fontSize = (12 * fontScale).sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White
                                            )
                                        }
                                    }
                                }
                            }

                            // Render Sections
                            enabledSections.forEach { section ->
                                Surface(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(cardRadius),
                                    color = surfaceColor,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, parseHexColor(theme.cardBorderColorHex, Slate800))
                                ) {
                                    Column(modifier = Modifier.padding(8.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                section.title,
                                                fontSize = (11 * fontScale).sp,
                                                fontWeight = FontWeight.Bold,
                                                color = textColor
                                            )
                                            if (!section.buttonText.isNullOrBlank()) {
                                                Surface(
                                                    shape = RoundedCornerShape(buttonRadius),
                                                    color = primaryColor
                                                ) {
                                                    Text(
                                                        section.buttonText,
                                                        fontSize = (9 * fontScale).sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = Color.White,
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                                    )
                                                }
                                            }
                                        }

                                        if (section.subtitle.isNotBlank()) {
                                            Text(
                                                section.subtitle,
                                                fontSize = (9 * fontScale).sp,
                                                color = textSecColor,
                                                modifier = Modifier.padding(top = 2.dp)
                                            )
                                        }

                                        if (!section.bannerImageUrl.isNullOrBlank()) {
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Surface(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .height(70.dp),
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                AsyncImage(
                                                    model = section.bannerImageUrl,
                                                    contentDescription = null,
                                                    contentScale = ContentScale.Crop,
                                                    modifier = Modifier.fillMaxSize()
                                                )
                                            }
                                        }

                                        // Placeholder mock list inside section
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            repeat(3) {
                                                Box(
                                                    modifier = Modifier
                                                        .weight(1f)
                                                        .height(28.dp)
                                                        .clip(RoundedCornerShape(6.dp))
                                                        .background(primaryColor.copy(alpha = 0.12f)),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text("Item ${it + 1}", fontSize = (8 * fontScale).sp, color = textSecColor)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Bottom Navigation Bar in Preview
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = surfaceColor,
                        shadowElevation = 8.dp
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceAround,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val enabledTabs = config.navigationTabs.filter { it.isEnabled }.sortedBy { it.order }
                            enabledTabs.forEach { tab ->
                                val isSelected = tab.tabId == activePreviewTab
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable { onTabSelected(tab.tabId) }
                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                ) {
                                    Icon(
                                        imageVector = when (tab.iconName) {
                                            "Explore" -> Icons.Default.Explore
                                            "Radio" -> Icons.Default.Radio
                                            "Movie" -> Icons.Default.Movie
                                            "ChatBubble" -> Icons.Default.ChatBubble
                                            "VolunteerActivism" -> Icons.Default.VolunteerActivism
                                            "Person" -> Icons.Default.Person
                                            else -> Icons.Default.Home
                                        },
                                        contentDescription = tab.label,
                                        tint = if (isSelected) primaryColor else textSecColor,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        tab.label,
                                        fontSize = 8.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) primaryColor else textSecColor
                                    )
                                }
                            }
                        }
                    }

                    // Home indicator bar at bottom
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .background(surfaceColor),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .width(60.dp)
                                .height(3.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(textSecColor.copy(alpha = 0.5f))
                        )
                    }
                }
            }
        }
    }
}
