package com.example.ui.discover

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import coil.compose.AsyncImage
import com.example.model.User
import com.example.service.SoundService
import com.example.ui.theme.*

@Composable
fun RadarView(
    currentUser: User,
    users: List<User>,
    friendIds: Set<String>,
    onToggleFriend: (String) -> Unit,
    onStartChat: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedPeer by remember { mutableStateOf<User?>(null) }
    val peers = remember(users, currentUser.id) {
        users.filter { it.id != currentUser.id && it.location.isSharing }
    }

    // Continuous sweep animation for radar
    val infiniteTransition = rememberInfiniteTransition(label = "radar_sweep")
    val angle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "sweep_angle"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Radar Header
        Text(
            text = "🧭 เรดาร์สแกนหาเพื่อนรอบตัว (Radar)",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Text(
            text = "ค้นหาเพื่อนใหม่ในรัศมีรอบตัว • ไม่เปิดเผยพิกัดจริง",
            fontSize = 11.sp,
            color = Slate400
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Circular Radar Display
        Box(
            modifier = Modifier
                .size(280.dp)
                .clip(CircleShape)
                .background(Slate950)
                .border(1.dp, EmeraldGreen.copy(alpha = 0.4f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            // Draw Concentric Circles & Crosshair
            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = Offset(size.width / 2, size.height / 2)
                val radius = size.width / 2

                drawCircle(color = EmeraldGreen.copy(alpha = 0.15f), radius = radius * 0.75f, style = Stroke(width = 1.dp.toPx()))
                drawCircle(color = EmeraldGreen.copy(alpha = 0.2f), radius = radius * 0.5f, style = Stroke(width = 1.dp.toPx()))
                drawCircle(color = EmeraldGreen.copy(alpha = 0.25f), radius = radius * 0.25f, style = Stroke(width = 1.dp.toPx()))

                drawLine(color = EmeraldGreen.copy(alpha = 0.15f), start = Offset(0f, center.y), end = Offset(size.width, center.y))
                drawLine(color = EmeraldGreen.copy(alpha = 0.15f), start = Offset(center.x, 0f), end = Offset(center.x, size.height))
            }

            // Rotating sweep cone
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .rotate(angle)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val center = Offset(size.width / 2, size.height / 2)
                    drawArc(
                        brush = Brush.sweepGradient(
                            listOf(Color.Transparent, EmeraldGreen.copy(alpha = 0.25f))
                        ),
                        startAngle = 0f,
                        sweepAngle = 75f,
                        useCenter = true
                    )
                }
            }

            // Center: Current User
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.zIndex(10f)
            ) {
                AsyncImage(
                    model = currentUser.avatar,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .border(2.dp, EmeraldGreen, CircleShape)
                )
                Text(
                    text = "คุณ",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = EmeraldGreen,
                    modifier = Modifier
                        .background(Slate900, RoundedCornerShape(4.dp))
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                )
            }

            // Scattered Peers around center
            val positions = listOf(
                Pair(0.25f, 0.30f),
                Pair(0.72f, 0.28f),
                Pair(0.20f, 0.70f),
                Pair(0.76f, 0.68f),
                Pair(0.80f, 0.42f),
                Pair(0.40f, 0.80f)
            )

            peers.take(positions.size).forEachIndexed { idx, peer ->
                val pos = positions[idx]
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(
                            start = (280 * pos.first).dp - 18.dp,
                            top = (280 * pos.second).dp - 18.dp
                        )
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .border(1.5.dp, PinkPrimary, CircleShape)
                            .clickable {
                                SoundService.playRadarBlip()
                                selectedPeer = peer
                            }
                    ) {
                        AsyncImage(
                            model = peer.avatar,
                            contentDescription = peer.displayName,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Selected Peer Quick Profile Sheet
        selectedPeer?.let { peer ->
            val isFriend = friendIds.contains(peer.id)
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                color = Slate900,
                border = androidx.compose.foundation.BorderStroke(1.dp, PinkPrimary.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            AsyncImage(
                                model = peer.avatar,
                                contentDescription = peer.displayName,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .border(2.dp, PinkPrimary, CircleShape)
                            )
                            Column {
                                Text(
                                    text = "${peer.displayName} (${peer.age})",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = "📍 ห่างประมาณ ${peer.location.distanceKm} กม. • ${peer.location.province}",
                                    fontSize = 11.sp,
                                    color = EmeraldGreen
                                )
                            }
                        }

                        IconButton(onClick = { selectedPeer = null }) {
                            Icon(Icons.Default.Close, contentDescription = "ปิด", tint = Slate400)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = peer.bio, fontSize = 11.sp, color = Slate300, maxLines = 2)

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { onToggleFriend(peer.id) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isFriend) Slate800 else PinkPrimary.copy(alpha = 0.2f)
                            )
                        ) {
                            Text(
                                text = if (isFriend) "เป็นเพื่อนแล้ว ✓" else "+ ขอเป็นเพื่อน",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isFriend) EmeraldGreen else PinkLight
                            )
                        }

                        Button(
                            onClick = {
                                val id = peer.id
                                selectedPeer = null
                                onStartChat(id)
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary)
                        ) {
                            Text("ทักแชตทันที", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }
        }
    }
}
