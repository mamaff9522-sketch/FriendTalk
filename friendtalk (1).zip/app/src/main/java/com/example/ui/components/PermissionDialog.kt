package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.AppPermissions
import com.example.model.User
import com.example.ui.theme.*

@Composable
fun PermissionDialog(
    isOpen: Boolean,
    currentUser: User,
    permissions: AppPermissions,
    onClose: () -> Unit,
    onToggleLocationSharing: () -> Unit,
    onUpdatePermissions: (camera: Boolean, mic: Boolean, geo: Boolean, notif: Boolean) -> Unit
) {
    if (!isOpen) return

    var camera by remember { mutableStateOf(permissions.camera) }
    var mic by remember { mutableStateOf(permissions.microphone) }
    var geo by remember { mutableStateOf(permissions.geolocation) }
    var notif by remember { mutableStateOf(permissions.notifications) }

    Dialog(onDismissRequest = onClose) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(28.dp),
            color = Slate900,
            border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = PinkPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                        Column {
                            Text(
                                text = "จัดการสิทธิ์และความเป็นส่วนตัว",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "ควบคุมข้อมูลและความปลอดภัยของคุณ",
                                fontSize = 11.sp,
                                color = Slate400
                            )
                        }
                    }
                    IconButton(onClick = onClose) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "ปิด",
                            tint = Slate400
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Location Distance Sharing Card
                Surface(
                    color = Slate950,
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Place,
                                contentDescription = null,
                                tint = if (currentUser.location.isSharing) EmeraldGreen else Slate500,
                                modifier = Modifier.size(22.dp)
                            )
                            Column {
                                Text(
                                    text = "แชร์ระยะทางกับเพื่อนใกล้เคียง",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = if (currentUser.location.isSharing)
                                        "เปิดอยู่ (แสดงระยะประมาณ เช่น 800 เมตร)"
                                    else
                                        "ปิดอยู่ (ไม่ปรากฏบนเรดาร์)",
                                    fontSize = 11.sp,
                                    color = Slate400
                                )
                            }
                        }
                        Switch(
                            checked = currentUser.location.isSharing,
                            onCheckedChange = { onToggleLocationSharing() },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = PinkPrimary,
                                uncheckedThumbColor = Slate400,
                                uncheckedTrackColor = Slate800
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Permission Rows
                PermissionRow(
                    icon = Icons.Default.CameraAlt,
                    title = "กล้องถ่ายภาพ (Camera)",
                    desc = "สำหรับการไลฟ์สด วิดีโอคอล ถ่ายภาพโปรไฟล์",
                    enabled = camera,
                    onToggle = { camera = it }
                )

                PermissionRow(
                    icon = Icons.Default.Mic,
                    title = "ไมโครโฟน (Microphone)",
                    desc = "สำหรับการคุยเสียง วิดีโอคอล ไลฟ์สด ข้อความเสียง",
                    enabled = mic,
                    onToggle = { mic = it }
                )

                PermissionRow(
                    icon = Icons.Default.LocationOn,
                    title = "ตำแหน่งที่ตั้ง (Location)",
                    desc = "สำหรับหาเพื่อนใกล้เคียงและเรดาร์ โดยไม่เปิดเผยพิกัดจริง",
                    enabled = geo,
                    onToggle = { geo = it }
                )

                PermissionRow(
                    icon = Icons.Default.Notifications,
                    title = "การแจ้งเตือน (Notifications)",
                    desc = "แจ้งเตือนข้อความแชตใหม่ และการไลฟ์สด",
                    enabled = notif,
                    onToggle = { notif = it }
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        onUpdatePermissions(camera, mic, geo, notif)
                        onClose()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary)
                ) {
                    Text(
                        text = "บันทึกการตั้งค่า",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }
    }
}

@Composable
private fun PermissionRow(
    icon: ImageVector,
    title: String,
    desc: String,
    enabled: Boolean,
    onToggle: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .background(Slate800, RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = PinkPrimary,
                    modifier = Modifier.size(16.dp)
                )
            }
            Column {
                Text(
                    text = title,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White
                )
                Text(
                    text = desc,
                    fontSize = 10.sp,
                    color = Slate400,
                    lineHeight = 13.sp
                )
            }
        }

        Switch(
            checked = enabled,
            onCheckedChange = onToggle,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = PinkPrimary,
                uncheckedThumbColor = Slate400,
                uncheckedTrackColor = Slate800
            )
        )
    }
}
