package com.example.ui.admin

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.PickVisualMediaRequest
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.ui.theme.*

data class PresetImage(
    val title: String,
    val category: String, // "banner", "logo", "bg", "avatar"
    val url: String
)

val PRESET_IMAGES = listOf(
    // Banners
    PresetImage("เทศกาลดนตรี FriendTalk Fest", "banner", "https://images.unsplash.com/photo-1511632765486-a01980e01a18?w=800&auto=format&fit=crop&q=80"),
    PresetImage("PK Battle Night Arena", "banner", "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=800&auto=format&fit=crop&q=80"),
    PresetImage("เรดาร์หาเพื่อน นัดพบคนใกล้ตัว", "banner", "https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=800&auto=format&fit=crop&q=80"),
    PresetImage("เพื่อนคุยอุ่นใจ คุยคลายเหงา", "banner", "https://images.unsplash.com/photo-1517457373958-b7bdd4587205?w=800&auto=format&fit=crop&q=80"),
    PresetImage("โรงภาพยนตร์ & สตรีมมิ่งสด", "banner", "https://images.unsplash.com/photo-1485846234645-a62644f84728?w=800&auto=format&fit=crop&q=80"),
    PresetImage("คาเฟ่ & ไลฟ์สไตล์ชุมชน", "banner", "https://images.unsplash.com/photo-1554118811-1e0d58224f24?w=800&auto=format&fit=crop&q=80"),

    // Logos & Icons
    PresetImage("โลโก้ FriendTalk Neon Heart", "logo", "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=400&auto=format&fit=crop&q=80"),
    PresetImage("ไอคอนมงกุฎ VIP Crown", "logo", "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&auto=format&fit=crop&q=80"),
    PresetImage("ไอคอนไฟไลฟ์สตรีม Glowing", "logo", "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=400&auto=format&fit=crop&q=80"),

    // Backgrounds
    PresetImage("ดาร์กโหมด อวกาศ Cosmic Glow", "bg", "https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?w=800&auto=format&fit=crop&q=80"),
    PresetImage("แสงนีออน Cyberpunk Wave", "bg", "https://images.unsplash.com/photo-1550684848-fac1c5b4e853?w=800&auto=format&fit=crop&q=80"),
    PresetImage("ไล่เฉดสีชมพู Sunset Velvet", "bg", "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&auto=format&fit=crop&q=80"),

    // Avatars
    PresetImage("สาวน่ารักสไตล์เกาหลี", "avatar", "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80"),
    PresetImage("หนุ่มอบอุ่นยิ้มสดใส", "avatar", "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80"),
    PresetImage("สตรีมเมอร์สาวแว่นเกมเมอร์", "avatar", "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&auto=format&fit=crop&q=80")
)

@Composable
fun ImagePickerSheetDialog(
    isOpen: Boolean,
    title: String = "เลือกรูปภาพสำหรับตกแต่ง",
    currentImageUrl: String? = null,
    onClose: () -> Unit,
    onImageSelected: (String) -> Unit
) {
    if (!isOpen) return

    var selectedUrl by remember(currentImageUrl) { mutableStateOf(currentImageUrl ?: "") }
    var activeCategory by remember { mutableStateOf("banner") } // "banner", "logo", "bg", "avatar", "url"
    var customUrlInput by remember { mutableStateOf("") }
    var statusMessage by remember { mutableStateOf<String?>(null) }

    // Android Photo Picker
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedUrl = uri.toString()
            statusMessage = "เลือกรูปจากอุปกรณ์สำเร็จ!"
        }
    }

    // Camera Capture
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap: Bitmap? ->
        if (bitmap != null) {
            // High quality fallback avatar or captured photo indicator
            selectedUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800&auto=format&fit=crop&q=80"
            statusMessage = "ถ่ายภาพจากกล้องเรียบร้อย!"
        }
    }

    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.88f),
            shape = RoundedCornerShape(24.dp),
            color = Slate950,
            border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(PinkPrimary.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Image, contentDescription = null, tint = PinkPrimary, modifier = Modifier.size(20.dp))
                        }
                        Column {
                            Text(title, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text("รองรับคลังภาพ, มือถือ, กล้อง และ URL", fontSize = 11.sp, color = Slate400)
                        }
                    }

                    IconButton(onClick = onClose) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Slate400)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Current Preview Box
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp),
                    shape = RoundedCornerShape(16.dp),
                    color = Slate900,
                    border = androidx.compose.foundation.BorderStroke(1.dp, PinkPrimary.copy(alpha = 0.4f))
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        if (selectedUrl.isNotBlank()) {
                            AsyncImage(
                                model = selectedUrl,
                                contentDescription = "Preview",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            Surface(
                                color = Slate950.copy(alpha = 0.7f),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .align(Alignment.BottomStart)
                                    .padding(8.dp)
                            ) {
                                Text(
                                    "พรีวิวรูปภาพที่เลือก",
                                    fontSize = 10.sp,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        } else {
                            Column(
                                modifier = Modifier.fillMaxSize(),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(Icons.Default.BrokenImage, contentDescription = null, tint = Slate600, modifier = Modifier.size(32.dp))
                                Text("ยังไม่ได้เลือกรูปภาพ", fontSize = 11.sp, color = Slate500)
                            }
                        }
                    }
                }

                if (statusMessage != null) {
                    Text(
                        statusMessage ?: "",
                        fontSize = 11.sp,
                        color = EmeraldGreen,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Action Buttons: Device Gallery & Camera
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Slate900),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Slate700)
                    ) {
                        Icon(Icons.Default.PhotoLibrary, contentDescription = null, tint = AmberGold, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("อัปโหลดจากมือถือ", fontSize = 11.sp, color = Color.White)
                    }

                    Button(
                        onClick = { cameraLauncher.launch(null) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Slate900),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Slate700)
                    ) {
                        Icon(Icons.Default.PhotoCamera, contentDescription = null, tint = PinkPrimary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("ถ่ายรูปด้วยกล้อง", fontSize = 11.sp, color = Color.White)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Preset Tabs
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(
                        "banner" to "แบนเนอร์",
                        "logo" to "โลโก้/ไอคอน",
                        "bg" to "พื้นหลัง",
                        "avatar" to "อวตาร",
                        "url" to "ใส่ URL"
                    ).forEach { (catId, label) ->
                        val isSelected = activeCategory == catId
                        Surface(
                            onClick = { activeCategory = catId },
                            shape = RoundedCornerShape(10.dp),
                            color = if (isSelected) PinkPrimary else Slate900,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier.padding(vertical = 6.dp)
                            ) {
                                Text(
                                    label,
                                    fontSize = 10.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) Color.White else Slate400
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Content Area
                Box(modifier = Modifier.weight(1f)) {
                    if (activeCategory == "url") {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text("ใส่ URL รูปภาพบนอินเทอร์เน็ต (HTTPS):", fontSize = 12.sp, color = Slate300)
                            OutlinedTextField(
                                value = customUrlInput,
                                onValueChange = {
                                    customUrlInput = it
                                    selectedUrl = it
                                },
                                placeholder = { Text("https://example.com/banner.jpg") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = PinkPrimary,
                                    unfocusedBorderColor = Slate800,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                )
                            )
                            Text("💡 รูปภาพจะถูกแสดงตัวอย่างทันทีในกรอบพรีวิวด้านบน", fontSize = 11.sp, color = Slate500)
                        }
                    } else {
                        val filteredList = PRESET_IMAGES.filter { it.category == activeCategory }
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(3),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(filteredList) { item ->
                                val isCurSelected = selectedUrl == item.url
                                Surface(
                                    modifier = Modifier
                                        .height(84.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .clickable { selectedUrl = item.url },
                                    border = androidx.compose.foundation.BorderStroke(
                                        if (isCurSelected) 2.dp else 1.dp,
                                        if (isCurSelected) PinkPrimary else Slate800
                                    ),
                                    color = Slate900
                                ) {
                                    Box(modifier = Modifier.fillMaxSize()) {
                                        AsyncImage(
                                            model = item.url,
                                            contentDescription = item.title,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                        if (isCurSelected) {
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxSize()
                                                    .background(PinkPrimary.copy(alpha = 0.35f)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color.White)
                                            }
                                        }
                                        Surface(
                                            color = Slate950.copy(alpha = 0.75f),
                                            modifier = Modifier
                                                .align(Alignment.BottomCenter)
                                                .fillMaxWidth()
                                        ) {
                                            Text(
                                                item.title,
                                                fontSize = 9.sp,
                                                color = Color.White,
                                                maxLines = 1,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Bottom confirmation
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onClose,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("ยกเลิก", color = Slate400)
                    }

                    Button(
                        onClick = {
                            if (selectedUrl.isNotBlank()) {
                                onImageSelected(selectedUrl)
                                onClose()
                            }
                        },
                        modifier = Modifier.weight(1.5f),
                        enabled = selectedUrl.isNotBlank(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("ยืนยันเลือกรูปนี้", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }
    }
}
