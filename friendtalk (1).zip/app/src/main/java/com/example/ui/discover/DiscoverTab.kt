package com.example.ui.discover

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.User
import com.example.service.SoundService
import com.example.ui.theme.*

data class DiscoverSubTab(
    val id: String,
    val label: String,
    val icon: ImageVector
)

@Composable
fun DiscoverTab(
    currentUser: User,
    users: List<User>,
    friendIds: Set<String>,
    onToggleFriend: (String) -> Unit,
    onStartChat: (String) -> Unit,
    onToggleLocationSharing: () -> Unit,
    modifier: Modifier = Modifier
) {
    var activeSubTab by remember { mutableStateOf("match") } // "match", "radar", "shake", "nearby"

    val tabs = remember {
        listOf(
            DiscoverSubTab("match", "ปัดจับคู่", Icons.Default.AutoAwesome),
            DiscoverSubTab("radar", "เรดาร์", Icons.Default.Explore),
            DiscoverSubTab("shake", "เขย่าหาเพื่อน", Icons.Default.Smartphone),
            DiscoverSubTab("nearby", "ใกล้เคียง", Icons.Default.Place)
        )
    }

    Column(modifier = modifier.fillMaxSize()) {
        // Sticky Sub-navigation Bar
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = Slate900.copy(alpha = 0.9f),
            border = androidx.compose.foundation.BorderStroke(0.5.dp, Slate800)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                tabs.forEach { tab ->
                    val isSelected = activeSubTab == tab.id
                    Surface(
                        onClick = {
                            SoundService.playPop()
                            activeSubTab = tab.id
                        },
                        shape = RoundedCornerShape(14.dp),
                        color = if (isSelected) PinkPrimary else Color.Transparent
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = tab.icon,
                                contentDescription = null,
                                tint = if (isSelected) Color.White else Slate400,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = tab.label,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) Color.White else Slate400
                            )
                        }
                    }
                }
            }
        }

        // Sub-Mode Views
        when (activeSubTab) {
            "match" -> SwipeMatchView(
                currentUser = currentUser,
                users = users,
                onToggleFriend = onToggleFriend,
                onStartChat = onStartChat
            )
            "radar" -> RadarView(
                currentUser = currentUser,
                users = users,
                friendIds = friendIds,
                onToggleFriend = onToggleFriend,
                onStartChat = onStartChat
            )
            "shake" -> ShakeView(
                currentUser = currentUser,
                users = users,
                friendIds = friendIds,
                onToggleFriend = onToggleFriend,
                onStartChat = onStartChat
            )
            "nearby" -> NearbyListView(
                currentUser = currentUser,
                users = users,
                friendIds = friendIds,
                onToggleFriend = onToggleFriend,
                onStartChat = onStartChat,
                onToggleLocationSharing = onToggleLocationSharing
            )
        }
    }
}
