package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.example.model.ThemeConfig
import com.example.model.parseHexColor

private val DefaultDarkColorScheme = darkColorScheme(
    primary = PinkPrimary,
    onPrimary = Color.White,
    primaryContainer = PinkDark,
    onPrimaryContainer = Color.White,
    secondary = RosePrimary,
    onSecondary = Color.White,
    tertiary = AmberGold,
    onTertiary = Slate950,
    background = Slate950,
    onBackground = Slate100,
    surface = Slate900,
    onSurface = Slate100,
    surfaceVariant = Slate800,
    onSurfaceVariant = Slate300,
    outline = Slate700
)

@Composable
fun FriendTalkTheme(
    themeConfig: ThemeConfig? = null,
    content: @Composable () -> Unit,
) {
    val colorScheme = if (themeConfig != null) {
        val isDark = themeConfig.themeMode != "light"
        val primary = parseHexColor(themeConfig.primaryColorHex, PinkPrimary)
        val secondary = parseHexColor(themeConfig.secondaryColorHex, RosePrimary)
        val tertiary = parseHexColor(themeConfig.accentColorHex, AmberGold)
        val background = parseHexColor(themeConfig.backgroundColorHex, if (isDark) Slate950 else Color(0xFFF8FAFC))
        val surface = parseHexColor(themeConfig.surfaceColorHex, if (isDark) Slate900 else Color.White)
        val onSurface = parseHexColor(themeConfig.textColorHex, if (isDark) Color.White else Color(0xFF0F172A))
        val outline = parseHexColor(themeConfig.cardBorderColorHex, if (isDark) Slate700 else Color(0xFFCBD5E1))

        if (isDark) {
            darkColorScheme(
                primary = primary,
                onPrimary = Color.White,
                secondary = secondary,
                onSecondary = Color.White,
                tertiary = tertiary,
                onTertiary = Slate950,
                background = background,
                onBackground = onSurface,
                surface = surface,
                onSurface = onSurface,
                surfaceVariant = Slate800,
                onSurfaceVariant = Slate300,
                outline = outline
            )
        } else {
            lightColorScheme(
                primary = primary,
                onPrimary = Color.White,
                secondary = secondary,
                onSecondary = Color.White,
                tertiary = tertiary,
                onTertiary = Color.White,
                background = background,
                onBackground = onSurface,
                surface = surface,
                onSurface = onSurface,
                surfaceVariant = Color(0xFFF1F5F9),
                onSurfaceVariant = Color(0xFF475569),
                outline = outline
            )
        }
    } else {
        DefaultDarkColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit,
) {
    FriendTalkTheme(content = content)
}
