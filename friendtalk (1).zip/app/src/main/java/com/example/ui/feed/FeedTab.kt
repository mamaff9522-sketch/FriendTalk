package com.example.ui.feed

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.*
import com.example.ui.components.ReportDialog
import com.example.ui.theme.*

@Composable
fun FeedTab(
    currentUser: User,
    users: List<User>,
    posts: List<Post>,
    stories: List<Story>,
    clubs: List<Club>,
    forumTopics: List<ForumTopic>,
    followingIds: Set<String>,
    onToggleFollow: (String) -> Unit,
    onLikePost: (String) -> Unit,
    onDeletePost: (String) -> Unit,
    onCreatePost: (content: String, mediaUrls: List<String>, tags: List<String>) -> Unit,
    onAddStory: (mediaUrl: String, caption: String?) -> Unit,
    onJoinClub: (String) -> Unit,
    onLeaveClub: (String) -> Unit,
    onCreateTopic: (clubId: String, title: String, content: String) -> Unit,
    onCreateReport: (targetType: String, targetId: String, reason: String, details: String?) -> Unit,
    modifier: Modifier = Modifier
) {
    var subTab by remember { mutableStateOf("all") } // "all", "following", "clubs"
    var isCreatePostOpen by remember { mutableStateOf(false) }
    var activeCommentPost by remember { mutableStateOf<Post?>(null) }
    var reportingPost by remember { mutableStateOf<Post?>(null) }

    val filteredPosts = when (subTab) {
        "following" -> posts.filter { followingIds.contains(it.authorId) || it.authorId == currentUser.id }
        else -> posts
    }

    Column(modifier = modifier.fillMaxSize()) {
        // Sticky Sub-Navigation Bar
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = Slate900.copy(alpha = 0.9f),
            border = androidx.compose.foundation.BorderStroke(0.5.dp, Slate800)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    SubTabItem(
                        label = "สำหรับคุณ",
                        isSelected = subTab == "all",
                        onClick = { subTab = "all" }
                    )
                    SubTabItem(
                        label = "กำลังติดตาม",
                        isSelected = subTab == "following",
                        onClick = { subTab = "following" }
                    )
                    SubTabItem(
                        label = "คอมมูนิตี้ & คลับ",
                        isSelected = subTab == "clubs",
                        onClick = { subTab = "clubs" }
                    )
                }

                Button(
                    onClick = { isCreatePostOpen = true },
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AddCircle,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "โพสต์",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }

        if (subTab == "clubs") {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(vertical = 10.dp)
            ) {
                item {
                    ClubsView(
                        clubs = clubs,
                        forumTopics = forumTopics,
                        currentUser = currentUser,
                        users = users,
                        onJoinClub = onJoinClub,
                        onLeaveClub = onLeaveClub,
                        onCreateTopic = onCreateTopic
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 72.dp)
            ) {
                // Stories Bar
                item {
                    StoryBar(
                        currentUser = currentUser,
                        users = users,
                        stories = stories,
                        onAddStory = onAddStory
                    )
                }

                // Quick Create Post Bar
                item {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        shape = RoundedCornerShape(20.dp),
                        color = Slate900,
                        border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            AsyncImage(
                                model = currentUser.avatar,
                                contentDescription = currentUser.displayName,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                            )

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(Slate950)
                                    .clickable { isCreatePostOpen = true }
                                    .padding(horizontal = 14.dp, vertical = 8.dp)
                            ) {
                                Text(
                                    text = "คุณกำลังคิดอะไรอยู่? หาเพื่อนคุย...",
                                    fontSize = 12.sp,
                                    color = Slate400
                                )
                            }

                            IconButton(
                                onClick = { isCreatePostOpen = true },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Image,
                                    contentDescription = "แนบรูป",
                                    tint = PinkPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }

                // Posts List
                items(filteredPosts, key = { it.id }) { post ->
                    val author = users.find { it.id == post.authorId }
                    val isFollowing = followingIds.contains(post.authorId)
                    PostCard(
                        post = post,
                        author = author,
                        currentUser = currentUser,
                        isFollowing = isFollowing,
                        onToggleFollow = { onToggleFollow(post.authorId) },
                        onLikePost = { onLikePost(post.id) },
                        onOpenComments = { activeCommentPost = post },
                        onOpenReport = { reportingPost = post },
                        onDeletePost = { onDeletePost(post.id) }
                    )
                }
            }
        }
    }

    // Dialogs
    CreatePostDialog(
        isOpen = isCreatePostOpen,
        currentUser = currentUser,
        onClose = { isCreatePostOpen = false },
        onSubmitPost = onCreatePost
    )

    PostCommentsDialog(
        isOpen = activeCommentPost != null,
        post = activeCommentPost,
        currentUser = currentUser,
        users = users,
        onClose = { activeCommentPost = null }
    )

    reportingPost?.let { post ->
        val author = users.find { it.id == post.authorId }
        ReportDialog(
            isOpen = true,
            targetType = "post",
            targetId = post.id,
            targetName = "โพสต์ของ ${author?.displayName ?: "ผู้ใช้"}",
            onClose = { reportingPost = null },
            onSubmitReport = { reason, details ->
                onCreateReport("post", post.id, reason, details)
                reportingPost = null
            }
        )
    }
}

@Composable
private fun SubTabItem(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .clickable { onClick() }
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = if (isSelected) PinkLight else Slate400
        )
        if (isSelected) {
            Spacer(modifier = Modifier.height(2.dp))
            Box(
                modifier = Modifier
                    .width(24.dp)
                    .height(2.dp)
                    .clip(RoundedCornerShape(1.dp))
                    .background(PinkPrimary)
            )
        }
    }
}
