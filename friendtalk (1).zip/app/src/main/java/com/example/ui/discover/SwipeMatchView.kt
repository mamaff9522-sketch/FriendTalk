package com.example.ui.discover

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.model.User
import com.example.service.SoundService
import com.example.ui.theme.*

@Composable
fun SwipeMatchView(
    currentUser: User,
    users: List<User>,
    onToggleFriend: (String) -> Unit,
    onStartChat: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val candidates = remember(users, currentUser.id) {
        users.filter { it.id != currentUser.id && !it.isSuspended }
    }

    var currentIndex by remember { mutableStateOf(0) }
    var matchedUser by remember { mutableStateOf<User?>(null) }

    val currentCandidate = candidates.getOrNull(currentIndex)

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Header
        Text(
            text = "✨ ปัดหาเพื่อนและจับคู่ (Match)",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Text(
            text = "ปัดขวาชอบ ปัดซ้ายข้าม หรือกดปุ่มด้านล่าง",
            fontSize = 11.sp,
            color = Slate400
        )

        Spacer(modifier = Modifier.height(14.dp))

        if (currentCandidate != null) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(430.dp),
                shape = RoundedCornerShape(28.dp),
                color = Slate900,
                border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    // Profile Photo
                    AsyncImage(
                        model = currentCandidate.photos.firstOrNull() ?: currentCandidate.avatar,
                        contentDescription = currentCandidate.displayName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )

                    // Top Status Badge
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Surface(
                            color = Color.Black.copy(alpha = 0.6f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = currentCandidate.badges.firstOrNull() ?: "สมาชิก FriendTalk",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        if (currentCandidate.isOnline) {
                            Surface(
                                color = EmeraldGreen.copy(alpha = 0.9f),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .clip(CircleShape)
                                            .background(Color.White)
                                    )
                                    Text("ออนไลน์", fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // Bottom Profile Info
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color.Transparent, Slate950.copy(alpha = 0.85f), Slate950)
                                )
                            )
                            .padding(16.dp)
                    ) {
                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = currentCandidate.displayName,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color.White
                                )
                                Text(
                                    text = "${currentCandidate.age}",
                                    fontSize = 15.sp,
                                    color = Slate300
                                )
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                modifier = Modifier.padding(vertical = 3.dp)
                            ) {
                                Icon(Icons.Default.Place, contentDescription = null, tint = PinkPrimary, modifier = Modifier.size(13.dp))
                                Text(
                                    text = "ห่างประมาณ ${currentCandidate.location.distanceKm} กม. • ${currentCandidate.location.province}",
                                    fontSize = 11.sp,
                                    color = PinkLight
                                )
                            }

                            Text(
                                text = currentCandidate.bio,
                                fontSize = 12.sp,
                                color = Slate200,
                                maxLines = 2,
                                lineHeight = 16.sp
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            // Action Buttons (Pass, SuperLike, Like)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Pass Button
                                IconButton(
                                    onClick = {
                                        SoundService.playPop()
                                        currentIndex = (currentIndex + 1) % candidates.size
                                    },
                                    modifier = Modifier
                                        .size(48.dp)
                                        .background(Slate900, CircleShape)
                                        .border(1.dp, Slate700, CircleShape)
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = "ข้าม", tint = Color.Red, modifier = Modifier.size(22.dp))
                                }

                                Spacer(modifier = Modifier.width(18.dp))

                                // Super Like Button
                                IconButton(
                                    onClick = {
                                        SoundService.playGiftFanfare()
                                        onToggleFriend(currentCandidate.id)
                                        matchedUser = currentCandidate
                                        currentIndex = (currentIndex + 1) % candidates.size
                                    },
                                    modifier = Modifier
                                        .size(44.dp)
                                        .background(Slate900, CircleShape)
                                        .border(1.dp, AmberGold, CircleShape)
                                ) {
                                    Icon(Icons.Default.Star, contentDescription = "Super Like", tint = AmberGold, modifier = Modifier.size(20.dp))
                                }

                                Spacer(modifier = Modifier.width(18.dp))

                                // Like Button
                                IconButton(
                                    onClick = {
                                        SoundService.playMatch()
                                        onToggleFriend(currentCandidate.id)
                                        matchedUser = currentCandidate
                                        currentIndex = (currentIndex + 1) % candidates.size
                                    },
                                    modifier = Modifier
                                        .size(54.dp)
                                        .background(
                                            Brush.linearGradient(listOf(PinkPrimary, RosePrimary)),
                                            CircleShape
                                        )
                                ) {
                                    Icon(Icons.Default.Favorite, contentDescription = "ถูกใจ", tint = Color.White, modifier = Modifier.size(26.dp))
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // All candidates viewed
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.padding(32.dp)
            ) {
                Text(text = "คุณได้ดูโปรไฟล์ทั้งหมดในบริเวณนี้แล้ว", fontSize = 13.sp, color = Slate400)
                Button(
                    onClick = { currentIndex = 0 },
                    colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("เริ่มดูใหม่อีกครั้ง", fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    // Match Celebration Modal
    matchedUser?.let { match ->
        Dialog(onDismissRequest = { matchedUser = null }) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                color = Slate900,
                border = androidx.compose.foundation.BorderStroke(1.5.dp, PinkPrimary)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(text = "💖", fontSize = 48.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "แมตช์สำเร็จ!",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                    Text(
                        text = "คุณและ ${match.displayName} ถูกใจกันและกัน",
                        fontSize = 12.sp,
                        color = Slate300
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    // Dual Avatars
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        AsyncImage(
                            model = currentUser.avatar,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .border(3.dp, PinkPrimary, CircleShape)
                        )
                        Spacer(modifier = Modifier.width((-14).dp))
                        AsyncImage(
                            model = match.avatar,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .border(3.dp, AmberGold, CircleShape)
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Button(
                        onClick = {
                            val id = match.id
                            matchedUser = null
                            onStartChat(id)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary)
                    ) {
                        Icon(Icons.Default.ChatBubble, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("เริ่มคุยเลยทันที", fontWeight = FontWeight.Bold, color = Color.White)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    TextButton(onClick = { matchedUser = null }) {
                        Text("ปัดหาเพื่อนต่อ", color = Slate400, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
