package com.example.ui.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.model.*
import com.example.service.SoundService
import com.example.ui.theme.*

@Composable
fun AdminDashboardDialog(
    isOpen: Boolean,
    currentUser: User,
    users: List<User>,
    liveRooms: List<LiveRoom>,
    reports: List<Report>,
    withdrawals: List<WithdrawalRequest>,
    adminLogs: List<AdminLog>,
    onClose: () -> Unit,
    onSuspendUser: (userId: String, suspend: Boolean) -> Unit,
    onBanUser: (userId: String, ban: Boolean) -> Unit,
    onChangeRole: (userId: String, role: UserRole) -> Unit,
    onReviewReport: (reportId: String, action: String, note: String?) -> Unit,
    onReviewWithdrawal: (withdrawalId: String, status: String) -> Unit,
    onBroadcastNotification: (title: String, body: String) -> Unit,
    onTerminateLive: (roomId: String) -> Unit,
    onDeletePost: (String) -> Unit,
    onOpenUiBuilder: () -> Unit = {},
    onOpenApkDownload: () -> Unit = {}
) {
    if (!isOpen) return

    var activeTab by remember { mutableStateOf("stats") } // "stats", "users", "reports", "live", "withdrawals", "broadcast", "logs"
    var userSearch by remember { mutableStateOf("") }
    var broadcastTitle by remember { mutableStateOf("") }
    var broadcastBody by remember { mutableStateOf("") }
    var broadcastSuccess by remember { mutableStateOf(false) }

    val totalUsers = users.size
    val onlineUsers = users.count { it.isOnline }
    val activeLiveRooms = liveRooms.count { it.isLive }
    val pendingReports = reports.count { it.status == "pending" }
    val pendingWithdrawals = withdrawals.count { it.status == "pending" }
    val totalCoinsEconomy = users.sumOf { it.coins }

    val filteredUsers = remember(users, userSearch) {
        if (userSearch.isBlank()) users
        else users.filter { it.displayName.contains(userSearch, true) || it.username.contains(userSearch, true) }
    }

    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Slate950
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header
                Surface(
                    color = Slate900,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 36.dp, bottom = 12.dp, start = 14.dp, end = 14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(AmberGold.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Security, contentDescription = null, tint = AmberGold, modifier = Modifier.size(20.dp))
                            }
                            Column {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text("FriendTalk Admin Console", fontSize = 14.sp, fontWeight = FontWeight.Black, color = Color.White)
                                    Surface(
                                        color = AmberGold,
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text("ADMIN", color = Slate950, fontSize = 9.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                                    }
                                }
                                Text("ระบบควบคุมและบริหารแอปพลิเคชัน", fontSize = 10.sp, color = Slate400)
                            }
                        }

                        IconButton(onClick = onClose) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Slate400)
                        }
                    }
                }

                // Admin Sub-Nav Tabs
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Slate900.copy(alpha = 0.6f))
                        .padding(horizontal = 8.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val tabs = listOf(
                        Pair("stats", "สรุปสถิติ"),
                        Pair("uibuilder", "🎨 UI Builder"),
                        Pair("apk", "📦 ดาวน์โหลด APK"),
                        Pair("users", "ผู้ใช้งาน ($totalUsers)"),
                        Pair("reports", "รายงาน ($pendingReports)"),
                        Pair("live", "ห้องไลฟ์ ($activeLiveRooms)"),
                        Pair("withdrawals", "ถอนเงิน ($pendingWithdrawals)"),
                        Pair("broadcast", "ประกาศ Push"),
                        Pair("logs", "บันทึกงาน")
                    )
                    items(tabs) { tab ->
                        val isSelected = activeTab == tab.first
                        Surface(
                            onClick = {
                                SoundService.playPop()
                                activeTab = tab.first
                            },
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) AmberGold else Slate800
                        ) {
                            Text(
                                text = tab.second,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Black else FontWeight.Normal,
                                color = if (isSelected) Slate950 else Slate300,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                // Main Admin Panel
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(14.dp)
                ) {
                    when (activeTab) {
                        "stats" -> {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                item {
                                    Text("ภาพรวมระบบแบบเรียลไทม์ (Real-time KPIs)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Slate400)
                                }
                                item {
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        KpiCard("ผู้ใช้งานทั้งหมด", "$totalUsers คน", "🟢 ออนไลน์ $onlineUsers คน", Modifier.weight(1f))
                                        KpiCard("ห้องไลฟ์สดสตรีม", "$activeLiveRooms ห้อง", "รวมคนดู 4,730 คน", Modifier.weight(1f))
                                    }
                                }
                                item {
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        KpiCard("รายงานรอตรวจสอบ", "$pendingReports รายการ", "ตรวจความปลอดภัย 24 ชม.", Modifier.weight(1f))
                                        KpiCard("คำขอถอนเงินรอตรวจ", "$pendingWithdrawals คำขอ", "มูลค่ารวม ฿15,000", Modifier.weight(1f))
                                    }
                                }
                                item {
                                    Surface(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(18.dp),
                                        color = Slate900,
                                        border = androidx.compose.foundation.BorderStroke(1.dp, AmberGold.copy(alpha = 0.4f))
                                    ) {
                                        Column(modifier = Modifier.padding(14.dp)) {
                                            Text("เหรียญหมุนเวียนในระบบ (Coins Economy)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AmberLight)
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text("🪙 $totalCoinsEconomy Coins", fontSize = 22.sp, fontWeight = FontWeight.Black, color = Color.White)
                                            Text("≈ ฿${(totalCoinsEconomy * 0.35).toInt()} มูลค่าเทียบเท่า", fontSize = 11.sp, color = EmeraldGreen)
                                        }
                                    }
                                }
                            }
                        }

                        "users" -> {
                            Column(modifier = Modifier.fillMaxSize()) {
                                OutlinedTextField(
                                    value = userSearch,
                                    onValueChange = { userSearch = it },
                                    placeholder = { Text("ค้นหาชื่อ หรือ username...", fontSize = 11.sp, color = Slate400) },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true,
                                    shape = RoundedCornerShape(14.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = AmberGold,
                                        unfocusedBorderColor = Slate800,
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White
                                    )
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    items(filteredUsers) { user ->
                                        Surface(
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(16.dp),
                                            color = Slate900,
                                            border = androidx.compose.foundation.BorderStroke(
                                                1.dp,
                                                if (user.isBanned) Color.Red else if (user.isSuspended) AmberGold else Slate800
                                            )
                                        ) {
                                            Column(modifier = Modifier.padding(12.dp)) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                    ) {
                                                        AsyncImage(
                                                            model = user.avatar,
                                                            contentDescription = null,
                                                            contentScale = ContentScale.Crop,
                                                            modifier = Modifier
                                                                .size(36.dp)
                                                                .clip(CircleShape)
                                                        )
                                                        Column {
                                                            Text(user.displayName, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                                            Text("@${user.username} • Role: ${user.role}", fontSize = 10.sp, color = Slate400)
                                                        }
                                                    }

                                                    Text("🪙 ${user.coins}", fontSize = 11.sp, color = AmberGold, fontWeight = FontWeight.Bold)
                                                }

                                                Spacer(modifier = Modifier.height(8.dp))

                                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                    Button(
                                                        onClick = { onSuspendUser(user.id, !user.isSuspended) },
                                                        shape = RoundedCornerShape(8.dp),
                                                        colors = ButtonDefaults.buttonColors(
                                                            containerColor = if (user.isSuspended) EmeraldGreen else AmberGold.copy(alpha = 0.2f)
                                                        ),
                                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                                    ) {
                                                        Text(if (user.isSuspended) "ปลดระงับ" else "ระงับชั่วคราว", fontSize = 10.sp, color = if (user.isSuspended) Color.White else AmberGold)
                                                    }

                                                    Button(
                                                        onClick = { onBanUser(user.id, !user.isBanned) },
                                                        shape = RoundedCornerShape(8.dp),
                                                        colors = ButtonDefaults.buttonColors(
                                                            containerColor = if (user.isBanned) EmeraldGreen else Color.Red.copy(alpha = 0.2f)
                                                        ),
                                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                                    ) {
                                                        Text(if (user.isBanned) "ปลดแบน" else "แบนถาวร", fontSize = 10.sp, color = if (user.isBanned) Color.White else Color.Red)
                                                    }

                                                    Button(
                                                        onClick = {
                                                            val nextRole = when (user.role) {
                                                                UserRole.USER -> UserRole.MODERATOR
                                                                UserRole.MODERATOR -> UserRole.ADMIN
                                                                else -> UserRole.USER
                                                            }
                                                            onChangeRole(user.id, nextRole)
                                                        },
                                                        shape = RoundedCornerShape(8.dp),
                                                        colors = ButtonDefaults.buttonColors(containerColor = Slate800),
                                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                                    ) {
                                                        Text("สิทธิ์: ${user.role}", fontSize = 10.sp, color = Slate300)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        "reports" -> {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(reports) { rep ->
                                    Surface(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(16.dp),
                                        color = Slate900,
                                        border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text("รายงาน: ${rep.targetType.uppercase()}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = RosePrimary)
                                                Text(rep.createdAt, fontSize = 10.sp, color = Slate500)
                                            }
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(rep.reason, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                            rep.details?.let {
                                                Text("\"$it\"", fontSize = 11.sp, color = Slate300)
                                            }
                                            Spacer(modifier = Modifier.height(8.dp))
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text("สถานะ: ${rep.status}", fontSize = 10.sp, color = if (rep.status == "pending") AmberLight else EmeraldGreen)

                                                if (rep.status == "pending") {
                                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                        Button(
                                                            onClick = { onReviewReport(rep.id, "dismissed", "ไม่พบความผิดปกติ") },
                                                            colors = ButtonDefaults.buttonColors(containerColor = Slate800),
                                                            shape = RoundedCornerShape(8.dp),
                                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                                        ) {
                                                            Text("ยกฟ้อง", fontSize = 10.sp)
                                                        }
                                                        Button(
                                                            onClick = {
                                                                onReviewReport(rep.id, "action_taken", "ลงโทษแล้ว")
                                                                if (rep.targetType == "post") onDeletePost(rep.targetId)
                                                            },
                                                            colors = ButtonDefaults.buttonColors(containerColor = RosePrimary),
                                                            shape = RoundedCornerShape(8.dp),
                                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                                        ) {
                                                            Text("ดำเนินการ", fontSize = 10.sp, color = Color.White)
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        "live" -> {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(liveRooms.filter { it.isLive }) { room ->
                                    val host = users.find { it.id == room.hostId }
                                    Surface(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(16.dp),
                                        color = Slate900,
                                        border = androidx.compose.foundation.BorderStroke(1.dp, RosePrimary.copy(alpha = 0.4f))
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(12.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                AsyncImage(
                                                    model = room.coverUrl,
                                                    contentDescription = null,
                                                    contentScale = ContentScale.Crop,
                                                    modifier = Modifier
                                                        .size(46.dp)
                                                        .clip(RoundedCornerShape(10.dp))
                                                )
                                                Column {
                                                    Text(room.title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1)
                                                    Text("Host: ${host?.displayName ?: "User"} • ${room.viewersCount} คนดู", fontSize = 10.sp, color = Slate400)
                                                    Text("🪙 ${room.currentGiftCoins} Coins", fontSize = 10.sp, color = AmberGold)
                                                }
                                            }

                                            Button(
                                                onClick = { onTerminateLive(room.id) },
                                                colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                                                shape = RoundedCornerShape(10.dp)
                                            ) {
                                                Text("สั่งปิดไลฟ์", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        "withdrawals" -> {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(withdrawals) { w ->
                                    val creator = users.find { it.id == w.creatorId }
                                    Surface(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(16.dp),
                                        color = Slate900,
                                        border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text("Creator: ${creator?.displayName ?: "User"}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                                Text("฿${w.amountBaht}", fontSize = 13.sp, fontWeight = FontWeight.Black, color = EmeraldGreen)
                                            }
                                            Text("Diamonds: 💎 ${w.amountCoins} • ${w.bankName}", fontSize = 10.sp, color = Slate400)
                                            Text("บัญชี: ${w.accountNumber} (${w.accountName})", fontSize = 10.sp, color = Slate300)

                                            Spacer(modifier = Modifier.height(8.dp))
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text("สถานะ: ${w.status}", fontSize = 10.sp, color = if (w.status == "pending") AmberLight else EmeraldGreen)

                                                if (w.status == "pending") {
                                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                        Button(
                                                            onClick = { onReviewWithdrawal(w.id, "rejected") },
                                                            colors = ButtonDefaults.buttonColors(containerColor = Slate800),
                                                            shape = RoundedCornerShape(8.dp),
                                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                                        ) {
                                                            Text("ปฏิเสธ", fontSize = 10.sp)
                                                        }
                                                        Button(
                                                            onClick = { onReviewWithdrawal(w.id, "approved") },
                                                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
                                                            shape = RoundedCornerShape(8.dp),
                                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                                        ) {
                                                            Text("อนุมัติ", fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        "broadcast" -> {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("ส่งประกาศ Push Notification ถึงผู้ใช้ทุกคน", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)

                                if (broadcastSuccess) {
                                    Surface(
                                        color = EmeraldGreen.copy(alpha = 0.2f),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Text("ส่งประกาศสำเร็จแล้ว!", color = EmeraldGreen, fontSize = 12.sp, modifier = Modifier.padding(12.dp))
                                    }
                                }

                                OutlinedTextField(
                                    value = broadcastTitle,
                                    onValueChange = { broadcastTitle = it },
                                    label = { Text("หัวข้อประกาศ") },
                                    placeholder = { Text("เช่น กิจกรรมแจกเหรียญประจำสัปดาห์! 🎉") },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = AmberGold,
                                        unfocusedBorderColor = Slate800,
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White
                                    )
                                )

                                OutlinedTextField(
                                    value = broadcastBody,
                                    onValueChange = { broadcastBody = it },
                                    label = { Text("เนื้อหาข้อความ") },
                                    placeholder = { Text("พิมพ์ข้อความที่ต้องการแจ้งเตือนถึงสมาชิกทุกคน...") },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(100.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = AmberGold,
                                        unfocusedBorderColor = Slate800,
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White
                                    )
                                )

                                Button(
                                    onClick = {
                                        if (broadcastTitle.isNotBlank() && broadcastBody.isNotBlank()) {
                                            onBroadcastNotification(broadcastTitle.trim(), broadcastBody.trim())
                                            broadcastTitle = ""
                                            broadcastBody = ""
                                            broadcastSuccess = true
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = AmberGold)
                                ) {
                                    Text("ส่งประกาศ Push ทันที ($totalUsers ผู้ใช้)", fontWeight = FontWeight.Black, color = Slate950)
                                }
                            }
                        }

                        "uibuilder" -> {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Surface(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    color = Slate900,
                                    border = androidx.compose.foundation.BorderStroke(1.5.dp, PinkPrimary)
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(44.dp)
                                                    .clip(RoundedCornerShape(12.dp))
                                                    .background(PinkPrimary.copy(alpha = 0.2f)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(Icons.Default.DashboardCustomize, contentDescription = null, tint = PinkPrimary, modifier = Modifier.size(24.dp))
                                            }
                                            Column {
                                                Text("Admin UI Builder & Remote Config", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                                Text("ปรับแต่งโครงสร้างหน้าตาแอป Section เมนู และชุดสีแบบ No-Code", fontSize = 11.sp, color = Slate400)
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(12.dp))
                                        Text(
                                            "• ปรับแก้หน้า Feed, ค้นหาเพื่อน, Live, Video/Movie, เพื่อนคุย, และโปรไฟล์\n• เพิ่ม/ลบ/ซ่อน/สลับลำดับ Section และแถบเมนูนำทาง\n• เปลี่ยนรูปภาพ แบนเนอร์ โลโก้ จากมือถือ คลังภาพ หรือกล้อง\n• ระบบพรีวิวเสมือนมือถือจริง และบันทึก Draft\n• เมื่อกด Publish แล้ว แอปบนมือถือผู้ใช้จะอัปเดตหน้าตาทันที ไม่ต้อง Build APK ใหม่",
                                            fontSize = 11.sp,
                                            color = Slate300,
                                            lineHeight = 18.sp
                                        )

                                        Spacer(modifier = Modifier.height(14.dp))
                                        Button(
                                            onClick = onOpenUiBuilder,
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(12.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary)
                                        ) {
                                            Icon(Icons.Default.Palette, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("เปิดระบบ Admin UI Builder ทันที", fontWeight = FontWeight.Bold, color = Color.White)
                                        }
                                    }
                                }
                            }
                        }

                        "apk" -> {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Surface(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    color = Slate900,
                                    border = androidx.compose.foundation.BorderStroke(1.5.dp, EmeraldGreen)
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(44.dp)
                                                    .clip(RoundedCornerShape(12.dp))
                                                    .background(EmeraldGreen.copy(alpha = 0.2f)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(Icons.Default.Android, contentDescription = null, tint = EmeraldGreen, modifier = Modifier.size(24.dp))
                                            }
                                            Column {
                                                Text("หน้าดาวน์โหลด APK FriendTalk", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                                Text("สำหรับ Admin ติดตั้งบนสมาร์ตโฟนจริงโดยตรง", fontSize = 11.sp, color = Slate400)
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(12.dp))
                                        Text(
                                            "• พร้อมดาวน์โหลด APK ล่าสุดทันทีโดยไม่ต้องค้นหาไฟล์เอง\n• แสดงสถานะ Build Status, ขนาดไฟล์, และวันที่สร้าง\n• จัดเก็บประวัติการ Build (Build History) ทุกเวอร์ชันไม่ลบอัตโนมัติ\n• รองรับการเชื่อมต่อ Remote UI Config ตั้งแต่เปิดแอปครั้งแรก",
                                            fontSize = 11.sp,
                                            color = Slate300,
                                            lineHeight = 18.sp
                                        )

                                        Spacer(modifier = Modifier.height(14.dp))
                                        Button(
                                            onClick = onOpenApkDownload,
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(12.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen)
                                        ) {
                                            Icon(Icons.Default.Download, contentDescription = null, tint = Slate950, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("เปิดหน้า Download APK ทันที", fontWeight = FontWeight.Black, color = Slate950)
                                        }
                                    }
                                }
                            }
                        }

                        "logs" -> {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(adminLogs) { log ->
                                    Surface(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(14.dp),
                                        color = Slate900,
                                        border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
                                    ) {
                                        Column(modifier = Modifier.padding(10.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text(log.adminName, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AmberGold)
                                                Text(log.timestamp, fontSize = 9.sp, color = Slate500)
                                            }
                                            Text(log.action, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                            Text(log.details, fontSize = 10.sp, color = Slate400)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun KpiCard(title: String, value: String, subtitle: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = Slate900,
        border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(title, fontSize = 10.sp, color = Slate400)
            Spacer(modifier = Modifier.height(2.dp))
            Text(value, fontSize = 18.sp, fontWeight = FontWeight.Black, color = Color.White)
            Spacer(modifier = Modifier.height(2.dp))
            Text(subtitle, fontSize = 10.sp, color = EmeraldGreen)
        }
    }
}
