package com.example.ui.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.User
import com.example.model.WithdrawalRequest
import com.example.ui.theme.*

@Composable
fun CreatorStudioDialog(
    isOpen: Boolean,
    currentUser: User,
    withdrawals: List<WithdrawalRequest>,
    onClose: () -> Unit,
    onRequestWithdrawal: (amountCoins: Int, bankName: String, accountNumber: String, accountName: String) -> Boolean
) {
    if (!isOpen) return

    var activeTab by remember { mutableStateOf("withdraw") } // "withdraw", "history"
    var amountStr by remember { mutableStateOf("500") }
    var bankName by remember { mutableStateOf("ธนาคารกสิกรไทย (KBANK)") }
    var accountNumber by remember { mutableStateOf("") }
    var accountName by remember { mutableStateOf(currentUser.displayName) }
    var successMessage by remember { mutableStateOf<String?>(null) }

    val creatorWithdrawals = remember(withdrawals, currentUser.id) {
        withdrawals.filter { it.creatorId == currentUser.id }
    }

    Dialog(onDismissRequest = onClose) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f),
            shape = RoundedCornerShape(28.dp),
            color = Slate900,
            border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Diamond,
                            contentDescription = null,
                            tint = PurpleAccent,
                            modifier = Modifier.size(24.dp)
                        )
                        Column {
                            Text(
                                text = "ศูนย์ครีเอเตอร์ (Creator Studio)",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "รายได้จากของขวัญและการไลฟ์สด",
                                fontSize = 10.sp,
                                color = Slate400
                            )
                        }
                    }
                    IconButton(onClick = onClose) {
                        Icon(Icons.Default.Close, contentDescription = "ปิด", tint = Slate400)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Diamond Balance Card
                Surface(
                    color = Slate950,
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, PurpleAccent.copy(alpha = 0.4f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Diamonds สะสม", fontSize = 10.sp, color = PurpleAccent, fontWeight = FontWeight.Bold)
                            Text("💎 ${currentUser.diamonds}", fontSize = 20.sp, fontWeight = FontWeight.Black, color = Color.White)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("มูลค่าประมาณ", fontSize = 10.sp, color = Slate400)
                            Text("≈ ฿${(currentUser.diamonds * 0.5).toInt()}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = EmeraldGreen)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Sub-tabs
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Slate950)
                        .padding(4.dp)
                ) {
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { activeTab = "withdraw" },
                        color = if (activeTab == "withdraw") PinkPrimary else Color.Transparent,
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = "ยื่นขอถอนรายได้",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (activeTab == "withdraw") Color.White else Slate400,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }

                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { activeTab = "history" },
                        color = if (activeTab == "history") PinkPrimary else Color.Transparent,
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = "ประวัติการถอน (${creatorWithdrawals.size})",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (activeTab == "history") Color.White else Slate400,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                if (activeTab == "withdraw") {
                    if (successMessage != null) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(vertical = 24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text("🎉", fontSize = 48.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(successMessage!!, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(onClick = { successMessage = null; activeTab = "history" }) {
                                Text("ดูประวัติการถอน")
                            }
                        }
                    } else {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = amountStr,
                                onValueChange = { amountStr = it },
                                label = { Text("จำนวน Diamonds ที่ต้องการถอน") },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = PinkPrimary,
                                    unfocusedBorderColor = Slate800,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                )
                            )

                            OutlinedTextField(
                                value = bankName,
                                onValueChange = { bankName = it },
                                label = { Text("ธนาคารปลายทาง / พร้อมเพย์") },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = PinkPrimary,
                                    unfocusedBorderColor = Slate800,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                )
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = accountNumber,
                                    onValueChange = { accountNumber = it },
                                    label = { Text("เลขบัญชี") },
                                    placeholder = { Text("0xx-x-xxxxx-x") },
                                    modifier = Modifier.weight(1f),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = PinkPrimary,
                                        unfocusedBorderColor = Slate800,
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White
                                    )
                                )
                                OutlinedTextField(
                                    value = accountName,
                                    onValueChange = { accountName = it },
                                    label = { Text("ชื่อบัญชี") },
                                    modifier = Modifier.weight(1f),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = PinkPrimary,
                                        unfocusedBorderColor = Slate800,
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White
                                    )
                                )
                            }

                            Spacer(modifier = Modifier.weight(1f))

                            Button(
                                onClick = {
                                    val amount = amountStr.toIntOrNull() ?: 0
                                    if (amount > 0 && accountNumber.isNotBlank() && accountName.isNotBlank()) {
                                        val ok = onRequestWithdrawal(amount, bankName, accountNumber, accountName)
                                        if (ok) {
                                            successMessage = "ส่งคำขอถอนเงินเรียบร้อยแล้ว!"
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary)
                            ) {
                                Text("ส่งคำขอถอนเงิน", fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }
                } else {
                    // History list
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(creatorWithdrawals) { w ->
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                                color = Slate950,
                                border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("💎 ${w.amountCoins} Diamonds (฿${w.amountBaht})", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                        Text(w.bankName, fontSize = 11.sp, color = Slate400)
                                        Text(w.createdAt, fontSize = 10.sp, color = Slate500)
                                    }

                                    Surface(
                                        color = when (w.status) {
                                            "approved" -> EmeraldGreen.copy(alpha = 0.2f)
                                            "rejected" -> Color.Red.copy(alpha = 0.2f)
                                            else -> AmberGold.copy(alpha = 0.2f)
                                        },
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text(
                                            text = when (w.status) {
                                                "approved" -> "อนุมัติแล้ว ✓"
                                                "rejected" -> "ปฏิเสธ"
                                                else -> "รอตรวจสอบ"
                                            },
                                            color = when (w.status) {
                                                "approved" -> EmeraldGreen
                                                "rejected" -> Color.Red
                                                else -> AmberLight
                                            },
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
