package com.example.ui.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.*
import com.example.ui.admin.AdminDashboardDialog
import com.example.ui.components.AuthDialog
import com.example.ui.components.CoinWalletDialog
import com.example.ui.components.PermissionDialog
import com.example.ui.theme.*

@Composable
fun ProfileTab(
    currentUser: User,
    users: List<User>,
    liveRooms: List<LiveRoom>,
    reports: List<Report>,
    withdrawals: List<WithdrawalRequest>,
    adminLogs: List<AdminLog>,
    permissions: AppPermissions,
    blockedUserIds: Set<String>,
    onUnblockUser: (String) -> Unit,
    onSaveProfile: (displayName: String, bio: String, age: Int, gender: Gender, province: String, interests: List<String>) -> Unit,
    onTopUpCoins: (amount: Int, priceBaht: Int) -> Unit,
    onRequestWithdrawal: (amountCoins: Int, bankName: String, accountNumber: String, accountName: String) -> Boolean,
    onToggleLocationSharing: () -> Unit,
    onUpdatePermissions: (camera: Boolean, mic: Boolean, geo: Boolean, notif: Boolean) -> Unit,
    onSwitchUser: (String) -> Unit,
    onRegisterUser: (displayName: String, username: String, age: Int, gender: Gender) -> Unit,
    onSuspendUser: (userId: String, suspend: Boolean) -> Unit,
    onBanUser: (userId: String, ban: Boolean) -> Unit,
    onChangeRole: (userId: String, role: UserRole) -> Unit,
    onReviewReport: (reportId: String, action: String, note: String?) -> Unit,
    onReviewWithdrawal: (withdrawalId: String, status: String) -> Unit,
    onBroadcastNotification: (title: String, body: String) -> Unit,
    onTerminateLive: (roomId: String) -> Unit,
    onDeletePost: (String) -> Unit,
    onNavigateToCompanion: (() -> Unit)? = null,
    onOpenAdminDashboard: (() -> Unit)? = null,
    onOpenUiBuilder: (() -> Unit)? = null,
    onOpenApkDownload: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    var isEditProfileOpen by remember { mutableStateOf(false) }
    var isWalletOpen by remember { mutableStateOf(false) }
    var isCreatorStudioOpen by remember { mutableStateOf(false) }
    var isAdminDashboardOpen by remember { mutableStateOf(false) }
    var isPermissionsOpen by remember { mutableStateOf(false) }
    var isAuthOpen by remember { mutableStateOf(false) }
    var showBlockedList by remember { mutableStateOf(false) }

    val blockedUsers = remember(users, blockedUserIds) {
        users.filter { blockedUserIds.contains(it.id) }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(bottom = 72.dp)
    ) {
        // Cover and Avatar
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(150.dp)
            ) {
                AsyncImage(
                    model = currentUser.coverPhoto,
                    contentDescription = "Cover",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Avatar overlapping
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(start = 16.dp)
                        .offset(y = 35.dp)
                ) {
                    AsyncImage(
                        model = currentUser.avatar,
                        contentDescription = currentUser.displayName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(80.dp)
                            .clip(CircleShape)
                            .border(3.dp, Slate950, CircleShape)
                    )
                }

                // Edit Profile Button
                Button(
                    onClick = { isEditProfileOpen = true },
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(end = 16.dp, bottom = 10.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Slate900),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Slate800),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Edit, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("แก้ไขโปรไฟล์", fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(44.dp))
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                // Name & Badges
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = currentUser.displayName,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                    if (currentUser.isVerified) {
                        Text("✓", color = PinkPrimary, fontSize = 13.sp, fontWeight = FontWeight.Black)
                    }
                    if (currentUser.role == UserRole.SUPERADMIN) {
                        Surface(
                            color = AmberGold.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(6.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, AmberGold.copy(alpha = 0.4f))
                        ) {
                            Text("👑 SUPER ADMIN", color = AmberGold, fontSize = 9.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                        }
                    }
                }

                Text(
                    text = "@${currentUser.username} • ${currentUser.age} ปี • ${if (currentUser.gender == Gender.FEMALE) "ผู้หญิง" else if (currentUser.gender == Gender.MALE) "ผู้ชาย" else "LGBTQ+"}",
                    fontSize = 11.sp,
                    color = Slate400
                )

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = currentUser.bio,
                    fontSize = 12.sp,
                    color = Slate200,
                    lineHeight = 17.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Location & Tags
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(
                        color = PinkPrimary.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = "📍 ${if (currentUser.location.isSharing) currentUser.location.province else "ซ่อนตำแหน่ง"}",
                            fontSize = 10.sp,
                            color = PinkLight,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }

                    currentUser.interests.forEach { tag ->
                        Surface(
                            color = Slate800,
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = "#$tag",
                                fontSize = 10.sp,
                                color = Slate300,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Stats Row
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = Slate900,
                    border = androidx.compose.foundation.BorderStroke(1.dp, Slate800),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        StatItem(count = currentUser.friendsCount.toString(), label = "เพื่อน")
                        StatItem(count = currentUser.followersCount.toString(), label = "ผู้ติดตาม")
                        StatItem(count = currentUser.followingCount.toString(), label = "กำลังติดตาม")
                        StatItem(count = currentUser.giftsReceivedTotal.toString(), label = "ของขวัญ", color = PinkLight)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Wallet Card
                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = Slate900,
                    border = androidx.compose.foundation.BorderStroke(1.dp, AmberGold.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("เหรียญและรายได้ของคุณ", fontSize = 10.sp, color = AmberGold, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                                Column {
                                    Text("เหรียญ Coin", fontSize = 10.sp, color = Slate400)
                                    Text("🪙 ${currentUser.coins}", fontSize = 16.sp, fontWeight = FontWeight.Black, color = AmberLight)
                                }
                                Column {
                                    Text("Diamonds", fontSize = 10.sp, color = Slate400)
                                    Text("💎 ${currentUser.diamonds}", fontSize = 16.sp, fontWeight = FontWeight.Black, color = PurpleAccent)
                                }
                            }
                        }

                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Button(
                                onClick = { isWalletOpen = true },
                                colors = ButtonDefaults.buttonColors(containerColor = AmberGold),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                            ) {
                                Text("เติมเหรียญ", color = Slate950, fontWeight = FontWeight.Black, fontSize = 11.sp)
                            }
                            Button(
                                onClick = { isCreatorStudioOpen = true },
                                colors = ButtonDefaults.buttonColors(containerColor = PurpleAccent.copy(alpha = 0.25f)),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                            ) {
                                Text("ถอนรายได้", color = PurpleAccent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Navigation Menus
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Admin Items
                    if (currentUser.role == UserRole.ADMIN || currentUser.role == UserRole.SUPERADMIN) {
                        ProfileMenuItem(
                            icon = Icons.Default.Security,
                            title = "แผงควบคุมระบบ (Admin Dashboard)",
                            subtitle = "จัดการผู้ใช้ ตรวจสอบรายงาน ปิดไลฟ์ อนุมัติถอนเงิน ส่ง Push",
                            badge = "ADMIN",
                            badgeColor = AmberGold,
                            onClick = { onOpenAdminDashboard?.invoke() ?: run { isAdminDashboardOpen = true } }
                        )

                        ProfileMenuItem(
                            icon = Icons.Default.DashboardCustomize,
                            title = "Admin UI Builder & Remote Config",
                            subtitle = "ปรับแต่งหน้าตา Section สลับเมนู ธีม และ Publish แบบ No-Code",
                            badge = "BUILDER",
                            badgeColor = PinkPrimary,
                            onClick = { onOpenUiBuilder?.invoke() }
                        )

                        ProfileMenuItem(
                            icon = Icons.Default.Android,
                            title = "ดาวน์โหลด APK ระบบ (Admin APK Portal)",
                            subtitle = "ดาวน์โหลดหรือติดตั้ง APK FriendTalk บนมือถือจริง และดูประวัติการ Build",
                            badge = "APK",
                            badgeColor = EmeraldGreen,
                            onClick = { onOpenApkDownload?.invoke() }
                        )
                    }

                    // Creator Studio Item
                    ProfileMenuItem(
                        icon = Icons.Default.Diamond,
                        title = "ศูนย์ครีเอเตอร์ & สถิติรายได้",
                        subtitle = "ดูรายได้ของขวัญ ยื่นคำขอถอนเงิน",
                        onClick = { isCreatorStudioOpen = true }
                    )

                    // Companion Item (เพื่อนคุย - เฉพาะอายุ 18 ปีขึ้นไปเท่านั้น)
                    if (currentUser.age >= 18 && onNavigateToCompanion != null) {
                        ProfileMenuItem(
                            icon = Icons.Default.VolunteerActivism,
                            title = "ระบบเพื่อนคุย (Friend Companion)",
                            subtitle = "ค้นหาเพื่อนคุย, จัดการสถานะ หรือกระเป๋าเงินรายได้ (18+)",
                            badge = "18+",
                            badgeColor = PinkPrimary,
                            onClick = onNavigateToCompanion
                        )
                    }

                    // Permissions Item
                    ProfileMenuItem(
                        icon = Icons.Default.Tune,
                        title = "จัดการสิทธิ์และความเป็นส่วนตัว",
                        subtitle = "กล้อง ไมโครโฟน ตำแหน่ง และการแจ้งเตือน",
                        onClick = { isPermissionsOpen = true }
                    )

                    // Blocked Users Item
                    ProfileMenuItem(
                        icon = Icons.Default.Lock,
                        title = "รายชื่อที่บล็อก (${blockedUsers.size})",
                        subtitle = "จัดการบัญชีผู้ใช้ที่คุณบล็อกไว้",
                        onClick = { showBlockedList = !showBlockedList }
                    )

                    if (showBlockedList) {
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = Slate950,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                if (blockedUsers.isEmpty()) {
                                    Text("ไม่มีรายชื่อผู้ใช้ที่ถูกบล็อก", fontSize = 11.sp, color = Slate500)
                                } else {
                                    blockedUsers.forEach { bUser ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 4.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                AsyncImage(
                                                    model = bUser.avatar,
                                                    contentDescription = null,
                                                    contentScale = ContentScale.Crop,
                                                    modifier = Modifier
                                                        .size(28.dp)
                                                        .clip(CircleShape)
                                                )
                                                Text(bUser.displayName, fontSize = 12.sp, color = Color.White)
                                            }

                                            Button(
                                                onClick = { onUnblockUser(bUser.id) },
                                                colors = ButtonDefaults.buttonColors(containerColor = Slate800),
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                            ) {
                                                Text("ปลดบล็อก", fontSize = 10.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Switch Account / Logout Item
                    ProfileMenuItem(
                        icon = Icons.Default.ExitToApp,
                        title = "สลับบัญชีทดสอบ / ลงชื่อออก",
                        subtitle = "สลับไปบัญชี Admin หรือ Creator ท่านอื่น",
                        onClick = { isAuthOpen = true }
                    )
                }
            }
        }
    }

    // Dialogs
    EditProfileDialog(
        isOpen = isEditProfileOpen,
        currentUser = currentUser,
        onClose = { isEditProfileOpen = false },
        onSaveProfile = onSaveProfile
    )

    CoinWalletDialog(
        isOpen = isWalletOpen,
        currentUser = currentUser,
        onClose = { isWalletOpen = false },
        onTopUpCoins = onTopUpCoins
    )

    CreatorStudioDialog(
        isOpen = isCreatorStudioOpen,
        currentUser = currentUser,
        withdrawals = withdrawals,
        onClose = { isCreatorStudioOpen = false },
        onRequestWithdrawal = onRequestWithdrawal
    )

    if (onOpenAdminDashboard == null) {
        AdminDashboardDialog(
            isOpen = isAdminDashboardOpen,
            currentUser = currentUser,
            users = users,
            liveRooms = liveRooms,
            reports = reports,
            withdrawals = withdrawals,
            adminLogs = adminLogs,
            onClose = { isAdminDashboardOpen = false },
            onSuspendUser = onSuspendUser,
            onBanUser = onBanUser,
            onChangeRole = onChangeRole,
            onReviewReport = onReviewReport,
            onReviewWithdrawal = onReviewWithdrawal,
            onBroadcastNotification = onBroadcastNotification,
            onTerminateLive = onTerminateLive,
            onDeletePost = onDeletePost,
            onOpenUiBuilder = { onOpenUiBuilder?.invoke() },
            onOpenApkDownload = { onOpenApkDownload?.invoke() }
        )
    }

    PermissionDialog(
        isOpen = isPermissionsOpen,
        currentUser = currentUser,
        permissions = permissions,
        onClose = { isPermissionsOpen = false },
        onToggleLocationSharing = onToggleLocationSharing,
        onUpdatePermissions = onUpdatePermissions
    )

    AuthDialog(
        isOpen = isAuthOpen,
        currentUser = currentUser,
        users = users,
        onClose = { isAuthOpen = false },
        onSwitchUser = onSwitchUser,
        onRegisterUser = onRegisterUser
    )
}

@Composable
private fun StatItem(count: String, label: String, color: Color = Color.White) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(count, fontSize = 14.sp, fontWeight = FontWeight.Black, color = color)
        Text(label, fontSize = 10.sp, color = Slate400)
    }
}

@Composable
private fun ProfileMenuItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    badge: String? = null,
    badgeColor: Color = AmberGold,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        color = Slate900,
        border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Slate800),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = icon, contentDescription = null, tint = PinkPrimary, modifier = Modifier.size(18.dp))
                }
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(text = title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        if (badge != null) {
                            Surface(
                                color = badgeColor,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(badge, color = Slate950, fontSize = 8.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                            }
                        }
                    }
                    Text(text = subtitle, fontSize = 10.sp, color = Slate400, maxLines = 1)
                }
            }

            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Slate500, modifier = Modifier.size(18.dp))
        }
    }
}
