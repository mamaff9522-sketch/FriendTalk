package com.example.ui.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.model.CallSession
import com.example.model.CallStatus
import com.example.model.User
import com.example.service.SoundService
import com.example.ui.theme.*
import kotlinx.coroutines.delay

@Composable
fun CallDialog(
    callSession: CallSession?,
    currentUser: User,
    users: List<User>,
    onEndCall: () -> Unit
) {
    if (callSession == null) return

    val peerId = if (callSession.callerId == currentUser.id) callSession.receiverId else callSession.callerId
    val peer = users.find { it.id == peerId }

    var isMuted by remember { mutableStateOf(false) }
    var isVideoOff by remember { mutableStateOf(false) }
    var secondsElapsed by remember { mutableStateOf(0) }

    LaunchedEffect(callSession.status) {
        if (callSession.status == CallStatus.CONNECTED) {
            while (true) {
                delay(1000)
                secondsElapsed += 1
            }
        }
    }

    val minutes = secondsElapsed / 60
    val seconds = secondsElapsed % 60
    val durationText = String.format("%02d:%02d", minutes, seconds)

    Dialog(
        onDismissRequest = onEndCall,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Slate950)
                .padding(24.dp)
        ) {
            // Top Encrypted badge
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 20.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = Slate900,
                    shape = RoundedCornerShape(14.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = EmeraldGreen, modifier = Modifier.size(14.dp))
                        Text("การโทรปลอดภัย เข้ารหัสปลายทาง", fontSize = 11.sp, color = Slate300)
                    }
                }

                Surface(
                    color = PinkPrimary.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = if (callSession.type == "video") "วิดีโอคอล HD" else "โทรเสียง",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = PinkLight,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            // Center: Peer Avatar and info
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                AsyncImage(
                    model = peer?.avatar,
                    contentDescription = peer?.displayName,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(120.dp)
                        .clip(CircleShape)
                        .border(3.dp, PinkPrimary, CircleShape)
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = peer?.displayName ?: "ผู้ใช้",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White
                )

                Text(
                    text = "@${peer?.username ?: "user"}",
                    fontSize = 12.sp,
                    color = Slate400
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = if (callSession.status == CallStatus.RINGING) "กำลังโทรออก..." else durationText,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (callSession.status == CallStatus.RINGING) AmberLight else EmeraldGreen
                )
            }

            // Bottom Controls Bar
            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(bottom = 30.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Mic toggle
                IconButton(
                    onClick = {
                        SoundService.playPop()
                        isMuted = !isMuted
                    },
                    modifier = Modifier
                        .size(52.dp)
                        .background(if (isMuted) Color.Red.copy(alpha = 0.25f) else Slate800, CircleShape)
                ) {
                    Icon(
                        imageVector = if (isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                        contentDescription = "Mute",
                        tint = if (isMuted) Color.Red else Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }

                // Video toggle (if video call)
                if (callSession.type == "video") {
                    IconButton(
                        onClick = {
                            SoundService.playPop()
                            isVideoOff = !isVideoOff
                        },
                        modifier = Modifier
                            .size(52.dp)
                            .background(if (isVideoOff) Color.Red.copy(alpha = 0.25f) else Slate800, CircleShape)
                    ) {
                        Icon(
                            imageVector = if (isVideoOff) Icons.Default.VideocamOff else Icons.Default.Videocam,
                            contentDescription = "Camera",
                            tint = if (isVideoOff) Color.Red else Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                // End call button
                IconButton(
                    onClick = onEndCall,
                    modifier = Modifier
                        .size(60.dp)
                        .background(Color.Red, CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.CallEnd,
                        contentDescription = "วางสาย",
                        tint = Color.White,
                        modifier = Modifier.size(30.dp)
                    )
                }
            }
        }
    }
}
