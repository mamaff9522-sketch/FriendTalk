package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.AppUiConfig
import com.example.model.User
import com.example.model.UserRole
import com.example.model.parseHexColor
import com.example.ui.theme.*

@Composable
fun AppHeader(
    currentUser: User,
    unreadNotificationsCount: Int,
    onOpenCoins: () -> Unit,
    onOpenNotifications: () -> Unit,
    onOpenAuth: () -> Unit,
    onOpenPermissions: () -> Unit,
    onToggleLocationSharing: () -> Unit,
    modifier: Modifier = Modifier,
    uiConfig: AppUiConfig = AppUiConfig(),
    onRefreshConfig: () -> Unit = {},
    isRefreshing: Boolean = false,
    onOpenAdminDashboard: () -> Unit = {},
    onOpenUiBuilder: () -> Unit = {},
    onOpenApkDownload: () -> Unit = {}
) {
    val theme = uiConfig.theme
    val isDark = theme.themeMode != "light"
    val headerBgColor = parseHexColor(theme.surfaceColorHex, if (isDark) Slate900.copy(alpha = 0.95f) else Color.White)
    val primaryColor = parseHexColor(theme.primaryColorHex, PinkPrimary)
    val accentColor = parseHexColor(theme.accentColorHex, AmberGold)
    val textColor = parseHexColor(theme.textColorHex, if (isDark) Color.White else Color(0xFF0F172A))
    val textSecColor = parseHexColor(theme.textSecondaryColorHex, if (isDark) Slate400 else Color(0xFF64748B))

    val isAdmin = currentUser.role == UserRole.ADMIN || currentUser.role == UserRole.SUPERADMIN

    // Rotation animation for refresh button
    val infiniteTransition = rememberInfiniteTransition(label = "refresh_rotation")
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = headerBgColor,
        tonalElevation = 4.dp,
        border = androidx.compose.foundation.BorderStroke(1.dp, parseHexColor(theme.cardBorderColorHex, Slate800))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Brand & Location
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.clickable { onOpenAuth() }
            ) {
                if (uiConfig.appLogoUrl.isNotBlank()) {
                    AsyncImage(
                        model = uiConfig.appLogoUrl,
                        contentDescription = "Logo",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(primaryColor, RosePrimary, accentColor)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "F",
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            fontSize = 20.sp
                        )
                    }
                }

                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = uiConfig.appName,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 16.sp,
                            color = primaryColor
                        )
                        if (isAdmin) {
                            Surface(
                                color = accentColor.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(4.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, accentColor.copy(alpha = 0.6f)),
                                modifier = Modifier.clickable { onOpenAdminDashboard() }
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(2.dp),
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                ) {
                                    Icon(Icons.Default.Security, contentDescription = null, tint = accentColor, modifier = Modifier.size(9.dp))
                                    Text(
                                        text = "ADMIN",
                                        color = accentColor,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }

                            Surface(
                                color = primaryColor.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(4.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, primaryColor.copy(alpha = 0.6f)),
                                modifier = Modifier.clickable { onOpenUiBuilder() }
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(2.dp),
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                ) {
                                    Icon(Icons.Default.Build, contentDescription = null, tint = primaryColor, modifier = Modifier.size(9.dp))
                                    Text(
                                        text = "BUILDER",
                                        color = primaryColor,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(3.dp),
                        modifier = Modifier.clickable { onToggleLocationSharing() }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Place,
                            contentDescription = "Location",
                            tint = if (currentUser.location.isSharing) EmeraldGreen else textSecColor,
                            modifier = Modifier.size(11.dp)
                        )
                        Text(
                            text = if (currentUser.location.isSharing) currentUser.location.province else "ซ่อนตำแหน่ง",
                            fontSize = 10.sp,
                            color = textSecColor
                        )
                    }
                }
            }

            // Right Actions: Remote Config Refresh, Coin Pill, Permissions, Notification, User Avatar
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Refresh Remote UI Config Button
                IconButton(
                    onClick = onRefreshConfig,
                    modifier = Modifier.size(30.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Sync,
                        contentDescription = "Refresh UI Config",
                        tint = if (isRefreshing) accentColor else textSecColor,
                        modifier = Modifier
                            .size(16.dp)
                            .rotate(if (isRefreshing) rotationAngle else 0f)
                    )
                }

                // If Admin, quick APK download button
                if (isAdmin) {
                    IconButton(
                        onClick = onOpenApkDownload,
                        modifier = Modifier.size(30.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Android,
                            contentDescription = "Download APK",
                            tint = EmeraldGreen,
                            modifier = Modifier.size(17.dp)
                        )
                    }
                }

                // Coin Pill
                Surface(
                    onClick = onOpenCoins,
                    color = accentColor.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(20.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, accentColor.copy(alpha = 0.35f))
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(3.dp),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    ) {
                        Text(text = "🪙", fontSize = 11.sp)
                        Text(
                            text = currentUser.coins.toString(),
                            color = AmberLight,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Box(
                            modifier = Modifier
                                .size(13.dp)
                                .clip(CircleShape)
                                .background(accentColor),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "+",
                                color = Slate950,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }

                // Privacy / Permissions Settings
                IconButton(
                    onClick = onOpenPermissions,
                    modifier = Modifier.size(30.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = "Permissions",
                        tint = textSecColor,
                        modifier = Modifier.size(16.dp)
                    )
                }

                // Notification Bell with badge
                Box {
                    IconButton(
                        onClick = onOpenNotifications,
                        modifier = Modifier.size(30.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = "Notifications",
                            tint = textSecColor,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    if (unreadNotificationsCount > 0) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .size(14.dp)
                                .clip(CircleShape)
                                .background(RosePrimary),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = unreadNotificationsCount.toString(),
                                color = Color.White,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Switch User Avatar
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .border(1.5.dp, primaryColor, CircleShape)
                        .clickable { onOpenAuth() }
                ) {
                    AsyncImage(
                        model = currentUser.avatar,
                        contentDescription = currentUser.displayName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
    }
}
