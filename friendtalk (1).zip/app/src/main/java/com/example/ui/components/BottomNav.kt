package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppUiConfig
import com.example.model.BottomNavTabConfig
import com.example.model.parseHexColor
import com.example.ui.theme.*

@Composable
fun BottomNavBar(
    activeTab: String,
    onTabSelected: (String) -> Unit,
    totalUnreadMessages: Int,
    activeLiveCount: Int,
    modifier: Modifier = Modifier,
    currentUserAge: Int = 18,
    uiConfig: AppUiConfig = AppUiConfig()
) {
    val canAccessCompanion = currentUserAge >= 18
    val theme = uiConfig.theme
    val isDark = theme.themeMode != "light"

    val navBgColor = parseHexColor(theme.surfaceColorHex, if (isDark) Slate950.copy(alpha = 0.95f) else Color.White)
    val primaryColor = parseHexColor(theme.primaryColorHex, PinkPrimary)
    val accentColor = parseHexColor(theme.accentColorHex, AmberGold)
    val inactiveColor = parseHexColor(theme.textSecondaryColorHex, if (isDark) Slate400 else Color(0xFF64748B))

    // Filter and sort tabs based on Remote UI Config
    val enabledTabs = uiConfig.navigationTabs
        .filter { tab ->
            tab.isEnabled && (tab.tabId != "companion" || canAccessCompanion)
        }
        .sortedBy { it.order }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding(),
        color = navBgColor,
        tonalElevation = 8.dp,
        border = androidx.compose.foundation.BorderStroke(1.dp, parseHexColor(theme.cardBorderColorHex, Slate800))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            enabledTabs.forEach { tab ->
                val isSelected = activeTab == tab.tabId

                when (tab.tabId) {
                    "live" -> {
                        // Special Prominent Live Center Button
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .offset(y = (-6).dp)
                                .clickable { onTabSelected("live") }
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.linearGradient(
                                            if (isSelected) listOf(primaryColor, RosePrimary, accentColor)
                                            else listOf(RosePrimary, primaryColor)
                                        )
                                    )
                                    .border(
                                        2.dp,
                                        if (isSelected) accentColor else Color.White.copy(alpha = 0.4f),
                                        CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Radio,
                                    contentDescription = tab.label,
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                                if (activeLiveCount > 0) {
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .size(16.dp)
                                            .clip(CircleShape)
                                            .background(RosePrimary),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = activeLiveCount.toString(),
                                            color = Color.White,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                            Text(
                                text = tab.label,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) primaryColor else inactiveColor,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                    }

                    "chat" -> {
                        // Chat Button with Unread Badge
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { onTabSelected("chat") }
                                .padding(horizontal = 6.dp, vertical = 6.dp)
                        ) {
                            Box {
                                Icon(
                                    imageVector = Icons.Default.ChatBubble,
                                    contentDescription = tab.label,
                                    tint = if (isSelected) primaryColor else inactiveColor,
                                    modifier = Modifier.size(22.dp)
                                )
                                if (totalUnreadMessages > 0) {
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .offset(x = 6.dp, y = (-4).dp)
                                            .size(16.dp)
                                            .clip(CircleShape)
                                            .background(primaryColor),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = totalUnreadMessages.toString(),
                                            color = Color.White,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                            Text(
                                text = tab.label,
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) primaryColor else inactiveColor
                            )
                        }
                    }

                    else -> {
                        // Standard Tab Item (Home, Discover, Companion, Movie, Profile)
                        val iconVector = when (tab.iconName) {
                            "Explore" -> Icons.Default.Explore
                            "Radio" -> Icons.Default.Radio
                            "Movie" -> Icons.Default.Movie
                            "ChatBubble" -> Icons.Default.ChatBubble
                            "VolunteerActivism" -> Icons.Default.VolunteerActivism
                            "Person" -> Icons.Default.Person
                            else -> when (tab.tabId) {
                                "movie" -> Icons.Default.Movie
                                "discover" -> Icons.Default.Explore
                                "companion" -> Icons.Default.VolunteerActivism
                                "profile" -> Icons.Default.Person
                                else -> Icons.Default.Home
                            }
                        }

                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { onTabSelected(tab.tabId) }
                                .padding(horizontal = 6.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = iconVector,
                                contentDescription = tab.label,
                                tint = if (isSelected) primaryColor else inactiveColor,
                                modifier = Modifier.size(22.dp)
                            )
                            Text(
                                text = tab.label,
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) primaryColor else inactiveColor
                            )
                        }
                    }
                }
            }
        }
    }
}
