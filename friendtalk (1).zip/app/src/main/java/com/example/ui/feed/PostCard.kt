package com.example.ui.feed

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.Post
import com.example.model.User
import com.example.model.UserRole
import com.example.ui.theme.*

@Composable
fun PostCard(
    post: Post,
    author: User?,
    currentUser: User,
    isFollowing: Boolean,
    onToggleFollow: () -> Unit,
    onLikePost: () -> Unit,
    onOpenComments: () -> Unit,
    onOpenReport: () -> Unit,
    onDeletePost: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showMenu by remember { mutableStateOf(false) }
    var isShared by remember { mutableStateOf(false) }

    val isLiked = post.likes.contains(currentUser.id)
    val isOwner = post.authorId == currentUser.id ||
            currentUser.role == UserRole.ADMIN ||
            currentUser.role == UserRole.SUPERADMIN

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = Slate900.copy(alpha = 0.8f),
        border = androidx.compose.foundation.BorderStroke(0.5.dp, Slate800)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Post Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box {
                        AsyncImage(
                            model = author?.avatar,
                            contentDescription = author?.displayName,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                        )
                        if (author?.isOnline == true) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(EmeraldGreen)
                                    .border(1.5.dp, Slate900, CircleShape)
                            )
                        }
                    }

                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = author?.displayName ?: "เพื่อน FriendTalk",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            if (author?.isVerified == true) {
                                Text(
                                    text = "✓",
                                    color = PinkPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            if (author?.role == UserRole.SUPERADMIN) {
                                Surface(
                                    color = AmberGold.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = "แอดมิน",
                                        color = AmberGold,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                            }
                        }

                        Text(
                            text = "@${author?.username ?: "user"} • ${post.createdAt}",
                            fontSize = 10.sp,
                            color = Slate400
                        )
                    }
                }

                // Follow / Menu actions
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (author != null && author.id != currentUser.id) {
                        Surface(
                            onClick = onToggleFollow,
                            shape = RoundedCornerShape(14.dp),
                            color = if (isFollowing) Slate800 else PinkPrimary.copy(alpha = 0.15f),
                            border = if (!isFollowing) androidx.compose.foundation.BorderStroke(1.dp, PinkPrimary.copy(alpha = 0.4f)) else null
                        ) {
                            Text(
                                text = if (isFollowing) "กำลังติดตาม" else "+ ติดตาม",
                                color = if (isFollowing) Slate300 else PinkPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Box {
                        IconButton(onClick = { showMenu = !showMenu }) {
                            Icon(
                                imageVector = Icons.Default.MoreVert,
                                contentDescription = "Menu",
                                tint = Slate400,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        DropdownMenu(
                            expanded = showMenu,
                            onDismissRequest = { showMenu = false },
                            modifier = Modifier.background(Slate950)
                        ) {
                            DropdownMenuItem(
                                text = { Text("รายงานโพสต์", color = RosePrimary, fontSize = 12.sp) },
                                onClick = {
                                    showMenu = false
                                    onOpenReport()
                                },
                                leadingIcon = {
                                    Icon(Icons.Default.Flag, contentDescription = null, tint = RosePrimary, modifier = Modifier.size(16.dp))
                                }
                            )
                            if (isOwner) {
                                DropdownMenuItem(
                                    text = { Text("ลบโพสต์", color = Color.Red, fontSize = 12.sp) },
                                    onClick = {
                                        showMenu = false
                                        onDeletePost()
                                    },
                                    leadingIcon = {
                                        Icon(Icons.Default.Delete, contentDescription = null, tint = Color.Red, modifier = Modifier.size(16.dp))
                                    }
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Post Content Text
            Text(
                text = post.content,
                fontSize = 13.sp,
                color = Slate100,
                lineHeight = 18.sp
            )

            // Post Media (Image)
            if (post.mediaUrls.isNotEmpty()) {
                Spacer(modifier = Modifier.height(10.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 240.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .border(1.dp, Slate800, RoundedCornerShape(16.dp))
                ) {
                    AsyncImage(
                        model = post.mediaUrls.first(),
                        contentDescription = "Post Image",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            // Tags
            if (post.tags.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    post.tags.forEach { tag ->
                        Text(
                            text = "#$tag",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = PinkLight
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action Buttons Bar
            HorizontalDivider(color = Slate800.copy(alpha = 0.6f))
            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Like Button
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier
                        .clickable { onLikePost() }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = if (isLiked) Icons.Default.Favorite else Icons.Outlined.FavoriteBorder,
                        contentDescription = "Like",
                        tint = if (isLiked) RosePrimary else Slate400,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = post.likes.size.toString(),
                        fontSize = 12.sp,
                        color = if (isLiked) RosePrimary else Slate400,
                        fontWeight = if (isLiked) FontWeight.Bold else FontWeight.Normal
                    )
                }

                // Comment Button
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier
                        .clickable { onOpenComments() }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.ChatBubbleOutline,
                        contentDescription = "Comments",
                        tint = Slate400,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = if (post.commentsCount > 0) post.commentsCount.toString() else "ความคิดเห็น",
                        fontSize = 12.sp,
                        color = Slate400
                    )
                }

                // Share Button
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier
                        .clickable { isShared = true }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Share,
                        contentDescription = "Share",
                        tint = if (isShared) EmeraldGreen else Slate400,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = if (isShared) "แชร์แล้ว!" else "แชร์",
                        fontSize = 12.sp,
                        color = if (isShared) EmeraldGreen else Slate400
                    )
                }
            }
        }
    }
}
