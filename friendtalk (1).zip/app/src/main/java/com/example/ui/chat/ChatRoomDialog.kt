package com.example.ui.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.model.*
import com.example.service.SoundService
import com.example.ui.components.ReportDialog
import com.example.ui.theme.*

@Composable
fun ChatRoomDialog(
    isOpen: Boolean,
    conversationId: String?,
    currentUser: User,
    users: List<User>,
    conversations: List<Conversation>,
    messages: List<ChatMessage>,
    onClose: () -> Unit,
    onSendMessage: (text: String, type: MessageType, mediaUrl: String?, disappearingSeconds: Int?, giftInfo: GiftInfo?) -> Unit,
    onSetDisappearingTimer: (seconds: Int) -> Unit,
    onStartCall: (targetUserId: String, type: String) -> Unit,
    onBlockUser: (String) -> Unit,
    onCreateReport: (targetType: String, targetId: String, reason: String, details: String?) -> Unit
) {
    if (!isOpen || conversationId == null) return
    val conv = conversations.find { it.id == conversationId } ?: return

    val isGroup = conv.type == "group"
    val otherParticipantId = if (!isGroup) conv.participantIds.find { it != currentUser.id } else null
    val otherUser = if (otherParticipantId != null) users.find { it.id == otherParticipantId } else null

    val convMessages = messages.filter { it.conversationId == conversationId }

    var textInput by remember { mutableStateOf("") }
    var showStickers by remember { mutableStateOf(false) }
    var showTimerMenu by remember { mutableStateOf(false) }
    var showMoreMenu by remember { mutableStateOf(false) }
    var isReportOpen by remember { mutableStateOf(false) }

    val stickers = remember {
        listOf(
            "🐱 แง้วว คิดถึงจัง",
            "❤️ รักนะ",
            "✨ สู้ๆ นะครับ/ค่ะ",
            "☕ ไปคาเฟ่กัน",
            "🎉 เย้ๆ ยินดีด้วย",
            "💤 ฝันดีนะ",
            "🙏 ขอบคุณมากๆ เลย",
            "🔥 ไฟลุก ลุยเลย!"
        )
    }

    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Slate950
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Top Chat Header Bar
                Surface(
                    color = Slate900,
                    modifier = Modifier.fillMaxWidth(),
                    shadowElevation = 4.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 36.dp, bottom = 10.dp, start = 12.dp, end = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            IconButton(onClick = onClose) {
                                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                            }

                            Box {
                                AsyncImage(
                                    model = if (isGroup) conv.avatar else otherUser?.avatar,
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .border(1.dp, PinkPrimary, CircleShape)
                                )
                                if (!isGroup && otherUser?.isOnline == true) {
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.BottomEnd)
                                            .size(10.dp)
                                            .clip(CircleShape)
                                            .background(EmeraldGreen)
                                            .border(1.dp, Slate900, CircleShape)
                                    )
                                }
                            }

                            Column {
                                Text(
                                    text = if (isGroup) (conv.name ?: "กลุ่ม") else (otherUser?.displayName ?: "แชต"),
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    maxLines = 1
                                )
                                Text(
                                    text = if (isGroup) "${conv.participantIds.size} สมาชิก"
                                    else if (otherUser?.isOnline == true) "ออนไลน์ขณะนี้" else (otherUser?.lastActive ?: "ออฟไลน์"),
                                    fontSize = 10.sp,
                                    color = if (otherUser?.isOnline == true) EmeraldGreen else Slate400
                                )
                            }
                        }

                        // Right Icons (Timer, Audio Call, Video Call, More)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // Disappearing Message Timer Button
                            IconButton(onClick = { showTimerMenu = !showTimerMenu }) {
                                Icon(
                                    imageVector = Icons.Outlined.Timer,
                                    contentDescription = "Timer",
                                    tint = if (conv.disappearingTimerDefault > 0) AmberGold else Slate400,
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            if (!isGroup && otherUser != null) {
                                IconButton(onClick = { onStartCall(otherUser.id, "audio") }) {
                                    Icon(Icons.Default.Call, contentDescription = "Call", tint = Slate400, modifier = Modifier.size(20.dp))
                                }
                                IconButton(onClick = { onStartCall(otherUser.id, "video") }) {
                                    Icon(Icons.Default.Videocam, contentDescription = "Video", tint = Slate400, modifier = Modifier.size(22.dp))
                                }
                            }

                            Box {
                                IconButton(onClick = { showMoreMenu = !showMoreMenu }) {
                                    Icon(Icons.Default.MoreVert, contentDescription = "More", tint = Slate400, modifier = Modifier.size(20.dp))
                                }

                                DropdownMenu(
                                    expanded = showMoreMenu,
                                    onDismissRequest = { showMoreMenu = false },
                                    modifier = Modifier.background(Slate900)
                                ) {
                                    if (!isGroup && otherUser != null) {
                                        DropdownMenuItem(
                                            text = { Text("รายงานผู้ใช้", color = RosePrimary, fontSize = 12.sp) },
                                            onClick = {
                                                showMoreMenu = false
                                                isReportOpen = true
                                            },
                                            leadingIcon = { Icon(Icons.Default.Flag, contentDescription = null, tint = RosePrimary) }
                                        )
                                        DropdownMenuItem(
                                            text = { Text("บล็อกผู้ใช้", color = Color.Red, fontSize = 12.sp) },
                                            onClick = {
                                                showMoreMenu = false
                                                onBlockUser(otherUser.id)
                                                onClose()
                                            },
                                            leadingIcon = { Icon(Icons.Default.Block, contentDescription = null, tint = Color.Red) }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Disappearing message notification banner
                if (conv.disappearingTimerDefault > 0) {
                    Surface(
                        color = AmberGold.copy(alpha = 0.15f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "⏱️ ข้อความอ่านแล้วหายเปิดใช้งานอยู่ (${conv.disappearingTimerDefault} วินาทีหลังส่ง)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = AmberLight,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }

                // Timer menu dropdown
                if (showTimerMenu) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(16.dp),
                        color = Slate900,
                        border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("ข้อความอ่านแล้วหาย:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Slate400)
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf(Pair(0, "ปิด"), Pair(5, "5 วิ"), Pair(30, "30 วิ"), Pair(60, "1 นาที")).forEach { item ->
                                    val isSelected = conv.disappearingTimerDefault == item.first
                                    Surface(
                                        onClick = {
                                            onSetDisappearingTimer(item.first)
                                            showTimerMenu = false
                                        },
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (isSelected) PinkPrimary else Slate950
                                    ) {
                                        Text(
                                            text = item.second,
                                            fontSize = 11.sp,
                                            color = if (isSelected) Color.White else Slate300,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Messages Stream List
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(convMessages) { msg ->
                        val isMine = msg.senderId == currentUser.id
                        val sender = users.find { it.id == msg.senderId }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = if (isMine) Arrangement.End else Arrangement.Start,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            if (!isMine) {
                                AsyncImage(
                                    model = sender?.avatar,
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .border(1.dp, Slate700, CircleShape)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                            }

                            Surface(
                                shape = RoundedCornerShape(
                                    topStart = 16.dp,
                                    topEnd = 16.dp,
                                    bottomStart = if (isMine) 16.dp else 4.dp,
                                    bottomEnd = if (isMine) 4.dp else 16.dp
                                ),
                                color = if (isMine) PinkPrimary else Slate900,
                                border = if (!isMine) androidx.compose.foundation.BorderStroke(1.dp, Slate800) else null,
                                modifier = Modifier.widthIn(max = 260.dp)
                            ) {
                                Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                                    if (msg.type == MessageType.STICKER) {
                                        Surface(
                                            color = Color.White.copy(alpha = 0.15f),
                                            shape = RoundedCornerShape(10.dp)
                                        ) {
                                            Text(
                                                text = msg.text,
                                                fontSize = 14.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                            )
                                        }
                                    } else if (msg.type == MessageType.GIFT) {
                                        Surface(
                                            color = AmberGold.copy(alpha = 0.2f),
                                            shape = RoundedCornerShape(10.dp),
                                            border = androidx.compose.foundation.BorderStroke(1.dp, AmberGold)
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(8.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Text(msg.giftInfo?.icon ?: "🎁", fontSize = 24.sp)
                                                Column {
                                                    Text(msg.giftInfo?.name ?: "ของขวัญ", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = AmberLight)
                                                    Text("🪙 ${msg.giftInfo?.coins} Coins", fontSize = 10.sp, color = AmberGold)
                                                }
                                            }
                                        }
                                    } else if (msg.type == MessageType.AUDIO) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Icon(Icons.Default.VolumeUp, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                            Text(msg.text, fontSize = 12.sp, color = Color.White)
                                        }
                                    } else {
                                        Text(
                                            text = msg.text,
                                            fontSize = 13.sp,
                                            color = Color.White,
                                            lineHeight = 17.sp
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(2.dp))
                                    Row(
                                        modifier = Modifier.align(Alignment.End),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                                    ) {
                                        if (msg.disappearingSeconds != null) {
                                            Text("⏱️ ${msg.disappearingSeconds}s", fontSize = 9.sp, color = if (isMine) Color.White.copy(alpha = 0.8f) else Slate400)
                                        }
                                        Text(msg.createdAt, fontSize = 9.sp, color = if (isMine) Color.White.copy(alpha = 0.7f) else Slate500)
                                        if (isMine) {
                                            Icon(Icons.Default.DoneAll, contentDescription = null, tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.size(12.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Stickers popup bottom sheet
                if (showStickers) {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = Slate900,
                        border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
                    ) {
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(4),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            items(stickers) { stk ->
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            onSendMessage(stk, MessageType.STICKER, null, conv.disappearingTimerDefault.takeIf { it > 0 }, null)
                                            showStickers = false
                                        },
                                    shape = RoundedCornerShape(10.dp),
                                    color = Slate950,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
                                ) {
                                    Text(
                                        text = stk,
                                        fontSize = 11.sp,
                                        color = Color.White,
                                        modifier = Modifier.padding(8.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // Bottom Message Input Bar
                Surface(
                    color = Slate900,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Stickers button
                        IconButton(onClick = { showStickers = !showStickers }, modifier = Modifier.size(36.dp)) {
                            Icon(Icons.Default.SentimentSatisfiedAlt, contentDescription = "Sticker", tint = Slate400, modifier = Modifier.size(20.dp))
                        }

                        // Voice message simulation
                        IconButton(
                            onClick = {
                                onSendMessage("ข้อความเสียง (0:04)", MessageType.AUDIO, null, conv.disappearingTimerDefault.takeIf { it > 0 }, null)
                            },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.Default.Mic, contentDescription = "Voice", tint = Slate400, modifier = Modifier.size(20.dp))
                        }

                        // Text Field
                        OutlinedTextField(
                            value = textInput,
                            onValueChange = { textInput = it },
                            placeholder = { Text("พิมพ์ข้อความ...", fontSize = 12.sp, color = Slate400) },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            shape = RoundedCornerShape(20.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = PinkPrimary,
                                unfocusedBorderColor = Slate800,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )

                        // Send button
                        IconButton(
                            onClick = {
                                if (textInput.isNotBlank()) {
                                    onSendMessage(textInput.trim(), MessageType.TEXT, null, conv.disappearingTimerDefault.takeIf { it > 0 }, null)
                                    textInput = ""
                                }
                            },
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(PinkPrimary)
                        ) {
                            Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
    }

    if (otherUser != null) {
        ReportDialog(
            isOpen = isReportOpen,
            targetType = "user",
            targetId = otherUser.id,
            targetName = otherUser.displayName,
            onClose = { isReportOpen = false },
            onSubmitReport = { reason, details ->
                onCreateReport("user", otherUser.id, reason, details)
                isReportOpen = false
            }
        )
    }
}
