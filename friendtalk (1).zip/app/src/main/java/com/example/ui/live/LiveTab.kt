package com.example.ui.live

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.Gift
import com.example.model.LiveRoom
import com.example.model.User
import com.example.ui.theme.*

@Composable
fun LiveTab(
    currentUser: User,
    users: List<User>,
    liveRooms: List<LiveRoom>,
    followingIds: Set<String>,
    currentLiveRoomId: String?,
    onOpenLiveRoom: (String) -> Unit,
    onCloseLiveRoom: () -> Unit,
    onStartLive: (title: String, category: String, isPk: Boolean) -> String,
    onEndLive: (String) -> Unit,
    onSendHeart: (String) -> Unit,
    onSendGift: (String, Gift) -> Boolean,
    onTogglePk: (String) -> Unit,
    onMuteViewer: (String, String) -> Unit,
    onKickViewer: (String, String) -> Unit,
    onToggleFollow: (String) -> Unit,
    onOpenCoins: () -> Unit,
    onCreateReport: (targetType: String, targetId: String, reason: String, details: String?) -> Unit,
    modifier: Modifier = Modifier
) {
    var isGoLiveOpen by remember { mutableStateOf(false) }
    var selectedCategory by remember { mutableStateOf("all") }

    val categories = remember {
        listOf(
            Pair("all", "ทั้งหมด"),
            Pair("pk", "⚡ PK Battle"),
            Pair("music", "🎤 ดนตรีสด"),
            Pair("game", "🎮 เกมเมอร์"),
            Pair("chat", "☕ พูดคุย")
        )
    }

    val filteredRooms = remember(liveRooms, selectedCategory) {
        liveRooms.filter { r ->
            if (!r.isLive) return@filter false
            when (selectedCategory) {
                "pk" -> r.isPkMode
                "music" -> r.category.contains("ดนตรี", ignoreCase = true)
                "game" -> r.category.contains("เกม", ignoreCase = true)
                "chat" -> r.category.contains("พูดคุย", ignoreCase = true)
                else -> true
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(14.dp)
    ) {
        // Hero Go Live Banner
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            color = Color.Transparent,
            shadowElevation = 6.dp
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Brush.linearGradient(listOf(PinkPrimary, RosePrimary, AmberGold)))
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Surface(
                            color = Color.Black.copy(alpha = 0.3f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = "FriendTalk Live 🔴",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "เปล่งประกายในแบบคุณ",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                        Text(
                            text = "เปิดห้องไลฟ์สด ร้องเพลง หรือท้าดวล PK ได้ทันที",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = { isGoLiveOpen = true },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.Radio, contentDescription = null, tint = RosePrimary, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("เริ่มไลฟ์สดของคุณ", color = Slate950, fontWeight = FontWeight.Black, fontSize = 12.sp)
                        }
                    }

                    Text("🎙️", fontSize = 54.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Category Filter Chips
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(categories) { cat ->
                val isSelected = selectedCategory == cat.first
                Surface(
                    onClick = { selectedCategory = cat.first },
                    shape = RoundedCornerShape(14.dp),
                    color = if (isSelected) PinkPrimary else Slate900,
                    border = if (!isSelected) androidx.compose.foundation.BorderStroke(1.dp, Slate800) else null
                ) {
                    Text(
                        text = cat.second,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) Color.White else Slate400,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Live Rooms Grid
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 60.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(filteredRooms) { room ->
                val host = users.find { it.id == room.hostId }
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .clickable { onOpenLiveRoom(room.id) },
                    shape = RoundedCornerShape(18.dp),
                    color = Slate900,
                    border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        AsyncImage(
                            model = room.coverUrl,
                            contentDescription = room.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )

                        // Dark gradient overlay
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        listOf(
                                            Color.Black.copy(alpha = 0.6f),
                                            Color.Transparent,
                                            Slate950.copy(alpha = 0.9f)
                                        )
                                    )
                                )
                        )

                        // Top Badges
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = RosePrimary,
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(5.dp)
                                            .clip(CircleShape)
                                            .background(Color.White)
                                    )
                                    Text("LIVE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                }
                            }

                            Surface(
                                color = Color.Black.copy(alpha = 0.6f),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                                ) {
                                    Icon(Icons.Default.Group, contentDescription = null, tint = Color.White, modifier = Modifier.size(11.dp))
                                    Text("${room.viewersCount}", fontSize = 10.sp, color = Color.White)
                                }
                            }
                        }

                        // PK Badge if active
                        if (room.isPkMode) {
                            Surface(
                                modifier = Modifier
                                    .align(Alignment.TopStart)
                                    .padding(top = 34.dp, start = 8.dp),
                                color = AmberGold,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = "⚡ PK BATTLE",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Slate950,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                )
                            }
                        }

                        // Bottom Title & Host Info
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .fillMaxWidth()
                                .padding(8.dp)
                        ) {
                            Text(
                                text = room.title,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                maxLines = 1
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                AsyncImage(
                                    model = host?.avatar,
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(20.dp)
                                        .clip(CircleShape)
                                        .border(1.dp, PinkPrimary, CircleShape)
                                )
                                Text(
                                    text = host?.displayName ?: "Host",
                                    fontSize = 10.sp,
                                    color = Slate300,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Go Live Modal
    GoLiveDialog(
        isOpen = isGoLiveOpen,
        currentUser = currentUser,
        onClose = { isGoLiveOpen = false },
        onStartLive = { title, category, isPk ->
            val id = onStartLive(title, category, isPk)
            onOpenLiveRoom(id)
        }
    )

    // Active Live Room Dialog
    LiveRoomDialog(
        isOpen = currentLiveRoomId != null,
        roomId = currentLiveRoomId,
        currentUser = currentUser,
        users = users,
        liveRooms = liveRooms,
        followingIds = followingIds,
        onClose = onCloseLiveRoom,
        onToggleFollow = onToggleFollow,
        onSendHeart = onSendHeart,
        onSendGift = onSendGift,
        onTogglePk = onTogglePk,
        onMuteViewer = onMuteViewer,
        onKickViewer = onKickViewer,
        onEndLive = onEndLive,
        onOpenCoins = onOpenCoins,
        onCreateReport = onCreateReport
    )
}
