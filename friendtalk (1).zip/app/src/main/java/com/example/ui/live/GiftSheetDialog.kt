package com.example.ui.live

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.MockData
import com.example.model.Gift
import com.example.model.User
import com.example.service.SoundService
import com.example.ui.theme.*

@Composable
fun GiftSheetDialog(
    isOpen: Boolean,
    currentUser: User,
    onClose: () -> Unit,
    onSelectGift: (Gift) -> Unit,
    onOpenCoins: () -> Unit
) {
    if (!isOpen) return

    val gifts = remember { MockData.giftsCatalog }
    var selectedGiftId by remember { mutableStateOf(gifts.first().id) }
    val selectedGift = gifts.find { it.id == selectedGiftId } ?: gifts.first()

    Dialog(onDismissRequest = onClose) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(28.dp),
            color = Slate900,
            border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                // Header with user coins
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ส่งของขวัญ (Gifts)",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            onClick = {
                                onClose()
                                onOpenCoins()
                            },
                            color = AmberGold.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(14.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, AmberGold.copy(alpha = 0.4f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text("🪙", fontSize = 11.sp)
                                Text(
                                    text = currentUser.coins.toString(),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = AmberLight
                                )
                                Text("+", fontSize = 11.sp, fontWeight = FontWeight.Black, color = AmberGold)
                            }
                        }

                        IconButton(onClick = onClose) {
                            Icon(Icons.Default.Close, contentDescription = "ปิด", tint = Slate400)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Gifts 4-column Grid
                LazyVerticalGrid(
                    columns = GridCells.Fixed(4),
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(gifts) { gift ->
                        val isSelected = gift.id == selectedGiftId
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    SoundService.playPop()
                                    selectedGiftId = gift.id
                                },
                            shape = RoundedCornerShape(16.dp),
                            color = if (isSelected) PinkPrimary.copy(alpha = 0.2f) else Slate950,
                            border = androidx.compose.foundation.BorderStroke(
                                if (isSelected) 1.5.dp else 1.dp,
                                if (isSelected) PinkPrimary else Slate800
                            )
                        ) {
                            Column(
                                modifier = Modifier.padding(8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(text = gift.icon, fontSize = 28.sp)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = gift.name,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    maxLines = 1
                                )
                                Text(
                                    text = "🪙 ${gift.coins}",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = AmberGold
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Footer with Send button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "เลือก: ${selectedGift.name}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "🪙 ${selectedGift.coins} Coins",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = AmberGold
                        )
                    }

                    val canSend = currentUser.coins >= selectedGift.coins
                    Button(
                        onClick = {
                            if (canSend) {
                                onSelectGift(selectedGift)
                            } else {
                                onClose()
                                onOpenCoins()
                            }
                        },
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (canSend) PinkPrimary else Slate800
                        )
                    ) {
                        Text(
                            text = if (canSend) "ส่งของขวัญ" else "เหรียญไม่พอ (เติม)",
                            fontWeight = FontWeight.Bold,
                            color = if (canSend) Color.White else AmberLight,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }
}
