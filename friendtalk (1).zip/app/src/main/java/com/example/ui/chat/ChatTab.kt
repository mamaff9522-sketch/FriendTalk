package com.example.ui.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.*
import com.example.ui.theme.*

@Composable
fun ChatTab(
    currentUser: User,
    users: List<User>,
    conversations: List<Conversation>,
    messages: List<ChatMessage>,
    activeCall: CallSession?,
    activeChatRoomId: String?,
    onOpenChatRoom: (String) -> Unit,
    onCloseChatRoom: () -> Unit,
    onSendMessage: (text: String, type: MessageType, mediaUrl: String?, disappearingSeconds: Int?, giftInfo: GiftInfo?) -> Unit,
    onSetDisappearingTimer: (seconds: Int) -> Unit,
    onCreateGroup: (name: String, participantIds: List<String>) -> Unit,
    onStartCall: (targetUserId: String, type: String) -> Unit,
    onEndCall: () -> Unit,
    onBlockUser: (String) -> Unit,
    onCreateReport: (targetType: String, targetId: String, reason: String, details: String?) -> Unit,
    modifier: Modifier = Modifier
) {
    var filterType by remember { mutableStateOf("all") } // "all" or "group"
    var searchQuery by remember { mutableStateOf("") }
    var isCreateGroupOpen by remember { mutableStateOf(false) }

    val filteredConversations = remember(conversations, filterType, searchQuery, currentUser.id) {
        conversations.filter { c ->
            if (filterType == "group" && c.type != "group") return@filter false
            if (searchQuery.isNotBlank()) {
                if (c.type == "group") {
                    c.name?.contains(searchQuery, ignoreCase = true) == true
                } else {
                    val otherId = c.participantIds.find { it != currentUser.id }
                    val other = users.find { it.id == otherId }
                    other?.displayName?.contains(searchQuery, ignoreCase = true) == true
                }
            } else true
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(14.dp)
    ) {
        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.Default.ChatBubble, contentDescription = null, tint = PinkPrimary, modifier = Modifier.size(20.dp))
                    Text(
                        text = "ข้อความและการสนทนา",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
                Text(
                    text = "แชตส่วนตัว กลุ่ม โทรเสียง และวิดีโอคอล",
                    fontSize = 10.sp,
                    color = Slate400
                )
            }

            Button(
                onClick = { isCreateGroupOpen = true },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary.copy(alpha = 0.2f)),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, tint = PinkLight, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("สร้างกลุ่ม", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = PinkLight)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Search bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("ค้นหาบทสนทนา หรือชื่อเพื่อน...", fontSize = 11.sp, color = Slate400) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Slate400, modifier = Modifier.size(18.dp)) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = PinkPrimary,
                unfocusedBorderColor = Slate800,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            )
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Filter tabs
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = filterType == "all",
                onClick = { filterType = "all" },
                label = { Text("แชตทั้งหมด", fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = PinkPrimary,
                    selectedLabelColor = Color.White
                )
            )
            FilterChip(
                selected = filterType == "group",
                onClick = { filterType = "group" },
                label = {
                    Text(
                        "กลุ่ม (${conversations.count { it.type == "group" }})",
                        fontSize = 11.sp
                    )
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = PinkPrimary,
                    selectedLabelColor = Color.White
                )
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Conversations List
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 60.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(filteredConversations) { conv ->
                val isGroup = conv.type == "group"
                val otherId = if (!isGroup) conv.participantIds.find { it != currentUser.id } else null
                val otherUser = if (otherId != null) users.find { it.id == otherId } else null

                val name = if (isGroup) (conv.name ?: "กลุ่ม") else (otherUser?.displayName ?: "เพื่อน")
                val avatar = if (isGroup) conv.avatar else otherUser?.avatar
                val unread = conv.unreadCounts[currentUser.id] ?: 0

                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onOpenChatRoom(conv.id) },
                    shape = RoundedCornerShape(18.dp),
                    color = Slate900,
                    border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Box {
                                AsyncImage(
                                    model = avatar,
                                    contentDescription = name,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(CircleShape)
                                        .border(1.dp, PinkPrimary, CircleShape)
                                )
                                if (!isGroup && otherUser?.isOnline == true) {
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.BottomEnd)
                                            .size(10.dp)
                                            .clip(CircleShape)
                                            .background(EmeraldGreen)
                                            .border(1.5.dp, Slate900, CircleShape)
                                    )
                                }
                            }

                            Column {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = name,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                    if (isGroup) {
                                        Surface(
                                            color = Slate800,
                                            shape = RoundedCornerShape(4.dp)
                                        ) {
                                            Text(
                                                text = "กลุ่ม",
                                                fontSize = 9.sp,
                                                color = Slate300,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                            )
                                        }
                                    }
                                }
                                Text(
                                    text = conv.lastMessage?.text ?: "เริ่มการสนทนาใหม่",
                                    fontSize = 11.sp,
                                    color = Slate400,
                                    maxLines = 1
                                )
                            }
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = conv.updatedAt,
                                fontSize = 10.sp,
                                color = Slate500
                            )
                            if (unread > 0) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Box(
                                    modifier = Modifier
                                        .size(18.dp)
                                        .clip(CircleShape)
                                        .background(PinkPrimary),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = unread.toString(),
                                        color = Color.White,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Create Group Dialog
    CreateGroupDialog(
        isOpen = isCreateGroupOpen,
        currentUser = currentUser,
        users = users,
        onClose = { isCreateGroupOpen = false },
        onCreateGroup = onCreateGroup
    )

    // Active Chat Room Dialog
    ChatRoomDialog(
        isOpen = activeChatRoomId != null,
        conversationId = activeChatRoomId,
        currentUser = currentUser,
        users = users,
        conversations = conversations,
        messages = messages,
        onClose = onCloseChatRoom,
        onSendMessage = onSendMessage,
        onSetDisappearingTimer = onSetDisappearingTimer,
        onStartCall = onStartCall,
        onBlockUser = onBlockUser,
        onCreateReport = onCreateReport
    )

    // Active Call Dialog
    CallDialog(
        callSession = activeCall,
        currentUser = currentUser,
        users = users,
        onEndCall = onEndCall
    )
}
