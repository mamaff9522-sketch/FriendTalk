package com.example.ui.admin

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.model.*
import com.example.ui.theme.*

@Composable
fun AdminUiBuilderDialog(
    isOpen: Boolean,
    currentUser: User,
    activeConfig: AppUiConfig,
    versionHistory: List<ConfigVersionRecord>,
    onClose: () -> Unit,
    onSaveDraft: (AppUiConfig) -> Unit,
    onPublishConfig: (config: AppUiConfig, author: String, notes: String) -> Unit,
    onRollbackTo: (version: String, author: String) -> Unit,
    onRestoreDefault: (author: String) -> Unit,
    onOpenApkDownload: () -> Unit
) {
    if (!isOpen) return

    val context = LocalContext.current
    var editingConfig by remember(activeConfig) { mutableStateOf(activeConfig.copy()) }
    var selectedScreenId by remember { mutableStateOf("home") }
    var builderModeTab by remember { mutableStateOf("sections") } // "sections", "nav", "theme", "preview", "history"
    var showPublishConfirmDialog by remember { mutableStateOf(false) }
    var publishNotesInput by remember { mutableStateOf("") }
    var showRestoreConfirmDialog by remember { mutableStateOf(false) }
    var imagePickerTarget by remember { mutableStateOf<String?>(null) } // "logo", "hero_home", "section_id"
    var isImagePickerOpen by remember { mutableStateOf(false) }

    fun showToast(msg: String) {
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
    }

    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Slate950
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Top App Bar with Builder Controls
                Surface(
                    color = Slate900,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 34.dp, bottom = 10.dp, start = 12.dp, end = 12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(PinkPrimary.copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.DashboardCustomize, contentDescription = null, tint = PinkPrimary, modifier = Modifier.size(22.dp))
                                }
                                Column {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            "Admin UI Builder",
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Black,
                                            color = Color.White
                                        )
                                        Surface(
                                            color = AmberGold.copy(alpha = 0.2f),
                                            shape = RoundedCornerShape(4.dp),
                                            border = androidx.compose.foundation.BorderStroke(1.dp, AmberGold)
                                        ) {
                                            Text(
                                                editingConfig.configVersion,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = AmberGold,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        "ปรับแต่งหน้าตาแอปและรีโมตคอนฟิกแบบ No-Code",
                                        fontSize = 10.sp,
                                        color = Slate400
                                    )
                                }
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                IconButton(
                                    onClick = onOpenApkDownload,
                                    modifier = Modifier.size(34.dp)
                                ) {
                                    Icon(Icons.Default.Android, contentDescription = "Download APK", tint = EmeraldGreen)
                                }
                                IconButton(
                                    onClick = {
                                        onSaveDraft(editingConfig)
                                        showToast("บันทึก Draft สำเร็จ!")
                                    },
                                    modifier = Modifier.size(34.dp)
                                ) {
                                    Icon(Icons.Default.Save, contentDescription = "Save Draft", tint = AmberGold)
                                }
                                IconButton(onClick = onClose, modifier = Modifier.size(34.dp)) {
                                    Icon(Icons.Default.Close, contentDescription = "Close", tint = Slate400)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Builder Navigation Tabs
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            listOf(
                                "sections" to "หน้า & Section",
                                "nav" to "เมนูนำทาง",
                                "theme" to "ธีม & สี",
                                "preview" to "📱 พรีวิวมือถือ",
                                "history" to "ประวัติ & ย้อนคืน"
                            ).forEach { (modeId, label) ->
                                val isSelected = builderModeTab == modeId
                                Surface(
                                    onClick = { builderModeTab = modeId },
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isSelected) PinkPrimary else Slate800,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        contentAlignment = Alignment.Center,
                                        modifier = Modifier.padding(vertical = 6.dp)
                                    ) {
                                        Text(
                                            label,
                                            fontSize = 9.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isSelected) Color.White else Slate300
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Main Workspace Content
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    when (builderModeTab) {
                        "sections" -> {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                            ) {
                                // Page Selector Row
                                Text("1. เลือกหน้าที่ต้องการปรับแต่ง:", fontSize = 12.sp, color = Slate400, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(6.dp))

                                val pagesList = listOf(
                                    "home" to "Feed / หน้าแรก",
                                    "discover" to "หาเพื่อน / Discover",
                                    "live" to "ไลฟ์สด / Live",
                                    "movie" to "วิดีโอ / Movie",
                                    "companion" to "เพื่อนคุย (18+)",
                                    "chat" to "แชต / Chat",
                                    "profile" to "โปรไฟล์"
                                )

                                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    items(pagesList) { (pId, pLabel) ->
                                        val isCurrentPage = selectedScreenId == pId
                                        Surface(
                                            onClick = { selectedScreenId = pId },
                                            shape = RoundedCornerShape(10.dp),
                                            color = if (isCurrentPage) PinkPrimary.copy(alpha = 0.25f) else Slate900,
                                            border = androidx.compose.foundation.BorderStroke(
                                                1.dp,
                                                if (isCurrentPage) PinkPrimary else Slate800
                                            )
                                        ) {
                                            Text(
                                                pLabel,
                                                fontSize = 11.sp,
                                                fontWeight = if (isCurrentPage) FontWeight.Bold else FontWeight.Normal,
                                                color = if (isCurrentPage) PinkPrimary else Slate300,
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                // Sections List for Current Screen
                                val currentPageConfig = editingConfig.pages[selectedScreenId] ?: PageUiConfig(selectedScreenId, selectedScreenId)
                                val sections = currentPageConfig.sections

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        "2. จัดการ Section ในหน้านี้ (${sections.size} ส่วน):",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )

                                    OutlinedButton(
                                        onClick = {
                                            val newSecId = "sec_${System.currentTimeMillis() % 10000}"
                                            val newSection = SectionUiConfig(
                                                id = newSecId,
                                                title = "Section ใหม่",
                                                subtitle = "คำอธิบายส่วนเนื้อหาใหม่",
                                                isEnabled = true,
                                                order = sections.size + 1
                                            )
                                            val updatedSections = sections + newSection
                                            val updatedPages = editingConfig.pages.toMutableMap()
                                            updatedPages[selectedScreenId] = currentPageConfig.copy(sections = updatedSections)
                                            editingConfig = editingConfig.copy(pages = updatedPages)
                                        },
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldGreen)
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = null, tint = EmeraldGreen, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("เพิ่ม Section", fontSize = 10.sp, color = EmeraldGreen)
                                    }
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                LazyColumn(
                                    verticalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.fillMaxSize()
                                ) {
                                    items(sections.sortedBy { it.order }, key = { it.id }) { section ->
                                        val sectionIndex = sections.indexOfFirst { it.id == section.id }
                                        Surface(
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(12.dp),
                                            color = Slate900,
                                            border = androidx.compose.foundation.BorderStroke(
                                                1.dp,
                                                if (section.isEnabled) PinkPrimary.copy(alpha = 0.4f) else Slate800
                                            )
                                        ) {
                                            Column(modifier = Modifier.padding(10.dp)) {
                                                // Header Row: Visibility, Title, Order Up/Down, Delete
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                        modifier = Modifier.weight(1f)
                                                    ) {
                                                        IconButton(
                                                            onClick = {
                                                                val updatedSections = sections.map {
                                                                    if (it.id == section.id) it.copy(isEnabled = !it.isEnabled) else it
                                                                }
                                                                val updatedPages = editingConfig.pages.toMutableMap()
                                                                updatedPages[selectedScreenId] = currentPageConfig.copy(sections = updatedSections)
                                                                editingConfig = editingConfig.copy(pages = updatedPages)
                                                            },
                                                            modifier = Modifier.size(28.dp)
                                                        ) {
                                                            Icon(
                                                                if (section.isEnabled) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                                                contentDescription = "Toggle Visibility",
                                                                tint = if (section.isEnabled) PinkPrimary else Slate600,
                                                                modifier = Modifier.size(18.dp)
                                                            )
                                                        }

                                                        Column {
                                                            Text(
                                                                section.title,
                                                                fontSize = 12.sp,
                                                                fontWeight = FontWeight.Bold,
                                                                color = if (section.isEnabled) Color.White else Slate500
                                                            )
                                                            Text(
                                                                "ID: ${section.id} • ลำดับที่ ${section.order}",
                                                                fontSize = 9.sp,
                                                                color = Slate500
                                                            )
                                                        }
                                                    }

                                                    Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                                        // Move Up
                                                        IconButton(
                                                            onClick = {
                                                                if (sectionIndex > 0) {
                                                                    val mutable = sections.toMutableList()
                                                                    val prev = mutable[sectionIndex - 1]
                                                                    val cur = mutable[sectionIndex]
                                                                    mutable[sectionIndex - 1] = cur.copy(order = prev.order)
                                                                    mutable[sectionIndex] = prev.copy(order = cur.order)
                                                                    val updatedPages = editingConfig.pages.toMutableMap()
                                                                    updatedPages[selectedScreenId] = currentPageConfig.copy(sections = mutable)
                                                                    editingConfig = editingConfig.copy(pages = updatedPages)
                                                                }
                                                            },
                                                            enabled = sectionIndex > 0,
                                                            modifier = Modifier.size(28.dp)
                                                        ) {
                                                            Icon(Icons.Default.ArrowUpward, contentDescription = "Move Up", tint = if (sectionIndex > 0) Slate300 else Slate700, modifier = Modifier.size(16.dp))
                                                        }

                                                        // Move Down
                                                        IconButton(
                                                            onClick = {
                                                                if (sectionIndex < sections.size - 1) {
                                                                    val mutable = sections.toMutableList()
                                                                    val next = mutable[sectionIndex + 1]
                                                                    val cur = mutable[sectionIndex]
                                                                    mutable[sectionIndex + 1] = cur.copy(order = next.order)
                                                                    mutable[sectionIndex] = next.copy(order = cur.order)
                                                                    val updatedPages = editingConfig.pages.toMutableMap()
                                                                    updatedPages[selectedScreenId] = currentPageConfig.copy(sections = mutable)
                                                                    editingConfig = editingConfig.copy(pages = updatedPages)
                                                                }
                                                            },
                                                            enabled = sectionIndex < sections.size - 1,
                                                            modifier = Modifier.size(28.dp)
                                                        ) {
                                                            Icon(Icons.Default.ArrowDownward, contentDescription = "Move Down", tint = if (sectionIndex < sections.size - 1) Slate300 else Slate700, modifier = Modifier.size(16.dp))
                                                        }

                                                        // Delete
                                                        IconButton(
                                                            onClick = {
                                                                val updatedSections = sections.filter { it.id != section.id }
                                                                val updatedPages = editingConfig.pages.toMutableMap()
                                                                updatedPages[selectedScreenId] = currentPageConfig.copy(sections = updatedSections)
                                                                editingConfig = editingConfig.copy(pages = updatedPages)
                                                            },
                                                            modifier = Modifier.size(28.dp)
                                                        ) {
                                                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = RosePrimary, modifier = Modifier.size(16.dp))
                                                        }
                                                    }
                                                }

                                                Spacer(modifier = Modifier.height(6.dp))

                                                // Inline Edit Title & Subtitle & Button
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                ) {
                                                    OutlinedTextField(
                                                        value = section.title,
                                                        onValueChange = { newTitle ->
                                                            val updatedSections = sections.map {
                                                                if (it.id == section.id) it.copy(title = newTitle) else it
                                                            }
                                                            val updatedPages = editingConfig.pages.toMutableMap()
                                                            updatedPages[selectedScreenId] = currentPageConfig.copy(sections = updatedSections)
                                                            editingConfig = editingConfig.copy(pages = updatedPages)
                                                        },
                                                        label = { Text("ชื่อ Section", fontSize = 9.sp) },
                                                        modifier = Modifier.weight(1.2f),
                                                        singleLine = true,
                                                        colors = OutlinedTextFieldDefaults.colors(
                                                            focusedBorderColor = PinkPrimary,
                                                            unfocusedBorderColor = Slate800,
                                                            focusedTextColor = Color.White,
                                                            unfocusedTextColor = Color.White
                                                        )
                                                    )

                                                    OutlinedTextField(
                                                        value = section.buttonText ?: "",
                                                        onValueChange = { newBtn ->
                                                            val updatedSections = sections.map {
                                                                if (it.id == section.id) it.copy(buttonText = newBtn) else it
                                                            }
                                                            val updatedPages = editingConfig.pages.toMutableMap()
                                                            updatedPages[selectedScreenId] = currentPageConfig.copy(sections = updatedSections)
                                                            editingConfig = editingConfig.copy(pages = updatedPages)
                                                        },
                                                        label = { Text("ข้อความปุ่ม", fontSize = 9.sp) },
                                                        modifier = Modifier.weight(0.8f),
                                                        singleLine = true,
                                                        colors = OutlinedTextFieldDefaults.colors(
                                                            focusedBorderColor = AmberGold,
                                                            unfocusedBorderColor = Slate800,
                                                            focusedTextColor = Color.White,
                                                            unfocusedTextColor = Color.White
                                                        )
                                                    )
                                                }

                                                Spacer(modifier = Modifier.height(6.dp))

                                                // Image / Banner Selector & Layout Mode
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Button(
                                                        onClick = {
                                                            imagePickerTarget = section.id
                                                            isImagePickerOpen = true
                                                        },
                                                        colors = ButtonDefaults.buttonColors(containerColor = Slate800),
                                                        shape = RoundedCornerShape(8.dp),
                                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                                    ) {
                                                        Icon(Icons.Default.Image, contentDescription = null, tint = PinkPrimary, modifier = Modifier.size(14.dp))
                                                        Spacer(modifier = Modifier.width(4.dp))
                                                        Text(
                                                            if (section.bannerImageUrl.isNullOrBlank()) "เลือกรูปแบนเนอร์" else "เปลี่ยนรูปแบนเนอร์",
                                                            fontSize = 10.sp,
                                                            color = Color.White
                                                        )
                                                    }

                                                    if (!section.bannerImageUrl.isNullOrBlank()) {
                                                        AsyncImage(
                                                            model = section.bannerImageUrl,
                                                            contentDescription = null,
                                                            modifier = Modifier
                                                                .size(30.dp)
                                                                .clip(RoundedCornerShape(6.dp))
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        "nav" -> {
                            // Bottom Nav Builder
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(12.dp)
                            ) {
                                Text("จัดการแถบเมนูนำทางด้านล่าง (Bottom Navigation):", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                Text("สามารถเปิด/ปิดเมนู, เปลี่ยนชื่อปุ่ม, สลับไอคอน และลากเรียงลำดับได้", fontSize = 11.sp, color = Slate400)
                                Spacer(modifier = Modifier.height(10.dp))

                                LazyColumn(
                                    verticalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.fillMaxSize()
                                ) {
                                    items(editingConfig.navigationTabs.sortedBy { it.order }) { tab ->
                                        val tabIndex = editingConfig.navigationTabs.indexOfFirst { it.tabId == tab.tabId }
                                        Surface(
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(12.dp),
                                            color = Slate900,
                                            border = androidx.compose.foundation.BorderStroke(
                                                1.dp,
                                                if (tab.isEnabled) AmberGold.copy(alpha = 0.4f) else Slate800
                                            )
                                        ) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(10.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                    modifier = Modifier.weight(1f)
                                                ) {
                                                    IconButton(
                                                        onClick = {
                                                            val updated = editingConfig.navigationTabs.map {
                                                                if (it.tabId == tab.tabId) it.copy(isEnabled = !it.isEnabled) else it
                                                            }
                                                            editingConfig = editingConfig.copy(navigationTabs = updated)
                                                        },
                                                        modifier = Modifier.size(30.dp)
                                                    ) {
                                                        Icon(
                                                            if (tab.isEnabled) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                                            contentDescription = null,
                                                            tint = if (tab.isEnabled) EmeraldGreen else Slate600
                                                        )
                                                    }

                                                    OutlinedTextField(
                                                        value = tab.label,
                                                        onValueChange = { newLabel ->
                                                            val updated = editingConfig.navigationTabs.map {
                                                                if (it.tabId == tab.tabId) it.copy(label = newLabel) else it
                                                            }
                                                            editingConfig = editingConfig.copy(navigationTabs = updated)
                                                        },
                                                        label = { Text("ชื่อแท็บ", fontSize = 9.sp) },
                                                        modifier = Modifier.weight(1f),
                                                        singleLine = true,
                                                        colors = OutlinedTextFieldDefaults.colors(
                                                            focusedBorderColor = AmberGold,
                                                            unfocusedBorderColor = Slate800,
                                                            focusedTextColor = Color.White,
                                                            unfocusedTextColor = Color.White
                                                        )
                                                    )
                                                }

                                                // Move left/right in order
                                                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                                    IconButton(
                                                        onClick = {
                                                            if (tabIndex > 0) {
                                                                val mutable = editingConfig.navigationTabs.toMutableList()
                                                                val prev = mutable[tabIndex - 1]
                                                                val cur = mutable[tabIndex]
                                                                mutable[tabIndex - 1] = cur.copy(order = prev.order)
                                                                mutable[tabIndex] = prev.copy(order = cur.order)
                                                                editingConfig = editingConfig.copy(navigationTabs = mutable)
                                                            }
                                                        },
                                                        enabled = tabIndex > 0,
                                                        modifier = Modifier.size(28.dp)
                                                    ) {
                                                        Icon(Icons.Default.ArrowBack, contentDescription = "Move Left", tint = if (tabIndex > 0) Slate300 else Slate700, modifier = Modifier.size(16.dp))
                                                    }

                                                    IconButton(
                                                        onClick = {
                                                            if (tabIndex < editingConfig.navigationTabs.size - 1) {
                                                                val mutable = editingConfig.navigationTabs.toMutableList()
                                                                val next = mutable[tabIndex + 1]
                                                                val cur = mutable[tabIndex]
                                                                mutable[tabIndex + 1] = cur.copy(order = next.order)
                                                                mutable[tabIndex] = next.copy(order = cur.order)
                                                                editingConfig = editingConfig.copy(navigationTabs = mutable)
                                                            }
                                                        },
                                                        enabled = tabIndex < editingConfig.navigationTabs.size - 1,
                                                        modifier = Modifier.size(28.dp)
                                                    ) {
                                                        Icon(Icons.Default.ArrowForward, contentDescription = "Move Right", tint = if (tabIndex < editingConfig.navigationTabs.size - 1) Slate300 else Slate700, modifier = Modifier.size(16.dp))
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        "theme" -> {
                            // Theme & Styling Controls
                            val theme = editingConfig.theme
                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                item {
                                    Text("ปรับแต่งธีม สี ขนาดตัวอักษร และความโค้งมน:", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                }

                                // Dark / Light Mode
                                item {
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = Slate900,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(12.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Icon(
                                                    if (theme.themeMode == "light") Icons.Default.LightMode else Icons.Default.DarkMode,
                                                    contentDescription = null,
                                                    tint = AmberGold
                                                )
                                                Text(
                                                    if (theme.themeMode == "light") "โหมดสว่าง (Light Theme)" else "โหมดมืด (Dark Theme)",
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.White
                                                )
                                            }

                                            Switch(
                                                checked = theme.themeMode == "dark",
                                                onCheckedChange = { isDark ->
                                                    editingConfig = editingConfig.copy(
                                                        theme = theme.copy(themeMode = if (isDark) "dark" else "light")
                                                    )
                                                }
                                            )
                                        }
                                    }
                                }

                                // Color Palette Palettes
                                item {
                                    Text("ชุดสีธีมหลัก (Theme Colors):", fontSize = 12.sp, color = Slate400, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(6.dp))

                                    listOf(
                                        "สีหลัก (Primary)" to theme.primaryColorHex,
                                        "สีรอง (Secondary)" to theme.secondaryColorHex,
                                        "สีเน้น (Accent)" to theme.accentColorHex,
                                        "สีพื้นหลัง (Background)" to theme.backgroundColorHex,
                                        "สีการ์ด (Surface)" to theme.surfaceColorHex
                                    ).forEach { (colorLabel, currentHex) ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 4.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(24.dp)
                                                        .clip(CircleShape)
                                                        .background(parseHexColor(currentHex, Color.Magenta))
                                                        .border(1.dp, Color.White, CircleShape)
                                                )
                                                Text(colorLabel, fontSize = 12.sp, color = Color.White)
                                            }

                                            // Quick preset swatches
                                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                listOf("#EC4899", "#F43F5E", "#F59E0B", "#10B981", "#3B82F6", "#8B5CF6", "#020617").forEach { swatchHex ->
                                                    Box(
                                                        modifier = Modifier
                                                            .size(20.dp)
                                                            .clip(CircleShape)
                                                            .background(parseHexColor(swatchHex, Color.Gray))
                                                            .clickable {
                                                                val updatedTheme = when (colorLabel) {
                                                                    "สีหลัก (Primary)" -> theme.copy(primaryColorHex = swatchHex)
                                                                    "สีรอง (Secondary)" -> theme.copy(secondaryColorHex = swatchHex)
                                                                    "สีเน้น (Accent)" -> theme.copy(accentColorHex = swatchHex)
                                                                    "สีพื้นหลัง (Background)" -> theme.copy(backgroundColorHex = swatchHex)
                                                                    else -> theme.copy(surfaceColorHex = swatchHex)
                                                                }
                                                                editingConfig = editingConfig.copy(theme = updatedTheme)
                                                            }
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }

                                // Sizing Sliders
                                item {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text("ขนาดตัวอักษรและระยะห่าง (Typography & Spacing):", fontSize = 12.sp, color = Slate400, fontWeight = FontWeight.Bold)

                                    // Font Scale
                                    Column(modifier = Modifier.padding(vertical = 4.dp)) {
                                        Text("ขนาดตัวอักษร (Font Scale): ${(theme.fontSizeScale * 100).toInt()}%", fontSize = 11.sp, color = Slate300)
                                        Slider(
                                            value = theme.fontSizeScale,
                                            onValueChange = { editingConfig = editingConfig.copy(theme = theme.copy(fontSizeScale = it)) },
                                            valueRange = 0.85f..1.3f,
                                            steps = 3
                                        )
                                    }

                                    // Spacing Scale
                                    Column(modifier = Modifier.padding(vertical = 4.dp)) {
                                        Text("ระยะห่างองค์ประกอบ (Spacing Scale): ${(theme.spacingScale * 100).toInt()}%", fontSize = 11.sp, color = Slate300)
                                        Slider(
                                            value = theme.spacingScale,
                                            onValueChange = { editingConfig = editingConfig.copy(theme = theme.copy(spacingScale = it)) },
                                            valueRange = 0.8f..1.3f,
                                            steps = 3
                                        )
                                    }

                                    // Card Corner Radius
                                    Column(modifier = Modifier.padding(vertical = 4.dp)) {
                                        Text("ความโค้งมนของการ์ด (Card Radius): ${theme.cardCornerRadiusDp} dp", fontSize = 11.sp, color = Slate300)
                                        Slider(
                                            value = theme.cardCornerRadiusDp.toFloat(),
                                            onValueChange = { editingConfig = editingConfig.copy(theme = theme.copy(cardCornerRadiusDp = it.toInt())) },
                                            valueRange = 0f..28f,
                                            steps = 4
                                        )
                                    }

                                    // Button Corner Radius
                                    Column(modifier = Modifier.padding(vertical = 4.dp)) {
                                        Text("ความโค้งมนของปุ่ม (Button Radius): ${theme.buttonCornerRadiusDp} dp", fontSize = 11.sp, color = Slate300)
                                        Slider(
                                            value = theme.buttonCornerRadiusDp.toFloat(),
                                            onValueChange = { editingConfig = editingConfig.copy(theme = theme.copy(buttonCornerRadiusDp = it.toInt())) },
                                            valueRange = 0f..28f,
                                            steps = 4
                                        )
                                    }
                                }

                                // App Branding / Logo / App Name
                                item {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text("โลโก้และชื่อแอปพลิเคชัน (App Branding):", fontSize = 12.sp, color = Slate400, fontWeight = FontWeight.Bold)

                                    OutlinedTextField(
                                        value = editingConfig.appName,
                                        onValueChange = { editingConfig = editingConfig.copy(appName = it) },
                                        label = { Text("ชื่อแอป (App Name)") },
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = PinkPrimary,
                                            unfocusedBorderColor = Slate800,
                                            focusedTextColor = Color.White,
                                            unfocusedTextColor = Color.White
                                        )
                                    )

                                    Spacer(modifier = Modifier.height(8.dp))

                                    Button(
                                        onClick = {
                                            imagePickerTarget = "logo"
                                            isImagePickerOpen = true
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Slate900),
                                        shape = RoundedCornerShape(10.dp),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, Slate700)
                                    ) {
                                        Icon(Icons.Default.Image, contentDescription = null, tint = PinkPrimary)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(if (editingConfig.appLogoUrl.isBlank()) "อัปโหลดหรือเลือกรูปโลโก้" else "เปลี่ยนรูปโลโก้แอป", color = Color.White)
                                    }
                                }
                            }
                        }

                        "preview" -> {
                            // Live Realistic Mobile Phone Mockup Preview
                            MobileDevicePreview(
                                config = editingConfig,
                                activePreviewTab = selectedScreenId,
                                onTabSelected = { selectedScreenId = it },
                                modifier = Modifier.fillMaxSize()
                            )
                        }

                        "history" -> {
                            // Version History & Rollback
                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                item {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("ประวัติเวอร์ชัน UI ทั้งหมด (${versionHistory.size})", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                        OutlinedButton(
                                            onClick = { showRestoreConfirmDialog = true },
                                            colors = ButtonDefaults.outlinedButtonColors(contentColor = RosePrimary),
                                            shape = RoundedCornerShape(10.dp)
                                        ) {
                                            Text("คืนค่าดั้งเดิม (Restore Default)", fontSize = 10.sp)
                                        }
                                    }
                                }

                                items(versionHistory) { record ->
                                    Surface(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(14.dp),
                                        color = Slate900,
                                        border = androidx.compose.foundation.BorderStroke(
                                            1.dp,
                                            if (record.isActive) EmeraldGreen else Slate800
                                        )
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                ) {
                                                    Text(record.version, fontSize = 14.sp, fontWeight = FontWeight.Black, color = Color.White)
                                                    if (record.isActive) {
                                                        Surface(
                                                            color = EmeraldGreen.copy(alpha = 0.2f),
                                                            shape = RoundedCornerShape(4.dp)
                                                        ) {
                                                            Text(
                                                                "ใช้งานอยู่ขณะนี้",
                                                                fontSize = 9.sp,
                                                                color = EmeraldGreen,
                                                                fontWeight = FontWeight.Bold,
                                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                            )
                                                        }
                                                    }
                                                }

                                                if (!record.isActive) {
                                                    Button(
                                                        onClick = {
                                                            onRollbackTo(record.version, currentUser.displayName)
                                                            editingConfig = record.config.copy()
                                                            showToast("Rollback กลับไปยังเวอร์ชัน ${record.version} สำเร็จ!")
                                                        },
                                                        colors = ButtonDefaults.buttonColors(containerColor = AmberGold),
                                                        shape = RoundedCornerShape(8.dp),
                                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                                    ) {
                                                        Icon(Icons.Default.Restore, contentDescription = null, tint = Slate950, modifier = Modifier.size(14.dp))
                                                        Spacer(modifier = Modifier.width(4.dp))
                                                        Text("Rollback", fontSize = 11.sp, color = Slate950, fontWeight = FontWeight.Bold)
                                                    }
                                                }
                                            }

                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text("เผยแพร่เมื่อ: ${record.publishedAt} โดย ${record.publishedBy}", fontSize = 10.sp, color = Slate400)
                                            Text("บันทึก: ${record.notes}", fontSize = 11.sp, color = Slate300)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Bottom Action Bar: Cancel, Preview toggle, Publish Button
                Surface(
                    color = Slate900,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = {
                                editingConfig = activeConfig.copy()
                                showToast("ยกเลิกการเปลี่ยนแปลงที่ยังไม่บันทึกแล้ว")
                            },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(0.8f)
                        ) {
                            Text("ยกเลิก", color = Slate400, fontSize = 12.sp)
                        }

                        Button(
                            onClick = {
                                builderModeTab = if (builderModeTab == "preview") "sections" else "preview"
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Slate800),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                if (builderModeTab == "preview") Icons.Default.Edit else Icons.Default.PhoneAndroid,
                                contentDescription = null,
                                tint = PinkPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (builderModeTab == "preview") "กลับไปแก้ไข" else "ดูพรีวิวสด", fontSize = 11.sp, color = Color.White)
                        }

                        Button(
                            onClick = { showPublishConfirmDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1.3f)
                        ) {
                            Icon(Icons.Default.CloudUpload, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Publish ขึ้นระบบสด", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }
        }
    }

    // Publish Confirmation Dialog
    if (showPublishConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showPublishConfirmDialog = false },
            title = { Text("ยืนยัน Publish UI Config ขึ้นระบบจริง", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "เมื่อ Publish แล้ว แอป FriendTalk ของผู้ใช้งานทั้งหมดจะซิงค์การตั้งค่า UI นี้ทันที โดยไม่ต้อง Build APK ใหม่!",
                        fontSize = 12.sp,
                        color = Slate300
                    )
                    OutlinedTextField(
                        value = publishNotesInput,
                        onValueChange = { publishNotesInput = it },
                        label = { Text("บันทึกการเปลี่ยนแปลง (Changelog)") },
                        placeholder = { Text("เช่น ปรับตำแหน่งแบนเนอร์และชุดสีธีม") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PinkPrimary,
                            unfocusedBorderColor = Slate800,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onPublishConfig(editingConfig, currentUser.displayName, publishNotesInput.trim())
                        showPublishConfirmDialog = false
                        showToast("Publish UI Config เวอร์ชันใหม่เรียบร้อย!")
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary)
                ) {
                    Text("ยืนยัน Publish ทันที", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showPublishConfirmDialog = false }) {
                    Text("ยกเลิก", color = Slate400)
                }
            },
            containerColor = Slate900
        )
    }

    // Restore Default Confirmation
    if (showRestoreConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showRestoreConfirmDialog = false },
            title = { Text("ยืนยันคืนค่าเริ่มต้น (Restore Default)?", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Text("การตั้งค่าหน้าตา สี และ Section ทั้งหมดจะถูกรีเซ็ตกลับเป็นค่าเริ่มต้นดั้งเดิมของ FriendTalk", fontSize = 12.sp, color = Slate300)
            },
            confirmButton = {
                Button(
                    onClick = {
                        onRestoreDefault(currentUser.displayName)
                        showRestoreConfirmDialog = false
                        showToast("รีเซ็ตค่า UI กลับสู่ค่าตั้งต้นแล้ว!")
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RosePrimary)
                ) {
                    Text("ยืนยันรีเซ็ต", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRestoreConfirmDialog = false }) {
                    Text("ยกเลิก", color = Slate400)
                }
            },
            containerColor = Slate900
        )
    }

    // Image Picker Sheet Dialog
    ImagePickerSheetDialog(
        isOpen = isImagePickerOpen,
        title = if (imagePickerTarget == "logo") "เลือกรูปโลโก้แอป FriendTalk" else "เลือกรูปแบนเนอร์สำหรับ Section",
        onClose = { isImagePickerOpen = false },
        onImageSelected = { newImageUrl ->
            when (imagePickerTarget) {
                "logo" -> {
                    editingConfig = editingConfig.copy(appLogoUrl = newImageUrl)
                }
                else -> {
                    val secId = imagePickerTarget
                    val currentPageConfig = editingConfig.pages[selectedScreenId] ?: PageUiConfig(selectedScreenId, selectedScreenId)
                    val updatedSections = currentPageConfig.sections.map {
                        if (it.id == secId) it.copy(bannerImageUrl = newImageUrl) else it
                    }
                    val updatedPages = editingConfig.pages.toMutableMap()
                    updatedPages[selectedScreenId] = currentPageConfig.copy(sections = updatedSections)
                    editingConfig = editingConfig.copy(pages = updatedPages)
                }
            }
            isImagePickerOpen = false
            showToast("อัปเดตรูปภาพเรียบร้อย!")
        }
    )
}
