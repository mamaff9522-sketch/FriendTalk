package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.model.Gender
import com.example.model.User
import com.example.model.UserRole
import com.example.ui.theme.*

@Composable
fun AuthDialog(
    isOpen: Boolean,
    currentUser: User,
    users: List<User>,
    onClose: () -> Unit,
    onSwitchUser: (String) -> Unit,
    onRegisterUser: (displayName: String, username: String, age: Int, gender: Gender) -> Unit
) {
    if (!isOpen) return

    var mode by remember { mutableStateOf("switch") } // "switch" or "register"

    // Register fields
    var displayName by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var ageStr by remember { mutableStateOf("22") }
    var selectedGender by remember { mutableStateOf(Gender.FEMALE) }

    Dialog(onDismissRequest = onClose) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.82f),
            shape = RoundedCornerShape(28.dp),
            color = Slate900,
            border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (mode == "switch") "สลับบัญชีผู้ใช้งาน" else "สร้างบัญชีใหม่",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    IconButton(onClick = onClose) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "ปิด",
                            tint = Slate400
                        )
                    }
                }

                // Mode Tabs
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 10.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Slate950)
                        .padding(4.dp)
                ) {
                    TabPill(
                        label = "สลับบัญชีทดสอบ",
                        selected = mode == "switch",
                        onClick = { mode = "switch" },
                        modifier = Modifier.weight(1f)
                    )
                    TabPill(
                        label = "สมัครสมาชิกใหม่",
                        selected = mode == "register",
                        onClick = { mode = "register" },
                        modifier = Modifier.weight(1f)
                    )
                }

                if (mode == "switch") {
                    Text(
                        text = "สลับบัญชีเพื่อทดสอบฟังก์ชันในแต่ละบทบาทได้ทันที",
                        fontSize = 11.sp,
                        color = Slate400,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(users) { user ->
                            val isSelected = user.id == currentUser.id
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        onSwitchUser(user.id)
                                        onClose()
                                    },
                                shape = RoundedCornerShape(16.dp),
                                color = if (isSelected) PinkPrimary.copy(alpha = 0.15f) else Slate950,
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (isSelected) PinkPrimary else Slate800
                                )
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Box {
                                        AsyncImage(
                                            model = user.avatar,
                                            contentDescription = user.displayName,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier
                                                .size(40.dp)
                                                .clip(CircleShape)
                                        )
                                        if (user.isOnline) {
                                            Box(
                                                modifier = Modifier
                                                    .align(Alignment.BottomEnd)
                                                    .size(10.dp)
                                                    .clip(CircleShape)
                                                    .background(EmeraldGreen)
                                            )
                                        }
                                    }

                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Text(
                                                text = user.displayName,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White
                                            )
                                            if (user.role == UserRole.SUPERADMIN) {
                                                RoleBadge("ADMIN", AmberGold)
                                            } else if (user.role == UserRole.MODERATOR) {
                                                RoleBadge("MOD", SkyBlue)
                                            } else if (user.isCreator) {
                                                RoleBadge("CREATOR", PinkPrimary)
                                            }
                                        }
                                        Text(
                                            text = "@${user.username} • ${user.age} ปี • ${user.location.province}",
                                            fontSize = 11.sp,
                                            color = Slate400
                                        )
                                    }

                                    if (isSelected) {
                                        Icon(
                                            imageVector = Icons.Default.CheckCircle,
                                            contentDescription = null,
                                            tint = PinkPrimary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                } else {
                    // Register Mode
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(top = 4.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = displayName,
                            onValueChange = { displayName = it },
                            label = { Text("ชื่อที่แสดง (Display Name)") },
                            placeholder = { Text("เช่น มินนี่, นาวิน") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = PinkPrimary,
                                unfocusedBorderColor = Slate800,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )

                        OutlinedTextField(
                            value = username,
                            onValueChange = { username = it },
                            label = { Text("ชื่อผู้ใช้ (Username)") },
                            placeholder = { Text("เช่น minnie_cute") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = PinkPrimary,
                                unfocusedBorderColor = Slate800,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = ageStr,
                                onValueChange = { ageStr = it },
                                label = { Text("อายุ (ปี)") },
                                modifier = Modifier.weight(1f),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = PinkPrimary,
                                    unfocusedBorderColor = Slate800,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                )
                            )

                            Column(modifier = Modifier.weight(1f)) {
                                Text("เพศ", fontSize = 11.sp, color = Slate400)
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    FilterChip(
                                        selected = selectedGender == Gender.FEMALE,
                                        onClick = { selectedGender = Gender.FEMALE },
                                        label = { Text("หญิง", fontSize = 11.sp) }
                                    )
                                    FilterChip(
                                        selected = selectedGender == Gender.MALE,
                                        onClick = { selectedGender = Gender.MALE },
                                        label = { Text("ชาย", fontSize = 11.sp) }
                                    )
                                }
                            }
                        }

                        Surface(
                            color = AmberGold.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, AmberGold.copy(alpha = 0.3f))
                        ) {
                            Text(
                                text = "🎁 สมาชิกใหม่รับฟรี 500 Coins ทันทีที่สมัคร!",
                                fontSize = 11.sp,
                                color = AmberLight,
                                modifier = Modifier.padding(10.dp)
                            )
                        }

                        Spacer(modifier = Modifier.weight(1f))

                        Button(
                            onClick = {
                                if (displayName.isNotBlank() && username.isNotBlank()) {
                                    val age = ageStr.toIntOrNull() ?: 22
                                    onRegisterUser(displayName, username, age, selectedGender)
                                    onClose()
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary)
                        ) {
                            Text(
                                text = "สร้างบัญชี & เข้าสู่ระบบ",
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TabPill(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.clickable { onClick() },
        color = if (selected) PinkPrimary else Color.Transparent,
        shape = RoundedCornerShape(10.dp)
    ) {
        Box(
            modifier = Modifier.padding(vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = label,
                fontSize = 12.sp,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                color = if (selected) Color.White else Slate400
            )
        }
    }
}

@Composable
private fun RoleBadge(label: String, color: Color) {
    Surface(
        color = color.copy(alpha = 0.2f),
        shape = RoundedCornerShape(4.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.4f))
    ) {
        Text(
            text = label,
            color = color,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
        )
    }
}
