package com.example.ui.live

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.model.*
import com.example.service.SoundService
import com.example.ui.components.ReportDialog
import com.example.ui.theme.*
import kotlinx.coroutines.delay

data class FloatingHeart(
    val id: Long,
    val offsetX: Float
)

@Composable
fun LiveRoomDialog(
    isOpen: Boolean,
    roomId: String?,
    currentUser: User,
    users: List<User>,
    liveRooms: List<LiveRoom>,
    followingIds: Set<String>,
    onClose: () -> Unit,
    onToggleFollow: (String) -> Unit,
    onSendHeart: (String) -> Unit,
    onSendGift: (String, Gift) -> Boolean,
    onTogglePk: (String) -> Unit,
    onMuteViewer: (String, String) -> Unit,
    onKickViewer: (String, String) -> Unit,
    onEndLive: (String) -> Unit,
    onOpenCoins: () -> Unit,
    onCreateReport: (targetType: String, targetId: String, reason: String, details: String?) -> Unit
) {
    if (!isOpen || roomId == null) return
    val room = liveRooms.find { it.id == roomId } ?: return
    val host = users.find { it.id == room.hostId } ?: return

    val isHost = currentUser.id == host.id
    val isFollowing = followingIds.contains(host.id)

    var isGiftSheetOpen by remember { mutableStateOf(false) }
    var isTopGifterOpen by remember { mutableStateOf(false) }
    var isReportOpen by remember { mutableStateOf(false) }
    var isGuestJoined by remember { mutableStateOf(false) }
    var messageText by remember { mutableStateOf("") }
    var selectedViewerForMod by remember { mutableStateOf<String?>(null) }

    var floatingHearts by remember { mutableStateOf(listOf<FloatingHeart>()) }

    var messages by remember(roomId) {
        mutableStateOf(
            listOf(
                LiveMessage("lm_1", roomId, "user_fah", "สวัสดีค่ะทุกคน วันนี้เสียงใสมากก 💖", "chat", null, "1 นาทีที่แล้ว"),
                LiveMessage("lm_2", roomId, "user_arty", "สู้ๆ นะครับ! ส่งกำลังใจให้รัวๆ ⚡", "chat", null, "เมื่อสักครู่")
            )
        )
    }

    // Auto add peer messages simulation
    LaunchedEffect(roomId) {
        val sampleUsers = listOf("น้องมายด์", "วินเนอร์", "พี่ท็อป", "เจนจิรา", "โอ๊ต", "แนนซี่")
        val sampleMsgs = listOf(
            "ร้องเพราะมากเลยครับ ฟังเพลินเลย 🥰",
            "ส่งหัวใจรัวๆๆๆ ❤️❤️❤️",
            "แวะมาให้กำลังใจน้าาา ✨",
            "วันนี้สวย/หล่อมากเลยครับ!",
            "เพลงนี้เพราะจังเลยครับ"
        )
        while (true) {
            delay(4000)
            val newMsg = LiveMessage(
                id = "lm_${System.currentTimeMillis()}",
                roomId = roomId,
                senderId = "guest",
                text = "${sampleUsers.random()}: ${sampleMsgs.random()}",
                type = "chat"
            )
            messages = (messages + newMsg).takeLast(15)
        }
    }

    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            // Background Video Stream / Cover
            if (room.isPkMode && room.pkOpponent != null) {
                // Split Screen PK Battle
                val opponent = users.find { it.id == room.pkOpponent.hostId }
                Column(modifier = Modifier.fillMaxSize()) {
                    // Top: Host Stream
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .border(1.dp, PinkPrimary)
                    ) {
                        AsyncImage(
                            model = room.coverUrl,
                            contentDescription = host.displayName,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Surface(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(8.dp),
                            color = Color.Black.copy(alpha = 0.6f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "🔵 ${host.displayName}: 🪙 ${room.pkScore}",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    // Bottom: Opponent Stream
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .border(1.dp, RosePrimary)
                    ) {
                        AsyncImage(
                            model = room.pkOpponent.streamUrl ?: opponent?.avatar,
                            contentDescription = opponent?.displayName,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Surface(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(8.dp),
                            color = Color.Black.copy(alpha = 0.6f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "🔴 ${opponent?.displayName ?: "คู่แข่ง"}: 🪙 ${room.pkOpponent.score}",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            } else {
                // Single Stream
                AsyncImage(
                    model = room.coverUrl,
                    contentDescription = host.displayName,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Co-host guest pip window
                if (isGuestJoined) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(top = 80.dp, end = 14.dp)
                            .size(100.dp, 130.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .border(2.dp, PinkPrimary, RoundedCornerShape(16.dp))
                    ) {
                        AsyncImage(
                            model = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80",
                            contentDescription = "Guest",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Text(
                            text = "Guest: ฟ้าใส",
                            color = Color.White,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .background(Color.Black.copy(alpha = 0.6f))
                                .padding(2.dp)
                        )
                    }
                }
            }

            // Dark overlay for controls visibility
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color.Black.copy(alpha = 0.7f),
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.85f)
                            )
                        )
                    )
            )

            // Top Header Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 40.dp, start = 12.dp, end = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Host badge
                Surface(
                    color = Color.Black.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(20.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.2f))
                ) {
                    Row(
                        modifier = Modifier.padding(4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        AsyncImage(
                            model = host.avatar,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                        )
                        Column {
                            Text(
                                text = host.displayName,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "🪙 ${room.currentGiftCoins} Coins",
                                fontSize = 10.sp,
                                color = AmberGold
                            )
                        }

                        if (!isHost) {
                            Button(
                                onClick = { onToggleFollow(host.id) },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isFollowing) Color.White.copy(alpha = 0.2f) else PinkPrimary
                                ),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (isFollowing) "ติดตาม" else "+ ติดตาม",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }

                // Top Controls (Viewers, Leaderboard, Report, Close)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(
                        color = Color.Black.copy(alpha = 0.5f),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(Icons.Default.Group, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                            Text("${room.viewersCount}", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }

                    IconButton(
                        onClick = { isTopGifterOpen = true },
                        modifier = Modifier
                            .size(32.dp)
                            .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                    ) {
                        Icon(Icons.Default.EmojiEvents, contentDescription = "Top Gifter", tint = AmberGold, modifier = Modifier.size(18.dp))
                    }

                    IconButton(
                        onClick = { isReportOpen = true },
                        modifier = Modifier
                            .size(32.dp)
                            .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                    ) {
                        Icon(Icons.Outlined.Flag, contentDescription = "Report", tint = RosePrimary, modifier = Modifier.size(18.dp))
                    }

                    IconButton(
                        onClick = onClose,
                        modifier = Modifier
                            .size(32.dp)
                            .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "ปิด", tint = Color.White, modifier = Modifier.size(18.dp))
                    }
                }
            }

            // PK Battle Gauge if active
            if (room.isPkMode) {
                Column(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 95.dp, start = 16.dp, end = 16.dp)
                        .fillMaxWidth()
                ) {
                    Surface(
                        color = Color.Black.copy(alpha = 0.7f),
                        shape = RoundedCornerShape(16.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, RosePrimary.copy(alpha = 0.4f))
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("🔵 ${host.displayName}: ${room.pkScore}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SkyBlue)
                                Text("⚔️ PK 02:45", fontSize = 11.sp, fontWeight = FontWeight.Black, color = AmberGold)
                                Text("${room.pkOpponent?.score ?: 500} 🔴", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = RosePrimary)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            // Gauge bar
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(8.dp)
                                    .clip(RoundedCornerShape(4.dp))
                            ) {
                                Box(
                                    modifier = Modifier
                                        .weight(0.55f)
                                        .fillMaxHeight()
                                        .background(SkyBlue)
                                )
                                Box(
                                    modifier = Modifier
                                        .weight(0.45f)
                                        .fillMaxHeight()
                                        .background(RosePrimary)
                                )
                            }
                        }
                    }
                }
            }

            // Floating Hearts Display
            floatingHearts.forEach { heart ->
                Text(
                    text = "❤️",
                    fontSize = 28.sp,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(bottom = 120.dp, end = (40 + heart.offsetX).dp)
                )
            }

            // Bottom Controls Area
            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(14.dp)
            ) {
                // Host Moderation Bar if current user is Host
                if (isHost) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Button(
                            onClick = { onTogglePk(room.id) },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = AmberGold.copy(alpha = 0.25f)),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = if (room.isPkMode) "จบ PK Battle" else "⚔️ เริ่ม PK Battle",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = AmberLight
                            )
                        }

                        Button(
                            onClick = { isGuestJoined = !isGuestJoined },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = PurpleAccent.copy(alpha = 0.25f)),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = if (isGuestJoined) "นำ Guest ออก" else "👥 เชิญ Guest",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = PurpleAccent
                            )
                        }

                        Button(
                            onClick = { onEndLive(room.id) },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Red.copy(alpha = 0.3f)),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text("จบไลฟ์", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Red)
                        }
                    }
                }

                // Chat Messages Stream
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 140.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(messages) { msg ->
                        Surface(
                            color = Color.Black.copy(alpha = 0.5f),
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.1f)),
                            modifier = Modifier.clickable {
                                if (isHost) {
                                    selectedViewerForMod = msg.senderId
                                }
                            }
                        ) {
                            Text(
                                text = msg.text,
                                color = Color.White,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Bottom Input & Gifts / Heart Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = messageText,
                        onValueChange = { messageText = it },
                        placeholder = { Text("คุยอะไรหน่อย...", fontSize = 12.sp, color = Slate400) },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        shape = RoundedCornerShape(20.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PinkPrimary,
                            unfocusedBorderColor = Color.White.copy(alpha = 0.3f),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    IconButton(
                        onClick = {
                            if (messageText.isNotBlank()) {
                                val newM = LiveMessage(
                                    id = "lm_${System.currentTimeMillis()}",
                                    roomId = room.id,
                                    senderId = currentUser.id,
                                    text = "${currentUser.displayName}: ${messageText.trim()}",
                                    type = "chat"
                                )
                                messages = (messages + newM).takeLast(15)
                                messageText = ""
                                SoundService.playPop()
                            }
                        },
                        modifier = Modifier
                            .size(38.dp)
                            .background(PinkPrimary, CircleShape)
                    ) {
                        Icon(Icons.Default.Send, contentDescription = "ส่ง", tint = Color.White, modifier = Modifier.size(16.dp))
                    }

                    // Gift Sheet Trigger
                    IconButton(
                        onClick = { isGiftSheetOpen = true },
                        modifier = Modifier
                            .size(42.dp)
                            .background(Brush.linearGradient(listOf(AmberGold, RosePrimary)), CircleShape)
                    ) {
                        Text("🎁", fontSize = 20.sp)
                    }

                    // Floating Heart Trigger
                    IconButton(
                        onClick = {
                            onSendHeart(room.id)
                            floatingHearts = floatingHearts + FloatingHeart(System.currentTimeMillis(), (0..30).random().toFloat())
                        },
                        modifier = Modifier
                            .size(42.dp)
                            .background(PinkPrimary, CircleShape)
                    ) {
                        Icon(Icons.Default.Favorite, contentDescription = "Heart", tint = Color.White, modifier = Modifier.size(22.dp))
                    }
                }
            }

            // Moderator Sheet for selected viewer
            selectedViewerForMod?.let { viewerId ->
                Dialog(onDismissRequest = { selectedViewerForMod = null }) {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(22.dp),
                        color = Slate900,
                        border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("จัดการผู้ชมในห้องไลฟ์", fontWeight = FontWeight.Bold, color = Color.White)
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = {
                                        onMuteViewer(room.id, viewerId)
                                        selectedViewerForMod = null
                                    },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = Slate800)
                                ) {
                                    Text("ปิดเสียง (Mute)", fontSize = 11.sp)
                                }
                                Button(
                                    onClick = {
                                        onKickViewer(room.id, viewerId)
                                        selectedViewerForMod = null
                                    },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = RosePrimary)
                                ) {
                                    Text("เตะออกจากห้อง", fontSize = 11.sp, color = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Gift Sheet Modal
    GiftSheetDialog(
        isOpen = isGiftSheetOpen,
        currentUser = currentUser,
        onClose = { isGiftSheetOpen = false },
        onSelectGift = { gift ->
            val success = onSendGift(room.id, gift)
            if (success) {
                isGiftSheetOpen = false
                val giftMsg = LiveMessage(
                    id = "lm_gift_${System.currentTimeMillis()}",
                    roomId = room.id,
                    senderId = currentUser.id,
                    text = "${currentUser.displayName} ส่ง ${gift.name} ${gift.icon} (${gift.coins} Coins)!",
                    type = "gift"
                )
                messages = (messages + giftMsg).takeLast(15)
            }
        },
        onOpenCoins = onOpenCoins
    )

    // Top Gifter Modal
    TopGifterDialog(
        isOpen = isTopGifterOpen,
        hostName = host.displayName,
        users = users,
        onClose = { isTopGifterOpen = false }
    )

    // Report Dialog
    ReportDialog(
        isOpen = isReportOpen,
        targetType = "live",
        targetId = room.id,
        targetName = "ห้องไลฟ์ของ ${host.displayName}",
        onClose = { isReportOpen = false },
        onSubmitReport = { reason, details ->
            onCreateReport("live", room.id, reason, details)
            isReportOpen = false
        }
    )
}
