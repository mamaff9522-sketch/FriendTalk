package com.example.ui.movie

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.AppUiConfig
import com.example.model.User
import com.example.model.parseHexColor
import com.example.ui.theme.*

data class MovieVideoItem(
    val id: String,
    val title: String,
    val creatorName: String,
    val creatorAvatar: String,
    val thumbnailUrl: String,
    val viewsCount: String,
    val likesCount: Int,
    val duration: String,
    val category: String
)

val MOCK_VIDEOS = listOf(
    MovieVideoItem(
        id = "vid_1",
        title = "ซีรีส์รักวัยรุ่น FriendTalk: ตอนที่ 1 รักแรกพบในห้องแชต",
        creatorName = "Linlin Official",
        creatorAvatar = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80",
        thumbnailUrl = "https://images.unsplash.com/photo-1485846234645-a62644f84728?w=800&auto=format&fit=crop&q=80",
        viewsCount = "124K",
        likesCount = 5820,
        duration = "14:20",
        category = "ละครสั้น"
    ),
    MovieVideoItem(
        id = "vid_2",
        title = "PK Battle ไฮไลท์สุดมันส์: Linlin VS Arty ชิงมงกุฎไลฟ์",
        creatorName = "FriendTalk Highlight",
        creatorAvatar = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80",
        thumbnailUrl = "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=800&auto=format&fit=crop&q=80",
        viewsCount = "89K",
        likesCount = 4210,
        duration = "08:45",
        category = "ไลฟ์สไตล์"
    ),
    MovieVideoItem(
        id = "vid_3",
        title = "เบื้องหลังคอนเสิร์ตอินดี้และเรื่องเล่าจากเพื่อนคุย",
        creatorName = "Fah Music",
        creatorAvatar = "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&auto=format&fit=crop&q=80",
        thumbnailUrl = "https://images.unsplash.com/photo-1511632765486-a01980e01a18?w=800&auto=format&fit=crop&q=80",
        viewsCount = "62K",
        likesCount = 3100,
        duration = "05:12",
        category = "ดนตรี"
    ),
    MovieVideoItem(
        id = "vid_4",
        title = "สอนเทคนิคการคุยคลายเหงา และการเป็นเพื่อนคุยมืออาชีพ",
        creatorName = "Coach Ken",
        creatorAvatar = "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&auto=format&fit=crop&q=80",
        thumbnailUrl = "https://images.unsplash.com/photo-1517457373958-b7bdd4587205?w=800&auto=format&fit=crop&q=80",
        viewsCount = "45K",
        likesCount = 2890,
        duration = "10:30",
        category = "เพื่อนคุย"
    )
)

@Composable
fun MovieTab(
    currentUser: User,
    uiConfig: AppUiConfig = AppUiConfig(),
    onOpenCoins: () -> Unit = {}
) {
    val movieConfig = uiConfig.pages["movie"]
    val theme = uiConfig.theme
    val isDark = theme.themeMode != "light"

    val bgColor = parseHexColor(theme.backgroundColorHex, if (isDark) Slate950 else Color(0xFFF8FAFC))
    val surfaceColor = parseHexColor(theme.surfaceColorHex, if (isDark) Slate900 else Color.White)
    val primaryColor = parseHexColor(theme.primaryColorHex, PinkPrimary)
    val textColor = parseHexColor(theme.textColorHex, if (isDark) Color.White else Color(0xFF0F172A))
    val textSecColor = parseHexColor(theme.textSecondaryColorHex, if (isDark) Slate400 else Color(0xFF64748B))
    val cardRadius = theme.cardCornerRadiusDp.dp

    var selectedCategory by remember { mutableStateOf("ทั้งหมด") }
    var likedVideoIds by remember { mutableStateOf(setOf<String>()) }
    var activePlayingVideo by remember { mutableStateOf<MovieVideoItem?>(null) }

    val categories = listOf("ทั้งหมด", "ละครสั้น", "ไลฟ์สไตล์", "ดนตรี", "เพื่อนคุย", "ตลก", "เกม")

    val filteredVideos = remember(selectedCategory) {
        if (selectedCategory == "ทั้งหมด") MOCK_VIDEOS
        else MOCK_VIDEOS.filter { it.category == selectedCategory }
    }

    val enabledSections = movieConfig?.sections?.filter { it.isEnabled }?.sortedBy { it.order } ?: emptyList()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(bgColor)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 80.dp),
            verticalArrangement = Arrangement.spacedBy((12 * theme.spacingScale).dp)
        ) {
            // Render configured sections in order
            enabledSections.forEach { section ->
                when (section.id) {
                    "video_hero" -> {
                        item(key = "video_hero") {
                            val heroUrl = section.bannerImageUrl ?: movieConfig?.heroImageUrl ?: "https://images.unsplash.com/photo-1485846234645-a62644f84728?w=800&auto=format&fit=crop&q=80"
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(170.dp),
                                color = surfaceColor
                            ) {
                                Box(modifier = Modifier.fillMaxSize()) {
                                    AsyncImage(
                                        model = heroUrl,
                                        contentDescription = section.title,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .background(
                                                Brush.verticalGradient(
                                                    listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f))
                                                )
                                            )
                                    )
                                    Column(
                                        modifier = Modifier
                                            .align(Alignment.BottomStart)
                                            .padding(14.dp)
                                    ) {
                                        Surface(
                                            color = primaryColor,
                                            shape = RoundedCornerShape(6.dp)
                                        ) {
                                            Text(
                                                "FEATURED MOVIE",
                                                color = Color.White,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Black,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            section.title,
                                            fontSize = 17.sp,
                                            fontWeight = FontWeight.Black,
                                            color = Color.White
                                        )
                                        if (section.subtitle.isNotBlank()) {
                                            Text(
                                                section.subtitle,
                                                fontSize = 11.sp,
                                                color = Slate300
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    "category_chips" -> {
                        item(key = "category_chips") {
                            Column(modifier = Modifier.padding(horizontal = 14.dp)) {
                                Text(section.title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = textColor)
                                Spacer(modifier = Modifier.height(6.dp))
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    items(categories) { cat ->
                                        val isSelected = selectedCategory == cat
                                        Surface(
                                            onClick = { selectedCategory = cat },
                                            shape = RoundedCornerShape(20.dp),
                                            color = if (isSelected) primaryColor else surfaceColor,
                                            border = androidx.compose.foundation.BorderStroke(
                                                1.dp,
                                                if (isSelected) primaryColor else parseHexColor(theme.cardBorderColorHex, Slate800)
                                            )
                                        ) {
                                            Text(
                                                cat,
                                                fontSize = 11.sp,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                color = if (isSelected) Color.White else textSecColor,
                                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    "trending_videos" -> {
                        item(key = "trending_videos") {
                            Column(modifier = Modifier.padding(horizontal = 14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(section.title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = textColor)
                                    Text("ดูทั้งหมด >", fontSize = 11.sp, color = primaryColor, fontWeight = FontWeight.SemiBold)
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    items(MOCK_VIDEOS.take(3)) { item ->
                                        Surface(
                                            modifier = Modifier
                                                .width(160.dp)
                                                .clickable { activePlayingVideo = item },
                                            shape = RoundedCornerShape(cardRadius),
                                            color = surfaceColor,
                                            border = androidx.compose.foundation.BorderStroke(1.dp, parseHexColor(theme.cardBorderColorHex, Slate800))
                                        ) {
                                            Column {
                                                Box(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .height(100.dp)
                                                ) {
                                                    AsyncImage(
                                                        model = item.thumbnailUrl,
                                                        contentDescription = item.title,
                                                        contentScale = ContentScale.Crop,
                                                        modifier = Modifier.fillMaxSize()
                                                    )
                                                    Surface(
                                                        color = Color.Black.copy(alpha = 0.7f),
                                                        shape = RoundedCornerShape(4.dp),
                                                        modifier = Modifier
                                                            .align(Alignment.BottomEnd)
                                                            .padding(4.dp)
                                                    ) {
                                                        Text(item.duration, fontSize = 9.sp, color = Color.White, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                                                    }
                                                }
                                                Column(modifier = Modifier.padding(8.dp)) {
                                                    Text(item.title, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = textColor, maxLines = 1)
                                                    Text("👁️ ${item.viewsCount} • ${item.creatorName}", fontSize = 9.sp, color = textSecColor, maxLines = 1)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    "video_feed" -> {
                        item(key = "video_feed_header") {
                            Text(
                                section.title,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = textColor,
                                modifier = Modifier.padding(horizontal = 14.dp)
                            )
                        }

                        items(filteredVideos, key = { it.id }) { video ->
                            val isLiked = likedVideoIds.contains(video.id)
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp),
                                shape = RoundedCornerShape(cardRadius),
                                color = surfaceColor,
                                border = androidx.compose.foundation.BorderStroke(1.dp, parseHexColor(theme.cardBorderColorHex, Slate800))
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    // Creator Info Row
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        AsyncImage(
                                            model = video.creatorAvatar,
                                            contentDescription = video.creatorName,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier
                                                .size(36.dp)
                                                .clip(CircleShape)
                                        )
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(video.creatorName, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = textColor)
                                            Text("หมวด: ${video.category} • ยอดวิว ${video.viewsCount}", fontSize = 10.sp, color = textSecColor)
                                        }
                                        Surface(
                                            color = primaryColor.copy(alpha = 0.15f),
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Text("ติดตาม", color = primaryColor, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(video.title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = textColor)
                                    Spacer(modifier = Modifier.height(8.dp))

                                    // Video Player Container
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(180.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                            .clickable { activePlayingVideo = video }
                                    ) {
                                        AsyncImage(
                                            model = video.thumbnailUrl,
                                            contentDescription = video.title,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                        Box(
                                            modifier = Modifier
                                                .size(48.dp)
                                                .clip(CircleShape)
                                                .background(Color.Black.copy(alpha = 0.6f))
                                                .align(Alignment.Center),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = Color.White, modifier = Modifier.size(28.dp))
                                        }
                                        Surface(
                                            color = Color.Black.copy(alpha = 0.7f),
                                            shape = RoundedCornerShape(4.dp),
                                            modifier = Modifier
                                                .align(Alignment.BottomEnd)
                                                .padding(8.dp)
                                        ) {
                                            Text(video.duration, fontSize = 10.sp, color = Color.White, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))

                                    // Action buttons (Like, Comments, Share, Gift)
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                                modifier = Modifier.clickable {
                                                    likedVideoIds = if (isLiked) likedVideoIds - video.id else likedVideoIds + video.id
                                                }
                                            ) {
                                                Icon(
                                                    if (isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                                    contentDescription = "Like",
                                                    tint = if (isLiked) RosePrimary else textSecColor,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                                Text(
                                                    "${video.likesCount + if (isLiked) 1 else 0}",
                                                    fontSize = 11.sp,
                                                    color = if (isLiked) RosePrimary else textSecColor
                                                )
                                            }

                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                Icon(Icons.Default.ChatBubbleOutline, contentDescription = "Comment", tint = textSecColor, modifier = Modifier.size(18.dp))
                                                Text("ความคิดเห็น", fontSize = 11.sp, color = textSecColor)
                                            }
                                        }

                                        Button(
                                            onClick = onOpenCoins,
                                            colors = ButtonDefaults.buttonColors(containerColor = AmberGold),
                                            shape = RoundedCornerShape(10.dp),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                        ) {
                                            Text("🎁 ส่งของขวัญ", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Slate950)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Video Player Dialog if tapped
    if (activePlayingVideo != null) {
        val vid = activePlayingVideo!!
        AlertDialog(
            onDismissRequest = { activePlayingVideo = null },
            title = {
                Text(vid.title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                            .clip(RoundedCornerShape(12.dp))
                    ) {
                        AsyncImage(
                            model = vid.thumbnailUrl,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.Black.copy(alpha = 0.3f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.PlayCircleFilled, contentDescription = null, tint = PinkPrimary, modifier = Modifier.size(54.dp))
                        }
                    }
                    Text("กำลังเล่นวิดีโอแบบจำลองความคมชัดระดับ Full HD 1080p", fontSize = 11.sp, color = EmeraldGreen)
                    Text("ครีเอเตอร์: ${vid.creatorName} • หมวดหมู่: ${vid.category}", fontSize = 11.sp, color = Slate400)
                }
            },
            confirmButton = {
                Button(
                    onClick = { activePlayingVideo = null },
                    colors = ButtonDefaults.buttonColors(containerColor = primaryColor)
                ) {
                    Text("ปิดหน้าต่าง", color = Color.White)
                }
            },
            containerColor = Slate900
        )
    }
}
