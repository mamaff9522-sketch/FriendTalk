package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.*

@Composable
fun ReportDialog(
    isOpen: Boolean,
    targetType: String, // "user", "post", "live"
    targetId: String,
    targetName: String? = null,
    onClose: () -> Unit,
    onSubmitReport: (reason: String, details: String) -> Unit
) {
    if (!isOpen) return

    val reasons = remember {
        listOf(
            "สแปม โฆษณา หรือการหลอกลวง",
            "เนื้อหาอนาจารหรือไม่เหมาะสม",
            "การคุกคาม กลั่นแกล้ง หรือสร้างความเกลียดชัง",
            "การแอบอ้างเป็นบุคคลอื่น หรือบัญชีปลอม",
            "ความรุนแรง หรือพฤติกรรมที่เป็นอันตราย"
        )
    }

    var selectedReason by remember { mutableStateOf(reasons[0]) }
    var details by remember { mutableStateOf("") }
    var isSubmitted by remember { mutableStateOf(false) }

    val targetLabel = when (targetType) {
        "user" -> "ผู้ใช้"
        "post" -> "โพสต์"
        else -> "ห้องไลฟ์สด"
    }

    Dialog(onDismissRequest = onClose) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(28.dp),
            color = Slate900,
            border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Report,
                            contentDescription = null,
                            tint = RosePrimary,
                            modifier = Modifier.size(24.dp)
                        )
                        Column {
                            Text(
                                text = "รายงาน $targetLabel",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            if (targetName != null) {
                                Text(
                                    text = targetName,
                                    fontSize = 11.sp,
                                    color = Slate400
                                )
                            }
                        }
                    }
                    IconButton(onClick = onClose) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "ปิด",
                            tint = Slate400
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                if (isSubmitted) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = EmeraldGreen,
                            modifier = Modifier.size(50.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "ส่งรายงานเรียบร้อยแล้ว",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "ทีมผู้ดูแลความปลอดภัยจะเร่งตรวจสอบภายใน 24 ชม.",
                            fontSize = 12.sp,
                            color = Slate300
                        )
                    }
                } else {
                    Text(
                        text = "โปรดระบุสาเหตุที่ต้องการรายงาน:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = Slate300
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    reasons.forEach { r ->
                        val isSelected = selectedReason == r
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                                .clickable { selectedReason = r },
                            shape = RoundedCornerShape(10.dp),
                            color = if (isSelected) RosePrimary.copy(alpha = 0.15f) else Slate950,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSelected) RosePrimary else Slate800
                            )
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                RadioButton(
                                    selected = isSelected,
                                    onClick = { selectedReason = r },
                                    colors = RadioButtonDefaults.colors(selectedColor = RosePrimary)
                                )
                                Text(
                                    text = r,
                                    fontSize = 12.sp,
                                    color = if (isSelected) Color.White else Slate300
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = details,
                        onValueChange = { details = it },
                        label = { Text("รายละเอียดเพิ่มเติม (ไม่บังคับ)") },
                        placeholder = { Text("ระบุข้อเท็จจริงที่พบ...") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = RosePrimary,
                            unfocusedBorderColor = Slate800,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            onSubmitReport(selectedReason, details)
                            isSubmitted = true
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = RosePrimary)
                    ) {
                        Text(
                            text = "ส่งรายงาน",
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}
