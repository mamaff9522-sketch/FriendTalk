package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.companion.data.CompanionMockData
import com.example.companion.model.*
import com.example.companion.repository.CompanionRepository
import com.example.companion.repository.InMemoryCompanionRepository
import com.example.data.MockData
import com.example.model.*
import com.example.service.RemoteUiConfigManager
import com.example.service.SoundService
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class FriendTalkUiState(
    val currentUser: User = MockData.initialUsers[0],
    val users: List<User> = MockData.initialUsers,
    val posts: List<Post> = MockData.initialPosts,
    val stories: List<Story> = MockData.initialStories,
    val liveRooms: List<LiveRoom> = MockData.initialLiveRooms,
    val conversations: List<Conversation> = MockData.initialConversations,
    val messages: List<ChatMessage> = MockData.initialMessages,
    val clubs: List<Club> = MockData.initialClubs,
    val forumTopics: List<ForumTopic> = MockData.initialForumTopics,
    val reports: List<Report> = MockData.initialReports,
    val withdrawals: List<WithdrawalRequest> = MockData.initialWithdrawals,
    val adminLogs: List<AdminLog> = MockData.initialAdminLogs,
    val notifications: List<AppNotification> = MockData.initialNotifications,
    val permissions: AppPermissions = AppPermissions(),
    val followingIds: Set<String> = setOf("user_linlin", "user_arty", "user_fah"),
    val friendIds: Set<String> = setOf("user_linlin", "user_fah"),
    val blockedUserIds: Set<String> = setOf("user_spammer"),
    val activeTab: String = "home", // home, discover, live, chat, profile, companion
    val currentLiveRoomId: String? = null,
    val activeGiftAnimation: ActiveGiftAnimation? = null,
    val activeCall: CallSession? = null,
    val activeChatRoomId: String? = null,
    // Companion System States
    val companionProfiles: List<CompanionProfile> = CompanionMockData.initialProfiles,
    val companionPricingConfig: CompanionPricingConfig = CompanionPricingConfig(),
    val companionWallets: Map<String, CompanionWallet> = CompanionMockData.initialWallets,
    val companionGiftRequests: List<CompanionGiftRequest> = CompanionMockData.initialGiftRequests,
    val companionAuditLogs: List<CompanionAdminAuditLog> = CompanionMockData.initialAuditLogs,
    val companionSafetyReports: List<CompanionSafetyReport> = CompanionMockData.initialSafetyReports,
    val userKycInfo: KycVerificationInfo? = null,
    // Remote UI Config & Admin UI Builder States
    val uiConfig: AppUiConfig = AppUiConfig(),
    val configVersionHistory: List<ConfigVersionRecord> = emptyList(),
    val apkBuilds: List<ApkBuildRecord> = emptyList(),
    val isRefreshingConfig: Boolean = false
)

class FriendTalkViewModel : ViewModel() {

    private val companionRepository: CompanionRepository = InMemoryCompanionRepository()
    private val remoteUiConfigManager = RemoteUiConfigManager.getInstance()

    private val _uiState = MutableStateFlow(FriendTalkUiState())
    val uiState: StateFlow<FriendTalkUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            remoteUiConfigManager.activeConfig.collect { config ->
                _uiState.value = _uiState.value.copy(uiConfig = config)
            }
        }
        viewModelScope.launch {
            remoteUiConfigManager.versionHistory.collect { history ->
                _uiState.value = _uiState.value.copy(configVersionHistory = history)
            }
        }
        viewModelScope.launch {
            remoteUiConfigManager.apkBuilds.collect { builds ->
                _uiState.value = _uiState.value.copy(apkBuilds = builds)
            }
        }
        viewModelScope.launch {
            remoteUiConfigManager.isRefreshing.collect { refreshing ->
                _uiState.value = _uiState.value.copy(isRefreshingConfig = refreshing)
            }
        }
    }

    fun setActiveTab(tab: String) {
        // กฎข้อ 1: ผู้ใช้อายุต่ำกว่า 18 ปี ห้ามเห็นเมนู “เพื่อนคุย” และห้ามใช้ฟังก์ชันเพื่อนคุยทุกกรณี
        if (tab == "companion" && _uiState.value.currentUser.age < 18) {
            return
        }
        SoundService.playPop()
        _uiState.value = _uiState.value.copy(activeTab = tab)
    }

    fun setCurrentLiveRoomId(id: String?) {
        _uiState.value = _uiState.value.copy(currentLiveRoomId = id)
    }

    fun setActiveChatRoomId(id: String?) {
        _uiState.value = _uiState.value.copy(activeChatRoomId = id)
    }

    // --- Auth & Account ---
    fun switchUser(userId: String) {
        val user = _uiState.value.users.find { it.id == userId }
        if (user != null) {
            SoundService.playPop()
            _uiState.value = _uiState.value.copy(currentUser = user)
        }
    }

    fun registerUser(displayName: String, username: String, age: Int, gender: Gender) {
        val newUser = User(
            id = "user_${System.currentTimeMillis()}",
            username = username.lowercase().replace(" ", "_"),
            displayName = displayName,
            avatar = if (gender == Gender.FEMALE)
                "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80"
            else
                "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80",
            coverPhoto = "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&auto=format&fit=crop&q=80",
            age = age,
            gender = gender,
            bio = "สมาชิกใหม่ FriendTalk ยินดีที่ได้รู้จักทุกคนครับ/ค่ะ ✨",
            role = UserRole.USER,
            coins = 500, // Welcome bonus
            location = UserLocation("กรุงเทพมหานคร", 0.5, true),
            interests = listOf("หาเพื่อน", "แชต", "ดนตรี"),
            badges = listOf("สมาชิกใหม่ 🌱")
        )
        SoundService.playMatch()
        _uiState.value = _uiState.value.copy(
            users = listOf(newUser) + _uiState.value.users,
            currentUser = newUser
        )
    }

    fun updateProfile(displayName: String, bio: String, age: Int, gender: Gender, province: String, interests: List<String>) {
        val updatedUser = _uiState.value.currentUser.copy(
            displayName = displayName,
            bio = bio,
            age = age,
            gender = gender,
            location = _uiState.value.currentUser.location.copy(province = province),
            interests = interests
        )
        _uiState.value = _uiState.value.copy(
            currentUser = updatedUser,
            users = _uiState.value.users.map { if (it.id == updatedUser.id) updatedUser else it }
        )
        SoundService.playPop()
    }

    fun toggleLocationSharing() {
        val current = _uiState.value.currentUser
        val updated = current.copy(location = current.location.copy(isSharing = !current.location.isSharing))
        _uiState.value = _uiState.value.copy(
            currentUser = updated,
            users = _uiState.value.users.map { if (it.id == updated.id) updated else it }
        )
        SoundService.playPop()
    }

    fun updatePermissions(camera: Boolean, microphone: Boolean, geolocation: Boolean, notifications: Boolean) {
        _uiState.value = _uiState.value.copy(
            permissions = AppPermissions(camera, microphone, geolocation, notifications)
        )
        SoundService.playPop()
    }

    // --- Social & Friends ---
    fun toggleFollow(targetUserId: String) {
        val following = _uiState.value.followingIds.toMutableSet()
        val isFollowing = following.contains(targetUserId)
        if (isFollowing) following.remove(targetUserId) else following.add(targetUserId)

        val updatedUsers = _uiState.value.users.map { u ->
            if (u.id == targetUserId) {
                u.copy(followersCount = maxOf(0, u.followersCount + if (isFollowing) -1 else 1))
            } else if (u.id == _uiState.value.currentUser.id) {
                u.copy(followingCount = maxOf(0, u.followingCount + if (isFollowing) -1 else 1))
            } else u
        }

        val updatedCurrent = updatedUsers.find { it.id == _uiState.value.currentUser.id } ?: _uiState.value.currentUser
        _uiState.value = _uiState.value.copy(
            followingIds = following,
            users = updatedUsers,
            currentUser = updatedCurrent
        )
        SoundService.playPop()
    }

    fun toggleFriend(targetUserId: String) {
        val friends = _uiState.value.friendIds.toMutableSet()
        val isFriend = friends.contains(targetUserId)
        if (isFriend) friends.remove(targetUserId) else friends.add(targetUserId)

        val updatedUsers = _uiState.value.users.map { u ->
            if (u.id == targetUserId || u.id == _uiState.value.currentUser.id) {
                u.copy(friendsCount = maxOf(0, u.friendsCount + if (isFriend) -1 else 1))
            } else u
        }

        val updatedCurrent = updatedUsers.find { it.id == _uiState.value.currentUser.id } ?: _uiState.value.currentUser
        _uiState.value = _uiState.value.copy(
            friendIds = friends,
            users = updatedUsers,
            currentUser = updatedCurrent
        )
        SoundService.playMatch()
    }

    fun blockUser(targetUserId: String) {
        val blocked = _uiState.value.blockedUserIds.toMutableSet()
        blocked.add(targetUserId)
        val following = _uiState.value.followingIds.toMutableSet().apply { remove(targetUserId) }
        val friends = _uiState.value.friendIds.toMutableSet().apply { remove(targetUserId) }

        _uiState.value = _uiState.value.copy(
            blockedUserIds = blocked,
            followingIds = following,
            friendIds = friends
        )
        SoundService.playPop()
    }

    fun unblockUser(targetUserId: String) {
        val blocked = _uiState.value.blockedUserIds.toMutableSet()
        blocked.remove(targetUserId)
        _uiState.value = _uiState.value.copy(blockedUserIds = blocked)
        SoundService.playPop()
    }

    // --- Feed & Posts ---
    fun createPost(content: String, mediaUrls: List<String> = emptyList(), tags: List<String> = emptyList()) {
        val newPost = Post(
            id = "post_${System.currentTimeMillis()}",
            authorId = _uiState.value.currentUser.id,
            content = content,
            mediaUrls = mediaUrls,
            likes = emptyList(),
            commentsCount = 0,
            sharesCount = 0,
            createdAt = "เมื่อสักครู่",
            tags = tags
        )
        _uiState.value = _uiState.value.copy(
            posts = listOf(newPost) + _uiState.value.posts
        )
        SoundService.playMessage()
    }

    fun likePost(postId: String) {
        val currentUserId = _uiState.value.currentUser.id
        val updatedPosts = _uiState.value.posts.map { post ->
            if (post.id == postId) {
                val isLiked = post.likes.contains(currentUserId)
                val newLikes = if (isLiked) post.likes - currentUserId else post.likes + currentUserId
                post.copy(likes = newLikes)
            } else post
        }
        _uiState.value = _uiState.value.copy(posts = updatedPosts)
        SoundService.playHeart()
    }

    fun deletePost(postId: String) {
        _uiState.value = _uiState.value.copy(
            posts = _uiState.value.posts.filter { it.id != postId }
        )
        SoundService.playPop()
    }

    fun addStory(mediaUrl: String, caption: String? = null) {
        val newStory = Story(
            id = "story_${System.currentTimeMillis()}",
            authorId = _uiState.value.currentUser.id,
            mediaUrl = mediaUrl,
            caption = caption,
            createdAt = "เมื่อสักครู่"
        )
        _uiState.value = _uiState.value.copy(
            stories = listOf(newStory) + _uiState.value.stories
        )
        SoundService.playPop()
    }

    // --- Chat & Messaging ---
    fun sendMessage(
        conversationId: String,
        text: String,
        type: MessageType = MessageType.TEXT,
        mediaUrl: String? = null,
        disappearingSeconds: Int? = null,
        giftInfo: GiftInfo? = null
    ) {
        val newMsg = ChatMessage(
            id = "m_${System.currentTimeMillis()}",
            conversationId = conversationId,
            senderId = _uiState.value.currentUser.id,
            text = text,
            type = type,
            mediaUrl = mediaUrl,
            giftInfo = giftInfo,
            createdAt = "เมื่อสักครู่",
            isRead = false,
            disappearingSeconds = disappearingSeconds,
            selfDestructAt = if (disappearingSeconds != null && disappearingSeconds > 0)
                System.currentTimeMillis() + disappearingSeconds * 1000L else null
        )

        val updatedMessages = _uiState.value.messages + newMsg
        val updatedConvs = _uiState.value.conversations.map { conv ->
            if (conv.id == conversationId) {
                conv.copy(lastMessage = newMsg, updatedAt = "เมื่อสักครู่")
            } else conv
        }

        _uiState.value = _uiState.value.copy(
            messages = updatedMessages,
            conversations = updatedConvs
        )
        SoundService.playMessage()

        // Auto reply simulation for peer conversation
        val conv = updatedConvs.find { it.id == conversationId }
        if (conv != null && conv.type == "direct") {
            val otherId = conv.participantIds.find { it != _uiState.value.currentUser.id }
            if (otherId != null && otherId != "user_spammer") {
                viewModelScope.launch {
                    delay(1800)
                    val replies = listOf(
                        "ขอบคุณที่ทักมานะครับคุณ ${_uiState.value.currentUser.displayName}! วันนี้เป็นไงบ้างเอ่ย 😊",
                        "ยินดีที่ได้รู้จักครับ! สบายดีมั้ยครับ ✨",
                        "น่ารักจังเลยค่ะ ดีใจที่ได้เป็นเพื่อนกันใน FriendTalk น้า 💖",
                        "ช่วงนี้ฝนตกบ่อย ดูแลสุขภาพด้วยนะครับ ☕"
                    )
                    val replyMsg = ChatMessage(
                        id = "m_rep_${System.currentTimeMillis()}",
                        conversationId = conversationId,
                        senderId = otherId,
                        text = replies.random(),
                        createdAt = "เมื่อสักครู่"
                    )
                    _uiState.value = _uiState.value.copy(
                        messages = _uiState.value.messages + replyMsg,
                        conversations = _uiState.value.conversations.map { c ->
                            if (c.id == conversationId) {
                                val currentUnread = c.unreadCounts[_uiState.value.currentUser.id] ?: 0
                                c.copy(
                                    lastMessage = replyMsg,
                                    unreadCounts = c.unreadCounts + (_uiState.value.currentUser.id to (currentUnread + 1)),
                                    updatedAt = "เมื่อสักครู่"
                                )
                            } else c
                        }
                    )
                    SoundService.playMessage()
                }
            }
        }
    }

    fun startDirectChat(targetUserId: String): String {
        val existing = _uiState.value.conversations.find {
            it.type == "direct" &&
                    it.participantIds.contains(_uiState.value.currentUser.id) &&
                    it.participantIds.contains(targetUserId)
        }
        if (existing != null) {
            _uiState.value = _uiState.value.copy(activeChatRoomId = existing.id, activeTab = "chat")
            return existing.id
        }

        val newId = "conv_${System.currentTimeMillis()}"
        val newConv = Conversation(
            id = newId,
            type = "direct",
            participantIds = listOf(_uiState.value.currentUser.id, targetUserId),
            updatedAt = "เมื่อสักครู่"
        )
        _uiState.value = _uiState.value.copy(
            conversations = listOf(newConv) + _uiState.value.conversations,
            activeChatRoomId = newId,
            activeTab = "chat"
        )
        return newId
    }

    fun createGroupChat(name: String, participantIds: List<String>): String {
        val newId = "conv_grp_${System.currentTimeMillis()}"
        val allParticipants = (listOf(_uiState.value.currentUser.id) + participantIds).distinct()
        val newConv = Conversation(
            id = newId,
            type = "group",
            name = name,
            avatar = "https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=400&auto=format&fit=crop&q=80",
            participantIds = allParticipants,
            updatedAt = "เมื่อสักครู่",
            createdBy = _uiState.value.currentUser.id,
            groupAdmins = listOf(_uiState.value.currentUser.id),
            lastMessage = ChatMessage(
                id = "m_grp_init_${System.currentTimeMillis()}",
                conversationId = newId,
                senderId = _uiState.value.currentUser.id,
                text = "สร้างกลุ่ม \"$name\" สำเร็จ ชวนเพื่อนๆ มาร่วมคุยกัน",
                createdAt = "เมื่อสักครู่"
            )
        )
        _uiState.value = _uiState.value.copy(
            conversations = listOf(newConv) + _uiState.value.conversations,
            activeChatRoomId = newId
        )
        SoundService.playMatch()
        return newId
    }

    fun setDisappearingTimer(conversationId: String, seconds: Int) {
        _uiState.value = _uiState.value.copy(
            conversations = _uiState.value.conversations.map {
                if (it.id == conversationId) it.copy(disappearingTimerDefault = seconds) else it
            }
        )
        SoundService.playPop()
    }

    // --- Calls ---
    fun startCall(targetUserId: String, type: String = "audio") {
        SoundService.playPop()
        val call = CallSession(
            id = "call_${System.currentTimeMillis()}",
            type = type,
            callerId = _uiState.value.currentUser.id,
            receiverId = targetUserId,
            status = CallStatus.RINGING,
            startedAt = "เมื่อสักครู่"
        )
        _uiState.value = _uiState.value.copy(activeCall = call)

        viewModelScope.launch {
            delay(2500)
            if (_uiState.value.activeCall?.id == call.id) {
                _uiState.value = _uiState.value.copy(
                    activeCall = _uiState.value.activeCall?.copy(status = CallStatus.CONNECTED)
                )
            }
        }
    }

    fun endCall() {
        _uiState.value = _uiState.value.copy(activeCall = null)
        SoundService.playPop()
    }

    // --- Live Streaming ---
    fun createLiveRoom(title: String, category: String, isPk: Boolean = false): String {
        val newId = "live_${System.currentTimeMillis()}"
        val room = LiveRoom(
            id = newId,
            hostId = _uiState.value.currentUser.id,
            title = title,
            coverUrl = _uiState.value.currentUser.avatar,
            category = category,
            isLive = true,
            viewersCount = 1,
            isPkMode = isPk,
            pkOpponent = if (isPk) PkOpponent("user_linlin", 120, "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=500&auto=format&fit=crop&q=80") else null,
            startedAt = "เมื่อสักครู่"
        )
        _uiState.value = _uiState.value.copy(
            liveRooms = listOf(room) + _uiState.value.liveRooms,
            currentLiveRoomId = newId
        )
        SoundService.playGiftFanfare()
        return newId
    }

    fun endLiveRoom(roomId: String) {
        _uiState.value = _uiState.value.copy(
            liveRooms = _uiState.value.liveRooms.map {
                if (it.id == roomId) it.copy(isLive = false) else it
            },
            currentLiveRoomId = if (_uiState.value.currentLiveRoomId == roomId) null else _uiState.value.currentLiveRoomId
        )
        SoundService.playPop()
    }

    fun sendLiveHeart(roomId: String) {
        _uiState.value = _uiState.value.copy(
            liveRooms = _uiState.value.liveRooms.map {
                if (it.id == roomId) it.copy(heartsCount = it.heartsCount + 1) else it
            }
        )
        SoundService.playHeart()
    }

    fun sendLiveGift(roomId: String, gift: Gift): Boolean {
        if (_uiState.value.currentUser.coins < gift.coins) {
            return false
        }
        val room = _uiState.value.liveRooms.find { it.id == roomId } ?: return false
        val host = _uiState.value.users.find { it.id == room.hostId }

        val updatedCurrent = _uiState.value.currentUser.copy(
            coins = _uiState.value.currentUser.coins - gift.coins
        )
        val updatedUsers = _uiState.value.users.map { u ->
            if (u.id == updatedCurrent.id) updatedCurrent
            else if (u.id == room.hostId) {
                u.copy(
                    diamonds = u.diamonds + (gift.coins * 0.7).toInt(),
                    giftsReceivedTotal = u.giftsReceivedTotal + gift.coins
                )
            } else u
        }

        val updatedRooms = _uiState.value.liveRooms.map { r ->
            if (r.id == roomId) {
                r.copy(
                    currentGiftCoins = r.currentGiftCoins + gift.coins,
                    pkScore = r.pkScore + gift.coins
                )
            } else r
        }

        _uiState.value = _uiState.value.copy(
            currentUser = updatedCurrent,
            users = updatedUsers,
            liveRooms = updatedRooms,
            activeGiftAnimation = ActiveGiftAnimation(
                id = "anim_${System.currentTimeMillis()}",
                gift = gift,
                senderName = updatedCurrent.displayName,
                receiverName = host?.displayName ?: "โฮสต์"
            )
        )
        SoundService.playGiftFanfare()
        return true
    }

    fun clearGiftAnimation() {
        _uiState.value = _uiState.value.copy(activeGiftAnimation = null)
    }

    fun toggleLivePk(roomId: String) {
        _uiState.value = _uiState.value.copy(
            liveRooms = _uiState.value.liveRooms.map { r ->
                if (r.id == roomId) {
                    val nextPk = !r.isPkMode
                    r.copy(
                        isPkMode = nextPk,
                        pkScore = 0,
                        pkOpponent = if (nextPk) PkOpponent("user_arty", 500, "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=500&auto=format&fit=crop&q=80") else null
                    )
                } else r
            }
        )
        SoundService.playMatch()
    }

    fun muteLiveViewer(roomId: String, userId: String) {
        _uiState.value = _uiState.value.copy(
            liveRooms = _uiState.value.liveRooms.map { r ->
                if (r.id == roomId) r.copy(mutedUserIds = (r.mutedUserIds + userId).distinct()) else r
            }
        )
        SoundService.playPop()
    }

    fun kickLiveViewer(roomId: String, userId: String) {
        _uiState.value = _uiState.value.copy(
            liveRooms = _uiState.value.liveRooms.map { r ->
                if (r.id == roomId) r.copy(
                    bannedUserIds = (r.bannedUserIds + userId).distinct(),
                    viewersCount = maxOf(1, r.viewersCount - 1)
                ) else r
            }
        )
        SoundService.playPop()
    }

    // --- Economy & Wallet ---
    fun topUpCoins(amount: Int, priceBaht: Int) {
        val updatedCurrent = _uiState.value.currentUser.copy(
            coins = _uiState.value.currentUser.coins + amount
        )
        val notif = AppNotification(
            id = "notif_topup_${System.currentTimeMillis()}",
            userId = updatedCurrent.id,
            title = "เติมเหรียญสำเร็จ! 🪙",
            body = "คุณได้รับ ${amount} Coins (ยอดชำระ ฿${priceBaht}) พร้อมใช้งานแล้ว",
            type = "gift",
            linkTab = "profile"
        )

        _uiState.value = _uiState.value.copy(
            currentUser = updatedCurrent,
            users = _uiState.value.users.map { if (it.id == updatedCurrent.id) updatedCurrent else it },
            notifications = listOf(notif) + _uiState.value.notifications
        )
        SoundService.playCoin()
    }

    fun requestWithdrawal(amountCoins: Int, bankName: String, accountNumber: String, accountName: String): Boolean {
        if (_uiState.value.currentUser.diamonds < amountCoins) return false

        val baht = (amountCoins * 0.5).toInt()
        val req = WithdrawalRequest(
            id = "wd_${System.currentTimeMillis()}",
            creatorId = _uiState.value.currentUser.id,
            amountCoins = amountCoins,
            amountBaht = baht,
            bankName = bankName,
            accountNumber = accountNumber,
            accountName = accountName,
            status = "pending",
            createdAt = "เมื่อสักครู่"
        )
        val updatedCurrent = _uiState.value.currentUser.copy(
            diamonds = _uiState.value.currentUser.diamonds - amountCoins
        )
        _uiState.value = _uiState.value.copy(
            currentUser = updatedCurrent,
            users = _uiState.value.users.map { if (it.id == updatedCurrent.id) updatedCurrent else it },
            withdrawals = listOf(req) + _uiState.value.withdrawals
        )
        SoundService.playPop()
        return true
    }

    // --- Clubs & Forums ---
    fun joinClub(clubId: String) {
        _uiState.value = _uiState.value.copy(
            clubs = _uiState.value.clubs.map { club ->
                if (club.id == clubId && !club.members.contains(_uiState.value.currentUser.id)) {
                    club.copy(
                        members = club.members + _uiState.value.currentUser.id,
                        memberCount = club.memberCount + 1
                    )
                } else club
            }
        )
        SoundService.playMatch()
    }

    fun leaveClub(clubId: String) {
        _uiState.value = _uiState.value.copy(
            clubs = _uiState.value.clubs.map { club ->
                if (club.id == clubId && club.members.contains(_uiState.value.currentUser.id)) {
                    club.copy(
                        members = club.members - _uiState.value.currentUser.id,
                        memberCount = maxOf(0, club.memberCount - 1)
                    )
                } else club
            }
        )
        SoundService.playPop()
    }

    fun createForumTopic(clubId: String, title: String, content: String) {
        val topic = ForumTopic(
            id = "topic_${System.currentTimeMillis()}",
            clubId = clubId,
            authorId = _uiState.value.currentUser.id,
            title = title,
            content = content,
            createdAt = "เมื่อสักครู่"
        )
        _uiState.value = _uiState.value.copy(
            forumTopics = listOf(topic) + _uiState.value.forumTopics
        )
        SoundService.playMessage()
    }

    // --- Moderation & Reports ---
    fun createReport(targetType: String, targetId: String, reason: String, details: String? = null) {
        val report = Report(
            id = "rep_${System.currentTimeMillis()}",
            reporterId = _uiState.value.currentUser.id,
            targetType = targetType,
            targetId = targetId,
            reason = reason,
            details = details,
            status = "pending",
            createdAt = "เมื่อสักครู่"
        )
        _uiState.value = _uiState.value.copy(
            reports = listOf(report) + _uiState.value.reports
        )
        SoundService.playPop()
    }

    // --- Admin Tools ---
    fun adminSuspendUser(userId: String, suspend: Boolean) {
        _uiState.value = _uiState.value.copy(
            users = _uiState.value.users.map { if (it.id == userId) it.copy(isSuspended = suspend) else it },
            adminLogs = listOf(
                AdminLog(
                    id = "log_${System.currentTimeMillis()}",
                    adminId = _uiState.value.currentUser.id,
                    adminName = _uiState.value.currentUser.displayName,
                    action = if (suspend) "ระงับการใช้งานบัญชี" else "ปลดการระงับบัญชี",
                    targetType = "user",
                    targetId = userId,
                    details = "ผู้ใช้ถูก ${if (suspend) "ระงับชั่วคราว" else "ปลดระงับ"}"
                )
            ) + _uiState.value.adminLogs
        )
        SoundService.playPop()
    }

    fun adminBanUser(userId: String, ban: Boolean) {
        _uiState.value = _uiState.value.copy(
            users = _uiState.value.users.map { if (it.id == userId) it.copy(isBanned = ban) else it },
            adminLogs = listOf(
                AdminLog(
                    id = "log_${System.currentTimeMillis()}",
                    adminId = _uiState.value.currentUser.id,
                    adminName = _uiState.value.currentUser.displayName,
                    action = if (ban) "แบนบัญชีถาวร" else "ปลดแบนบัญชี",
                    targetType = "user",
                    targetId = userId,
                    details = "ผู้ใช้ถูก ${if (ban) "แบนถาวร" else "ปลดแบน"}"
                )
            ) + _uiState.value.adminLogs
        )
        SoundService.playPop()
    }

    fun adminChangeRole(userId: String, role: UserRole) {
        _uiState.value = _uiState.value.copy(
            users = _uiState.value.users.map { if (it.id == userId) it.copy(role = role) else it },
            adminLogs = listOf(
                AdminLog(
                    id = "log_${System.currentTimeMillis()}",
                    adminId = _uiState.value.currentUser.id,
                    adminName = _uiState.value.currentUser.displayName,
                    action = "เปลี่ยนสิทธิ์ผู้ใช้",
                    targetType = "user",
                    targetId = userId,
                    details = "เปลี่ยนเป็น $role"
                )
            ) + _uiState.value.adminLogs
        )
        SoundService.playPop()
    }

    fun adminReviewReport(reportId: String, action: String, note: String? = null) {
        _uiState.value = _uiState.value.copy(
            reports = _uiState.value.reports.map {
                if (it.id == reportId) it.copy(status = action, actionNote = note) else it
            },
            adminLogs = listOf(
                AdminLog(
                    id = "log_${System.currentTimeMillis()}",
                    adminId = _uiState.value.currentUser.id,
                    adminName = _uiState.value.currentUser.displayName,
                    action = "ตรวจสอบรายงาน",
                    targetType = "report",
                    targetId = reportId,
                    details = "สถานะ: $action, โน้ต: ${note ?: "-"}"
                )
            ) + _uiState.value.adminLogs
        )
        SoundService.playPop()
    }

    fun adminReviewWithdrawal(withdrawalId: String, status: String) {
        _uiState.value = _uiState.value.copy(
            withdrawals = _uiState.value.withdrawals.map {
                if (it.id == withdrawalId) it.copy(status = status, adminNote = "ดำเนินการเรียบร้อย") else it
            },
            adminLogs = listOf(
                AdminLog(
                    id = "log_${System.currentTimeMillis()}",
                    adminId = _uiState.value.currentUser.id,
                    adminName = _uiState.value.currentUser.displayName,
                    action = "ตรวจสอบคำขอถอนเงิน",
                    targetType = "withdrawal",
                    targetId = withdrawalId,
                    details = "ผลการตรวจสอบ: $status"
                )
            ) + _uiState.value.adminLogs
        )
        SoundService.playPop()
    }

    fun adminBroadcastNotification(title: String, body: String) {
        val notif = AppNotification(
            id = "notif_broadcast_${System.currentTimeMillis()}",
            userId = "all",
            title = "📢 $title",
            body = body,
            type = "system",
            linkTab = "home"
        )
        _uiState.value = _uiState.value.copy(
            notifications = listOf(notif) + _uiState.value.notifications,
            adminLogs = listOf(
                AdminLog(
                    id = "log_${System.currentTimeMillis()}",
                    adminId = _uiState.value.currentUser.id,
                    adminName = _uiState.value.currentUser.displayName,
                    action = "ส่งข้อความประกาศ Push Notification",
                    targetType = "system",
                    targetId = "broadcast",
                    details = "หัวข้อ: $title"
                )
            ) + _uiState.value.adminLogs
        )
        SoundService.playMessage()
    }

    fun adminTerminateLive(roomId: String) {
        endLiveRoom(roomId)
        _uiState.value = _uiState.value.copy(
            adminLogs = listOf(
                AdminLog(
                    id = "log_${System.currentTimeMillis()}",
                    adminId = _uiState.value.currentUser.id,
                    adminName = _uiState.value.currentUser.displayName,
                    action = "สั่งปิดห้องไลฟ์ทันที",
                    targetType = "live",
                    targetId = roomId,
                    details = "ปิดห้องไลฟ์เนื่องจากละเมิดกฎชุมชน"
                )
            ) + _uiState.value.adminLogs
        )
        SoundService.playPop()
    }

    fun markNotificationsAsRead() {
        _uiState.value = _uiState.value.copy(
            notifications = _uiState.value.notifications.map { it.copy(isRead = true) }
        )
    }

    // --- Companion ("เพื่อนคุย") Actions ---

    fun completeUserKyc(kycInfo: KycVerificationInfo) {
        val updatedUser = _uiState.value.currentUser.copy(isVerified = true)
        _uiState.value = _uiState.value.copy(
            currentUser = updatedUser,
            userKycInfo = kycInfo,
            users = _uiState.value.users.map { if (it.id == updatedUser.id) updatedUser else it }
        )
    }

    fun deductUserCoins(coinsToDeduct: Int) {
        if (coinsToDeduct <= 0) return
        val updatedUser = _uiState.value.currentUser.copy(
            coins = maxOf(0, _uiState.value.currentUser.coins - coinsToDeduct)
        )
        _uiState.value = _uiState.value.copy(
            currentUser = updatedUser,
            users = _uiState.value.users.map { if (it.id == updatedUser.id) updatedUser else it }
        )
    }

    fun applyAsCompanion(profile: CompanionProfile) {
        // กฎข้อ 1 & 2: ต้องอายุ 18 ปีขึ้นไป และยืนยันตัวตนเรียบร้อยก่อน
        if (_uiState.value.currentUser.age < 18) return
        companionRepository.applyAsCompanion(profile)
        _uiState.value = _uiState.value.copy(companionProfiles = companionRepository.profiles.value)
    }

    fun adminApproveCompanion(companionId: String, justification: String) {
        companionRepository.adminApproveCompanion(
            companionId = companionId,
            adminId = _uiState.value.currentUser.id,
            adminName = _uiState.value.currentUser.displayName,
            justification = justification
        )
        _uiState.value = _uiState.value.copy(
            companionProfiles = companionRepository.profiles.value,
            companionAuditLogs = companionRepository.auditLogs.value
        )
    }

    fun adminRejectCompanion(companionId: String, reason: String) {
        companionRepository.adminRejectCompanion(
            companionId = companionId,
            adminId = _uiState.value.currentUser.id,
            adminName = _uiState.value.currentUser.displayName,
            reason = reason
        )
        _uiState.value = _uiState.value.copy(
            companionProfiles = companionRepository.profiles.value,
            companionAuditLogs = companionRepository.auditLogs.value
        )
    }

    fun adminSuspendCompanion(companionId: String, reason: String) {
        companionRepository.adminSuspendCompanion(
            companionId = companionId,
            adminId = _uiState.value.currentUser.id,
            adminName = _uiState.value.currentUser.displayName,
            reason = reason
        )
        _uiState.value = _uiState.value.copy(
            companionProfiles = companionRepository.profiles.value,
            companionAuditLogs = companionRepository.auditLogs.value
        )
    }

    fun updateCompanionRates(level: CompanionLevel, text: Int, voice: Int, video: Int, reason: String) {
        companionRepository.updatePricingRates(
            level = level,
            text = text,
            voice = voice,
            video = video,
            adminId = _uiState.value.currentUser.id,
            adminName = _uiState.value.currentUser.displayName,
            reason = reason
        )
        _uiState.value = _uiState.value.copy(
            companionPricingConfig = companionRepository.pricingConfig.value,
            companionAuditLogs = companionRepository.auditLogs.value
        )
    }

    fun recalculateCompanionLevel(companionId: String) {
        companionRepository.recalculateLevel(companionId)
        _uiState.value = _uiState.value.copy(companionProfiles = companionRepository.profiles.value)
    }

    fun sendCompanionGiftRequest(request: CompanionGiftRequest) {
        if (_uiState.value.currentUser.coins < request.gift.coins) return
        deductUserCoins(request.gift.coins)
        companionRepository.sendGiftRequest(request)
        _uiState.value = _uiState.value.copy(companionGiftRequests = companionRepository.giftRequests.value)
    }

    fun respondCompanionGiftRequest(requestId: String, accept: Boolean): Pair<Boolean, CompanionGiftRequest?> {
        val result = companionRepository.respondGiftRequest(requestId, accept)
        _uiState.value = _uiState.value.copy(
            companionGiftRequests = companionRepository.giftRequests.value,
            companionWallets = companionRepository.wallets.value
        )
        return result
    }

    fun completeCompanionSession(
        session: CompanionSession,
        earnings: Int,
        rating: Int?,
        comment: String?
    ) {
        companionRepository.creditSessionEarning(session.companionId, session, earnings)
        _uiState.value = _uiState.value.copy(
            companionProfiles = companionRepository.profiles.value,
            companionWallets = companionRepository.wallets.value
        )
    }

    fun companionWithdrawal(
        companionId: String,
        companionName: String,
        amountCoins: Int,
        bankAccount: CompanionBankAccount
    ): Boolean {
        val success = companionRepository.requestWithdrawal(companionId, companionName, amountCoins, bankAccount)
        if (success) {
            _uiState.value = _uiState.value.copy(companionWallets = companionRepository.wallets.value)
        }
        return success
    }

    fun logCompanionAdminAudit(action: String, targetType: String, targetId: String, justification: String) {
        companionRepository.logAdminAudit(
            adminId = _uiState.value.currentUser.id,
            adminName = _uiState.value.currentUser.displayName,
            action = action,
            targetType = targetType,
            targetId = targetId,
            reason = justification
        )
        _uiState.value = _uiState.value.copy(companionAuditLogs = companionRepository.auditLogs.value)
    }

    // --- Admin UI Builder & Remote UI Config ---
    fun saveDraftUiConfig(config: AppUiConfig) {
        if (!isAdminUser()) return
        remoteUiConfigManager.saveDraft(config)
    }

    fun publishUiConfig(config: AppUiConfig, author: String, notes: String) {
        if (!isAdminUser()) return
        remoteUiConfigManager.publish(config, author, notes)
        SoundService.playSuccess()
    }

    fun rollbackUiConfig(version: String, author: String) {
        if (!isAdminUser()) return
        val success = remoteUiConfigManager.rollbackTo(version, author)
        if (success) {
            SoundService.playSuccess()
        }
    }

    fun restoreDefaultUiConfig(author: String) {
        if (!isAdminUser()) return
        remoteUiConfigManager.restoreDefault(author)
        SoundService.playSuccess()
    }

    fun refreshRemoteUiConfig() {
        viewModelScope.launch {
            SoundService.playPop()
            val success = remoteUiConfigManager.refreshRemoteConfig()
            if (success) {
                SoundService.playSuccess()
            }
        }
    }

    fun triggerNewApkBuild(versionName: String, notes: String) {
        if (!isAdminUser()) return
        remoteUiConfigManager.addNewApkBuild(versionName, notes)
        SoundService.playSuccess()
    }

    private fun isAdminUser(): Boolean {
        val role = _uiState.value.currentUser.role
        return role == UserRole.ADMIN || role == UserRole.SUPERADMIN
    }
}
