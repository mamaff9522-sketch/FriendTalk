package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.companion.ui.CompanionMainScreen
import com.example.model.parseHexColor
import com.example.ui.admin.AdminDashboardDialog
import com.example.ui.admin.AdminUiBuilderDialog
import com.example.ui.admin.ApkDownloadDialog
import com.example.ui.chat.ChatTab
import com.example.ui.components.*
import com.example.ui.discover.DiscoverTab
import com.example.ui.feed.FeedTab
import com.example.ui.live.LiveTab
import com.example.ui.movie.MovieTab
import com.example.ui.profile.ProfileTab
import com.example.ui.theme.FriendTalkTheme
import com.example.ui.theme.Slate950
import com.example.viewmodel.FriendTalkViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            FriendTalkApp()
        }
    }
}

@Composable
fun FriendTalkApp(
    viewModel: FriendTalkViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    var isCoinsOpen by remember { mutableStateOf(false) }
    var isNotifsOpen by remember { mutableStateOf(false) }
    var isAuthOpen by remember { mutableStateOf(false) }
    var isPermissionsOpen by remember { mutableStateOf(false) }
    var isAdminDashboardOpen by remember { mutableStateOf(false) }
    var isUiBuilderOpen by remember { mutableStateOf(false) }
    var isApkDownloadOpen by remember { mutableStateOf(false) }

    val unreadNotificationsCount = uiState.notifications.count { !it.isRead }
    val totalUnreadMessages = uiState.conversations.sumOf { it.unreadCounts[uiState.currentUser.id] ?: 0 }
    val activeLiveCount = uiState.liveRooms.count { it.isLive }

    val appBgColor = parseHexColor(uiState.uiConfig.theme.backgroundColorHex, Slate950)

    FriendTalkTheme(themeConfig = uiState.uiConfig.theme) {
        Scaffold(
            modifier = Modifier
                .fillMaxSize()
                .background(appBgColor),
            topBar = {
                AppHeader(
                    currentUser = uiState.currentUser,
                    unreadNotificationsCount = unreadNotificationsCount,
                    onOpenCoins = { isCoinsOpen = true },
                    onOpenNotifications = { isNotifsOpen = true },
                    onOpenAuth = { isAuthOpen = true },
                    onOpenPermissions = { isPermissionsOpen = true },
                    onToggleLocationSharing = { viewModel.toggleLocationSharing() },
                    uiConfig = uiState.uiConfig,
                    onRefreshConfig = { viewModel.refreshRemoteUiConfig() },
                    isRefreshing = uiState.isRefreshingConfig,
                    onOpenAdminDashboard = { isAdminDashboardOpen = true },
                    onOpenUiBuilder = { isUiBuilderOpen = true },
                    onOpenApkDownload = { isApkDownloadOpen = true }
                )
            },
            bottomBar = {
                BottomNavBar(
                    activeTab = uiState.activeTab,
                    onTabSelected = { viewModel.setActiveTab(it) },
                    totalUnreadMessages = totalUnreadMessages,
                    activeLiveCount = activeLiveCount,
                    currentUserAge = uiState.currentUser.age,
                    uiConfig = uiState.uiConfig
                )
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(appBgColor)
            ) {
                when (uiState.activeTab) {
                    "home" -> FeedTab(
                        currentUser = uiState.currentUser,
                        users = uiState.users,
                        posts = uiState.posts,
                        stories = uiState.stories,
                        clubs = uiState.clubs,
                        forumTopics = uiState.forumTopics,
                        followingIds = uiState.followingIds,
                        onToggleFollow = { viewModel.toggleFollow(it) },
                        onLikePost = { viewModel.likePost(it) },
                        onDeletePost = { viewModel.deletePost(it) },
                        onCreatePost = { content, urls, tags -> viewModel.createPost(content, urls, tags) },
                        onAddStory = { url, cap -> viewModel.addStory(url, cap) },
                        onJoinClub = { viewModel.joinClub(it) },
                        onLeaveClub = { viewModel.leaveClub(it) },
                        onCreateTopic = { id, title, content -> viewModel.createForumTopic(id, title, content) },
                        onCreateReport = { type, id, reason, details -> viewModel.createReport(type, id, reason, details) }
                    )

                    "discover" -> DiscoverTab(
                        currentUser = uiState.currentUser,
                        users = uiState.users,
                        friendIds = uiState.friendIds,
                        onToggleFriend = { viewModel.toggleFriend(it) },
                        onStartChat = { viewModel.startDirectChat(it) },
                        onToggleLocationSharing = { viewModel.toggleLocationSharing() }
                    )

                    "live" -> LiveTab(
                        currentUser = uiState.currentUser,
                        users = uiState.users,
                        liveRooms = uiState.liveRooms,
                        followingIds = uiState.followingIds,
                        currentLiveRoomId = uiState.currentLiveRoomId,
                        onOpenLiveRoom = { viewModel.setCurrentLiveRoomId(it) },
                        onCloseLiveRoom = { viewModel.setCurrentLiveRoomId(null) },
                        onStartLive = { title, cat, pk -> viewModel.createLiveRoom(title, cat, pk) },
                        onEndLive = { viewModel.endLiveRoom(it) },
                        onSendHeart = { viewModel.sendLiveHeart(it) },
                        onSendGift = { id, gift -> viewModel.sendLiveGift(id, gift) },
                        onTogglePk = { viewModel.toggleLivePk(it) },
                        onMuteViewer = { rId, uId -> viewModel.muteLiveViewer(rId, uId) },
                        onKickViewer = { rId, uId -> viewModel.kickLiveViewer(rId, uId) },
                        onToggleFollow = { viewModel.toggleFollow(it) },
                        onOpenCoins = { isCoinsOpen = true },
                        onCreateReport = { type, id, reason, details -> viewModel.createReport(type, id, reason, details) }
                    )

                    "movie" -> MovieTab(
                        currentUser = uiState.currentUser,
                        uiConfig = uiState.uiConfig,
                        onOpenCoins = { isCoinsOpen = true }
                    )

                    "chat" -> ChatTab(
                        currentUser = uiState.currentUser,
                        users = uiState.users,
                        conversations = uiState.conversations,
                        messages = uiState.messages,
                        activeCall = uiState.activeCall,
                        activeChatRoomId = uiState.activeChatRoomId,
                        onOpenChatRoom = { viewModel.setActiveChatRoomId(it) },
                        onCloseChatRoom = { viewModel.setActiveChatRoomId(null) },
                        onSendMessage = { text, type, url, timer, gift -> viewModel.sendMessage(uiState.activeChatRoomId ?: "", text, type, url, timer, gift) },
                        onSetDisappearingTimer = { viewModel.setDisappearingTimer(uiState.activeChatRoomId ?: "", it) },
                        onCreateGroup = { name, ids -> viewModel.createGroupChat(name, ids) },
                        onStartCall = { id, type -> viewModel.startCall(id, type) },
                        onEndCall = { viewModel.endCall() },
                        onBlockUser = { viewModel.blockUser(it) },
                        onCreateReport = { type, id, reason, details -> viewModel.createReport(type, id, reason, details) }
                    )

                    "profile" -> ProfileTab(
                        currentUser = uiState.currentUser,
                        users = uiState.users,
                        liveRooms = uiState.liveRooms,
                        reports = uiState.reports,
                        withdrawals = uiState.withdrawals,
                        adminLogs = uiState.adminLogs,
                        permissions = uiState.permissions,
                        blockedUserIds = uiState.blockedUserIds,
                        onUnblockUser = { viewModel.unblockUser(it) },
                        onSaveProfile = { name, bio, age, gender, prov, tags -> viewModel.updateProfile(name, bio, age, gender, prov, tags) },
                        onTopUpCoins = { amt, price -> viewModel.topUpCoins(amt, price) },
                        onRequestWithdrawal = { amt, bank, acc, name -> viewModel.requestWithdrawal(amt, bank, acc, name) },
                        onToggleLocationSharing = { viewModel.toggleLocationSharing() },
                        onUpdatePermissions = { c, m, g, n -> viewModel.updatePermissions(c, m, g, n) },
                        onSwitchUser = { viewModel.switchUser(it) },
                        onRegisterUser = { name, uName, age, gender -> viewModel.registerUser(name, uName, age, gender) },
                        onSuspendUser = { id, s -> viewModel.adminSuspendUser(id, s) },
                        onBanUser = { id, b -> viewModel.adminBanUser(id, b) },
                        onChangeRole = { id, r -> viewModel.adminChangeRole(id, r) },
                        onReviewReport = { id, a, n -> viewModel.adminReviewReport(id, a, n) },
                        onReviewWithdrawal = { id, s -> viewModel.adminReviewWithdrawal(id, s) },
                        onBroadcastNotification = { t, b -> viewModel.adminBroadcastNotification(t, b) },
                        onTerminateLive = { viewModel.adminTerminateLive(it) },
                        onDeletePost = { viewModel.deletePost(it) },
                        onNavigateToCompanion = { viewModel.setActiveTab("companion") },
                        onOpenAdminDashboard = { isAdminDashboardOpen = true },
                        onOpenUiBuilder = { isUiBuilderOpen = true },
                        onOpenApkDownload = { isApkDownloadOpen = true }
                    )

                    "companion" -> CompanionMainScreen(
                        currentUser = uiState.currentUser,
                        profiles = uiState.companionProfiles,
                        pricingConfig = uiState.companionPricingConfig,
                        wallets = uiState.companionWallets,
                        giftRequests = uiState.companionGiftRequests,
                        auditLogs = uiState.companionAuditLogs,
                        safetyReports = uiState.companionSafetyReports,
                        userKycInfo = uiState.userKycInfo,
                        onOpenCoinTopUp = { isCoinsOpen = true },
                        onDeductCoinsFromUser = { viewModel.deductUserCoins(it) },
                        onApplyCompanion = { viewModel.applyAsCompanion(it) },
                        onApproveCompanion = { id, r -> viewModel.adminApproveCompanion(id, r) },
                        onRejectCompanion = { id, r -> viewModel.adminRejectCompanion(id, r) },
                        onSuspendCompanion = { id, r -> viewModel.adminSuspendCompanion(id, r) },
                        onUpdateRates = { l, t, v, vi, r -> viewModel.updateCompanionRates(l, t, v, vi, r) },
                        onRecalculateLevel = { viewModel.recalculateCompanionLevel(it) },
                        onSendGiftRequest = { viewModel.sendCompanionGiftRequest(it) },
                        onRespondGiftRequest = { id, a -> viewModel.respondCompanionGiftRequest(id, a) },
                        onSessionCompleted = { s, e, r, c -> viewModel.completeCompanionSession(s, e, r, c) },
                        onCompanionWithdrawal = { id, n, a, b -> viewModel.companionWithdrawal(id, n, a, b) },
                        onLogAdminAudit = { a, t, i, j -> viewModel.logCompanionAdminAudit(a, t, i, j) },
                        onKycCompleted = { viewModel.completeUserKyc(it) }
                    )
                }
            }
        }

        // Global Overlays & Dialogs
        GiftAnimationOverlay(
            animation = uiState.activeGiftAnimation,
            onDismiss = { viewModel.clearGiftAnimation() }
        )

        NotificationDrawer(
            isOpen = isNotifsOpen,
            notifications = uiState.notifications,
            onClose = { isNotifsOpen = false },
            onMarkAllRead = { viewModel.markNotificationsAsRead() },
            onNavigateTab = {
                viewModel.setActiveTab(it)
                isNotifsOpen = false
            }
        )

        PermissionDialog(
            isOpen = isPermissionsOpen,
            currentUser = uiState.currentUser,
            permissions = uiState.permissions,
            onClose = { isPermissionsOpen = false },
            onToggleLocationSharing = { viewModel.toggleLocationSharing() },
            onUpdatePermissions = { c, m, g, n -> viewModel.updatePermissions(c, m, g, n) }
        )

        AuthDialog(
            isOpen = isAuthOpen,
            currentUser = uiState.currentUser,
            users = uiState.users,
            onClose = { isAuthOpen = false },
            onSwitchUser = { viewModel.switchUser(it) },
            onRegisterUser = { name, uName, age, gender -> viewModel.registerUser(name, uName, age, gender) }
        )

        CoinWalletDialog(
            isOpen = isCoinsOpen,
            currentUser = uiState.currentUser,
            onClose = { isCoinsOpen = false },
            onTopUpCoins = { amt, price -> viewModel.topUpCoins(amt, price) }
        )

        // Single Canonical Admin Dashboard Dialog
        AdminDashboardDialog(
            isOpen = isAdminDashboardOpen,
            currentUser = uiState.currentUser,
            users = uiState.users,
            liveRooms = uiState.liveRooms,
            reports = uiState.reports,
            withdrawals = uiState.withdrawals,
            adminLogs = uiState.adminLogs,
            onClose = { isAdminDashboardOpen = false },
            onSuspendUser = { id, s -> viewModel.adminSuspendUser(id, s) },
            onBanUser = { id, b -> viewModel.adminBanUser(id, b) },
            onChangeRole = { id, r -> viewModel.adminChangeRole(id, r) },
            onReviewReport = { id, a, n -> viewModel.adminReviewReport(id, a, n) },
            onReviewWithdrawal = { id, s -> viewModel.adminReviewWithdrawal(id, s) },
            onBroadcastNotification = { t, b -> viewModel.adminBroadcastNotification(t, b) },
            onTerminateLive = { viewModel.adminTerminateLive(it) },
            onDeletePost = { viewModel.deletePost(it) },
            onOpenUiBuilder = { isUiBuilderOpen = true },
            onOpenApkDownload = { isApkDownloadOpen = true }
        )

        // Admin UI Builder Dialog
        AdminUiBuilderDialog(
            isOpen = isUiBuilderOpen,
            currentUser = uiState.currentUser,
            activeConfig = uiState.uiConfig,
            versionHistory = uiState.configVersionHistory,
            onClose = { isUiBuilderOpen = false },
            onSaveDraft = { viewModel.saveDraftUiConfig(it) },
            onPublishConfig = { config, author, notes -> viewModel.publishUiConfig(config, author, notes) },
            onRollbackTo = { ver, author -> viewModel.rollbackUiConfig(ver, author) },
            onRestoreDefault = { author -> viewModel.restoreDefaultUiConfig(author) },
            onOpenApkDownload = { isApkDownloadOpen = true }
        )

        // Admin APK Download Dialog
        ApkDownloadDialog(
            isOpen = isApkDownloadOpen,
            currentUser = uiState.currentUser,
            apkBuilds = uiState.apkBuilds,
            onClose = { isApkDownloadOpen = false },
            onTriggerNewBuild = { ver, notes -> viewModel.triggerNewApkBuild(ver, notes) }
        )
    }
}
