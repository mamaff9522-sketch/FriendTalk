package com.example

import com.example.companion.model.*
import com.example.companion.repository.InMemoryCompanionRepository
import com.example.companion.service.CompanionLevelCalculator
import com.example.companion.service.CompanionModerationService
import com.example.companion.service.CompanionSessionManager
import com.example.companion.service.CompanionWalletService
import com.example.data.MockData
import com.example.model.Gender
import com.example.model.User
import com.example.model.UserRole
import com.example.viewmodel.FriendTalkViewModel
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class CompanionSystemUnitTest {

    private lateinit var viewModel: FriendTalkViewModel
    private lateinit var repository: InMemoryCompanionRepository
    private lateinit var sessionManager: CompanionSessionManager
    private lateinit var walletService: CompanionWalletService
    private lateinit var moderationService: CompanionModerationService

    @Before
    fun setup() {
        viewModel = FriendTalkViewModel()
        repository = InMemoryCompanionRepository()
        sessionManager = CompanionSessionManager()
        walletService = CompanionWalletService()
        moderationService = CompanionModerationService()
    }

    @Test
    fun testUnder18AgeRestriction() {
        // Switch to under-18 user (nong khao, age 16)
        viewModel.switchUser("user_nong_khao")
        val currentUser = viewModel.uiState.value.currentUser
        assertEquals(16, currentUser.age)
        assertTrue(currentUser.age < 18)

        // Attempting to set activeTab to "companion" must be blocked
        viewModel.setActiveTab("companion")
        assertNotEquals("companion", viewModel.uiState.value.activeTab)

        // Attempting to apply as companion for an under-18 user must be rejected
        val under18Profile = CompanionProfile(
            id = "comp_under18",
            userId = currentUser.id,
            displayName = currentUser.displayName,
            avatar = currentUser.avatar,
            age = 16,
            introBio = "อยากเป็นเพื่อนคุย",
            status = CompanionStatus.PENDING_REVIEW
        )
        viewModel.applyAsCompanion(under18Profile)
        assertNull(viewModel.uiState.value.companionProfiles.find { it.userId == "user_nong_khao" })
    }

    @Test
    fun testCompanionApplicationStartsInPendingReview() {
        // Adult user (age 24)
        viewModel.switchUser("user_me")
        val adult = viewModel.uiState.value.currentUser
        assertTrue(adult.age >= 18)

        val newProfile = CompanionProfile(
            id = "comp_user_me",
            userId = adult.id,
            displayName = adult.displayName,
            avatar = adult.avatar,
            age = adult.age,
            introBio = "พร้อมรับฟังและแลกเปลี่ยนความคิดเห็นครับ",
            status = CompanionStatus.PENDING_REVIEW,
            isReadyNow = false
        )

        repository.applyAsCompanion(newProfile)
        val submitted = repository.profiles.value.find { it.id == "comp_user_me" }
        assertNotNull(submitted)
        assertEquals(CompanionStatus.PENDING_REVIEW, submitted?.status)
        assertFalse(submitted?.isReadyNow ?: true)
    }

    @Test
    fun testAdminApproveRejectAndSuspendCompanion() {
        val compId = "comp_bank" // Bank is initially PENDING_REVIEW
        val initialProfile = repository.profiles.value.find { it.id == compId }
        assertEquals(CompanionStatus.PENDING_REVIEW, initialProfile?.status)

        // Admin approves
        repository.adminApproveCompanion(compId, "user_admin", "Official Admin", "เอกสาร KYC ถูกต้องครบถ้วน")
        val approvedProfile = repository.profiles.value.find { it.id == compId }
        assertEquals(CompanionStatus.APPROVED, approvedProfile?.status)
        assertTrue(approvedProfile?.isReadyNow == true)

        // Admin suspends
        repository.adminSuspendCompanion(compId, "user_admin", "Official Admin", "ตรวจพบพฤติกรรมไม่เหมาะสม")
        val suspendedProfile = repository.profiles.value.find { it.id == compId }
        assertEquals(CompanionStatus.SUSPENDED, suspendedProfile?.status)
        assertFalse(suspendedProfile?.isReadyNow == true)
        assertEquals(1, suspendedProfile?.penaltyHistoryCount)
    }

    @Test
    fun testLevelCalculationRules() {
        // VIP criteria: rating >= 4.9, hours >= 50, repeat >= 20, complaints = 0, penalty = 0
        val vipLevel = CompanionLevelCalculator.calculateLevel(
            rating = 4.95,
            totalHours = 60.0,
            repeatUsers = 25,
            complaints = 0,
            penaltyHistory = 0
        )
        assertEquals(CompanionLevel.VIP, vipLevel)

        // Gold criteria: rating >= 4.6, hours >= 15, repeat >= 5, complaints <= 2, penalty = 0
        val goldLevel = CompanionLevelCalculator.calculateLevel(
            rating = 4.7,
            totalHours = 20.0,
            repeatUsers = 8,
            complaints = 1,
            penaltyHistory = 0
        )
        assertEquals(CompanionLevel.GOLD, goldLevel)

        // If penalized heavily, demoted to STARTER
        val penalizedLevel = CompanionLevelCalculator.calculateLevel(
            rating = 4.9,
            totalHours = 80.0,
            repeatUsers = 30,
            complaints = 6,
            penaltyHistory = 3
        )
        assertEquals(CompanionLevel.STARTER, penalizedLevel)
    }

    @Test
    fun testAdminModifyLevelPricing() {
        val initialRates = repository.pricingConfig.value
        assertEquals(5, initialRates.getRate(CompanionLevel.STARTER, CompanionSessionType.TEXT))

        // Admin modifies rates
        repository.updatePricingRates(
            level = CompanionLevel.STARTER,
            text = 10,
            voice = 18,
            video = 28,
            adminId = "user_admin",
            adminName = "Official Admin",
            reason = "ปรับราคาตามอัตราเงินเฟ้อ"
        )

        val updatedRates = repository.pricingConfig.value
        assertEquals(10, updatedRates.getRate(CompanionLevel.STARTER, CompanionSessionType.TEXT))
        assertEquals(18, updatedRates.getRate(CompanionLevel.STARTER, CompanionSessionType.VOICE))
        assertEquals(28, updatedRates.getRate(CompanionLevel.STARTER, CompanionSessionType.VIDEO))
    }

    @Test
    fun testSessionCreditDeductionAndTermination() {
        val ratePerMin = 12
        // Can start if client has at least 1 min rate
        assertTrue(sessionManager.canStartSession(50, ratePerMin))
        assertFalse(sessionManager.canStartSession(10, ratePerMin))

        // Low credit check
        assertTrue(sessionManager.isLowCredit(8, ratePerMin))
        assertFalse(sessionManager.isLowCredit(25, ratePerMin))

        // Out of credits
        assertTrue(sessionManager.isOutOfCredits(0))
        assertTrue(sessionManager.isOutOfCredits(-5))
        assertFalse(sessionManager.isOutOfCredits(1))
    }

    @Test
    fun testCompanionWalletAndEarningsTracking() {
        val initialWallet = CompanionWallet(companionId = "comp_test")
        val session = CompanionSession(
            id = "sess_01",
            clientId = "user_me",
            clientName = "ต้นกล้า",
            companionId = "comp_test",
            companionName = "Test Companion",
            type = CompanionSessionType.VOICE,
            rateCoinsPerMinute = 15,
            durationSeconds = 120,
            totalCoinsDeducted = 30,
            companionEarningsCoins = 25
        )

        val creditedWallet = walletService.creditSessionEarning(initialWallet, session, 25)
        assertEquals(25, creditedWallet.todayEarningsCoins)
        assertEquals(25, creditedWallet.currentBalanceCoins)
        assertEquals(1, creditedWallet.sessionHistory.size)

        // Request withdrawal
        val bankAccount = CompanionBankAccount("KBANK", "123-4-56789-0", "Test Name")
        val withdrawalResult = walletService.requestWithdrawal(creditedWallet, 20, bankAccount)
        assertNotNull(withdrawalResult)

        val (walletAfterWd, wdReq) = withdrawalResult!!
        assertEquals(5, walletAfterWd.currentBalanceCoins)
        assertEquals(10, wdReq.amountBaht) // 20 coins * 0.5 = 10 baht
        assertEquals("pending", wdReq.status)
        assertEquals(bankAccount, walletAfterWd.bankAccount)
    }

    @Test
    fun testGiftRequestAcceptAndReject() {
        val greq = CompanionGiftRequest(
            id = "req_test",
            senderId = "user_me",
            senderName = "ต้นกล้า",
            senderAvatar = "",
            receiverId = "user_linlin",
            receiverName = "หลินหลิน",
            gift = CompanionGiftCatalogItem("g1", "ดอกไม้", "💐", 50, "ดอกไม้สวยงาม"),
            message = "อยากคุยด้วยครับ"
        )
        repository.sendGiftRequest(greq)

        // Reject case
        val (rejectedSuccess, rejectedReq) = repository.respondGiftRequest("req_test", false)
        assertTrue(rejectedSuccess)
        assertEquals(GiftRequestStatus.REJECTED, rejectedReq?.status)

        // Accept case
        val greq2 = greq.copy(id = "req_test_2")
        repository.sendGiftRequest(greq2)
        val (acceptedSuccess, acceptedReq) = repository.respondGiftRequest("req_test_2", true)
        assertTrue(acceptedSuccess)
        assertEquals(GiftRequestStatus.ACCEPTED, acceptedReq?.status)
    }

    @Test
    fun testAutomatedScreeningAndAuditLogs() {
        // Screening detects underage
        val screeningMinor = moderationService.performAutomatedScreening(
            age = 16,
            idCardNumber = "1-1004-99882-11-2",
            faceMatchConfidence = 0.95
        )
        assertTrue(screeningMinor.isFlaggedForManualReview)
        assertEquals(1.0, screeningMinor.riskScore, 0.01)

        // Screening adult with good match
        val screeningAdult = moderationService.performAutomatedScreening(
            age = 22,
            idCardNumber = "1-1004-99882-11-2",
            faceMatchConfidence = 0.98
        )
        assertFalse(screeningAdult.isFlaggedForManualReview)
        assertTrue(screeningAdult.riskScore < 0.2)

        // Audit Log creation
        val auditLog = moderationService.createAuditLog(
            adminId = "user_admin",
            adminName = "Official Admin",
            action = "ตรวจเอกสาร KYC",
            targetType = "companion_kyc",
            targetId = "comp_test",
            reason = "สุ่มตรวจความปลอดภัยประจำสัปดาห์"
        )
        assertEquals("Official Admin", auditLog.adminName)
        assertEquals("companion_kyc", auditLog.targetType)
    }
}
