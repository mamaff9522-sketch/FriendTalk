package com.example

import com.example.data.MockData
import com.example.model.Gender
import com.example.model.UserRole
import com.example.viewmodel.FriendTalkViewModel
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class FriendTalkUnitTest {

    private lateinit var viewModel: FriendTalkViewModel

    @Before
    fun setup() {
        viewModel = FriendTalkViewModel()
    }

    @Test
    fun testInitialDataLoaded() {
        val state = viewModel.uiState.value
        assertNotNull(state.currentUser)
        assertEquals("tonkla_tk", state.currentUser.username)
        assertTrue(state.users.isNotEmpty())
        assertTrue(state.posts.isNotEmpty())
        assertTrue(state.liveRooms.isNotEmpty())
        assertTrue(state.clubs.isNotEmpty())
        assertEquals(8, MockData.giftsCatalog.size)
    }

    @Test
    fun testTopUpCoins() {
        val initialCoins = viewModel.uiState.value.currentUser.coins
        viewModel.topUpCoins(650, 189)
        assertEquals(initialCoins + 650, viewModel.uiState.value.currentUser.coins)
    }

    @Test
    fun testLikePost() {
        viewModel.createPost("โพสต์ทดสอบ", emptyList(), emptyList())
        val newPost = viewModel.uiState.value.posts.first()
        assertEquals(0, newPost.likes.size)
        viewModel.likePost(newPost.id)
        val likedPost = viewModel.uiState.value.posts.first { it.id == newPost.id }
        assertTrue(likedPost.likes.contains(viewModel.uiState.value.currentUser.id))
        assertEquals(1, likedPost.likes.size)
    }

    @Test
    fun testCreateGroupChat() {
        val convId = viewModel.createGroupChat("กลุ่มท่องเที่ยว", listOf("user_linlin", "user_fah"))
        val conv = viewModel.uiState.value.conversations.find { it.id == convId }
        assertNotNull(conv)
        assertEquals("กลุ่มท่องเที่ยว", conv?.name)
        assertEquals("group", conv?.type)
        assertTrue(conv?.participantIds?.contains("user_linlin") == true)
    }

    @Test
    fun testRegisterUser() {
        val initialCount = viewModel.uiState.value.users.size
        viewModel.registerUser("Minnie", "minnie_cool", 21, Gender.FEMALE)
        assertEquals(initialCount + 1, viewModel.uiState.value.users.size)
        assertEquals("minnie_cool", viewModel.uiState.value.currentUser.username)
        assertEquals(500, viewModel.uiState.value.currentUser.coins) // Welcome bonus
    }

    @Test
    fun testSendLiveGiftDeductAndReward() {
        val state = viewModel.uiState.value
        val initialUserCoins = state.currentUser.coins
        val gift = MockData.giftsCatalog.first { it.id == "gift_rose" } // 1 coin
        val room = state.liveRooms.first { it.hostId == "user_linlin" }
        val hostBefore = state.users.first { it.id == "user_linlin" }

        val success = viewModel.sendLiveGift(room.id, gift)
        assertTrue(success)

        val updatedUser = viewModel.uiState.value.currentUser
        val updatedHost = viewModel.uiState.value.users.first { it.id == "user_linlin" }

        assertEquals(initialUserCoins - 1, updatedUser.coins)
        assertTrue(updatedHost.diamonds >= hostBefore.diamonds)
        assertNotNull(viewModel.uiState.value.activeGiftAnimation)
    }

    @Test
    fun testAdminModeration() {
        viewModel.adminSuspendUser("user_spammer", true)
        val spammer = viewModel.uiState.value.users.find { it.id == "user_spammer" }
        assertTrue(spammer?.isSuspended == true)

        viewModel.adminChangeRole("user_ploy", UserRole.ADMIN)
        val ploy = viewModel.uiState.value.users.find { it.id == "user_ploy" }
        assertEquals(UserRole.ADMIN, ploy?.role)
    }
}
